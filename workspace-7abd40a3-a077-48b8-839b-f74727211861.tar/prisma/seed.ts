// ─── Arpon Telecom — database seed (idempotent: deleteMany → create) ────────
// Run: bun prisma/seed.ts
import { PrismaClient } from "@prisma/client";
import { readFileSync } from "fs";
import { join } from "path";

const db = new PrismaClient();

// ── image URLs (slug → OSS urls) ────────────────────────────────────────────
const IMAGES: Record<string, string[]> = JSON.parse(
  readFileSync(join(process.cwd(), "data", "images.json"), "utf-8"),
);
const imgs = (slug: string): string[] => {
  const arr = IMAGES[slug] ?? [];
  return arr.length > 1 ? [arr[0], arr[1]] : [...arr];
};

// ── helpers ─────────────────────────────────────────────────────────────────
interface Spec { labelEn: string; labelBn: string; valueEn: string; valueBn: string }
interface VariantGroup { nameEn: string; nameBn: string; type: "color" | "storage"; options: string[] }
const sp = (labelEn: string, labelBn: string, valueEn: string, valueBn: string): Spec =>
  ({ labelEn, labelBn, valueEn, valueBn });
const phoneVariants = (colors: string[], storages: string[]): VariantGroup[] => [
  { nameEn: "Color", nameBn: "রঙ", type: "color", options: colors },
  { nameEn: "Storage", nameBn: "স্টোরেজ", type: "storage", options: storages },
];
const colorVariants = (colors: string[]): VariantGroup[] => [
  { nameEn: "Color", nameBn: "রঙ", type: "color", options: colors },
];
const daysAgo = (n: number) => new Date(Date.now() - n * 24 * 60 * 60 * 1000);

// ── categories ──────────────────────────────────────────────────────────────
const CATEGORIES = [
  { slug: "smartphones", nameEn: "Smartphones", nameBn: "স্মার্টফোন", icon: "Smartphone" },
  { slug: "feature-phones", nameEn: "Feature Phones", nameBn: "ফিচার ফোন", icon: "Phone" },
  { slug: "tablets", nameEn: "Tablets", nameBn: "ট্যাবলেট", icon: "Tablet" },
  { slug: "chargers-cables", nameEn: "Chargers & Cables", nameBn: "চার্জার ও কেবল", icon: "Plug" },
  { slug: "earphones-headphones", nameEn: "Earphones & Headphones", nameBn: "ইয়ারফোন ও হেডফোন", icon: "Headphones" },
  { slug: "power-banks", nameEn: "Power Banks", nameBn: "পাওয়ার ব্যাংক", icon: "BatteryCharging" },
  { slug: "smart-watches", nameEn: "Smart Watches", nameBn: "স্মার্ট ওয়াচ", icon: "Watch" },
  { slug: "cases-protectors", nameEn: "Cases & Protectors", nameBn: "কেস ও স্ক্রিন প্রোটেক্টর", icon: "ShieldCheck" },
  { slug: "sim-recharge", nameEn: "SIM & Recharge", nameBn: "সিম ও রিচার্জ", icon: "SimCard" },
  { slug: "spare-parts", nameEn: "Spare Parts", nameBn: "স্পেয়ার পার্টস", icon: "Wrench" },
];

const W_PHONE = ["1 year official warranty", "১ বছরের অফিসিয়াল ওয়ারেন্টি"];
const W_ACC = ["6 months replacement warranty", "৬ মাসের রিপ্লেসমেন্ট ওয়ারেন্টি"];
const W_WATCH = ["1 year brand warranty", "১ বছরের ব্র্যান্ড ওয়ারেন্টি"];
const W_DIGITAL = ["Digital item — no warranty", "ডিজিটাল আইটেম — কোনো ওয়ারেন্টি নেই"];
const W_PART = ["3 months service warranty", "৩ মাসের সার্ভিস ওয়ারেন্টি"];

// ── products ────────────────────────────────────────────────────────────────
interface SeedProduct {
  slug: string; nameEn: string; nameBn: string; brand: string; cat: string;
  price: number; oldPrice?: number; stock: number; stockStatus?: string;
  flash?: boolean; fresh?: boolean; best?: boolean;
  ram?: string; storage?: string; images: string[];
  rating: number; reviewCount: number; sold: number;
  warrantyEn: string; warrantyBn: string; descEn: string; descBn: string;
  specs: Spec[]; variants: VariantGroup[];
}

// bn digits: "8" → "৮"
const bnNum = (s: string) => s.replace(/[0-9]/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);
const ramBn = (ram: string) => bnNum(ram.replace("GB", "")) + " জিবি";
const stoBn = (s: string) => bnNum(s.replace("GB", "")) + " জিবি";
const phoneSpecs = (
  dispEn: string, dispBn: string, cpuEn: string, cpuBn: string,
  ram: string, sto: string, camEn: string, camBn: string, batEn: string, batBn: string
): Spec[] => [
  sp("Display", "ডিসপ্লে", dispEn, dispBn),
  sp("Processor", "প্রসেসর", cpuEn, cpuBn),
  sp("RAM", "র‍্যাম", ram, ramBn(ram)),
  sp("Storage", "স্টোরেজ", sto, stoBn(sto)),
  sp("Camera", "ক্যামেরা", camEn, camBn),
  sp("Battery", "ব্যাটারি", batEn, batBn),
];

const PRODUCTS: SeedProduct[] = [
  // ── smartphones ───────────────────────────────────────────────────────────
  {
    slug: "samsung-galaxy-a16-5g", nameEn: "Samsung Galaxy A16 5G", nameBn: "স্যামসাং গ্যালাক্সি A16 5G",
    brand: "Samsung", cat: "smartphones", price: 26999, oldPrice: 28999, stock: 15, best: true,
    ram: "8GB", storage: "128GB", images: imgs("p-samsung-a16"),
    rating: 4.6, reviewCount: 186, sold: 320, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "A sleek 5G all-rounder with a 6.7\" Super AMOLED display and Samsung's famous 6-generation OS upgrade promise. Perfect for gaming, streaming and everyday multitasking on a budget.",
    descBn: "৬.৭ ইঞ্চির সুপার AMOLED ডিসপ্লে ও ৬ জেনারেশনের OS আপডেট সুবিধাসহ স্টাইলিশ 5G ফোন। গেমিং, স্ট্রিমিং ও দৈনন্দিন কাজের জন্য বাজেটের মধ্যে সেরা পছন্দ।",
    specs: phoneSpecs("6.7\" Super AMOLED, 90Hz", "৬.৭\" সুপার AMOLED, ৯০Hz", "Exynos 1330", "এক্সিনোস ১৩৩০", "8GB", "128GB", "50MP + 5MP + 2MP ∣ 13MP", "৫০+৫+২ মেপি ∣ ১৩ মেপি", "5000mAh, 25W", "৫০০০ mAh, ২৫W"),
    variants: phoneVariants(["Blue Black", "Light Green", "Light Gray", "Gold"], ["8GB+128GB"]),
  },
  {
    slug: "redmi-note-14", nameEn: "Xiaomi Redmi Note 14", nameBn: "শাওমি রেডমি নোট ১৪",
    brand: "Xiaomi", cat: "smartphones", price: 24499, oldPrice: 26999, stock: 20, flash: true, fresh: true,
    ram: "8GB", storage: "256GB", images: imgs("p-redmi-note-14"),
    rating: 4.7, reviewCount: 214, sold: 245, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "The fan-favourite Note series returns with a 120Hz AMOLED panel and a crystal-clear 108MP main camera. With 45W fast charging, a full day's power lands in under an hour.",
    descBn: "প্রিয় নোট সিরিজে এবার ১২০Hz AMOLED ডিসপ্লে ও ঝকঝকে ১০৮ মেপি মেইন ক্যামেরা। ৪৫W ফাস্ট চার্জিংয়ে মাত্র এক ঘণ্টায় পাবেন সারাদিনের চার্জ।",
    specs: phoneSpecs("6.67\" AMOLED, 120Hz", "৬.৬৭\" AMOLED, ১২০Hz", "Dimensity 7025-Ultra", "ডাইমেনসিটি ৭০২৫-আল্ট্রা", "8GB", "256GB", "108MP + 2MP ∣ 20MP", "১০৮+২ মেপি ∣ ২০ মেপি", "5110mAh, 45W", "৫১১০ mAh, ৪৫W"),
    variants: phoneVariants(["Black", "Purple", "Green"], ["8GB+128GB", "8GB+256GB"]),
  },
  {
    slug: "realme-c75", nameEn: "realme C75", nameBn: "রিয়েলমি C75",
    brand: "Realme", cat: "smartphones", price: 18999, oldPrice: 19999, stock: 12, fresh: true,
    ram: "8GB", storage: "128GB", images: imgs("p-realme-c75"),
    rating: 4.5, reviewCount: 96, sold: 68, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "Built like a tank with IP69 water resistance and a massive 5828mAh battery that comfortably lasts two days. ArmorShell protection makes it one of the toughest phones in this price range.",
    descBn: "IP69 ওয়াটার রেজিস্ট্যান্স ও বিশাল ৫৮২৮ mAh ব্যাটারি — টেকসই ফোনের সেরা উদাহরণ। এই দামে সবচেয়ে মজবুত ফোনগুলোর একটি।",
    specs: phoneSpecs("6.72\" IPS LCD, 90Hz", "৬.৭২\" IPS LCD, ৯০Hz", "Helio G92 Max", "হেলিও G92 ম্যাক্স", "8GB", "128GB", "50MP ∣ 8MP", "৫০ মেপি ∣ ৮ মেপি", "5828mAh, 45W", "৫৮২৮ mAh, ৪৫W"),
    variants: phoneVariants(["Black", "Gold"], ["8GB+128GB"]),
  },
  {
    slug: "oppo-a60", nameEn: "OPPO A60", nameBn: "ওপ্পো A60",
    brand: "Oppo", cat: "smartphones", price: 21499, oldPrice: 22999, stock: 10,
    ram: "8GB", storage: "128GB", images: imgs("p-oppo-a60"),
    rating: 4.4, reviewCount: 74, sold: 55, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "Ultra-slim design with a 90Hz sunlit display and 45W SUPERVOOC charging that refuels 50% in 30 minutes. A dependable everyday phone with OPPO's polished ColorOS experience.",
    descBn: "আল্ট্রা-স্লিম ডিজাইন, ৯০Hz ডিসপ্লে ও ৪৫W SUPERVOOC চার্জিং — ৩০ মিনিটেই ৫০% চার্জ। স্মুথ ColorOS এক্সপেরিয়েন্সসহ নির্ভরযোগ্য ডেইলি ড্রাইভার।",
    specs: phoneSpecs("6.67\" IPS LCD, 90Hz", "৬.৬৭\" IPS LCD, ৯০Hz", "Snapdragon 680", "স্ন্যাপড্রাগন ৬৮০", "8GB", "128GB", "50MP + 2MP ∣ 8MP", "৫০+২ মেপি ∣ ৮ মেপি", "5000mAh, 45W", "৫০০০ mAh, ৪৫W"),
    variants: phoneVariants(["Purple", "Blue"], ["8GB+128GB"]),
  },
  {
    slug: "vivo-y28-5g", nameEn: "vivo Y28 5G", nameBn: "ভিভো Y28 5G",
    brand: "Vivo", cat: "smartphones", price: 23999, stock: 8,
    ram: "6GB", storage: "128GB", images: imgs("p-vivo-y28"),
    rating: 4.5, reviewCount: 58, sold: 47, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "5G-ready performance with a military-grade shock-resistant body and 6000mAh-class endurance. vivo's Y-series reliability with clean, bloat-free funtouch OS.",
    descBn: "মিলিটারি-গ্রেড শক-রেজিস্ট্যান্ট বডি ও দীর্ঘস্থায়ী ব্যাটারিসহ 5G-রেডি পারফরম্যান্স। bloat-free ফানটাচ ওএসে ভিভো Y-সিরিজের নির্ভরযোগ্যতা।",
    specs: phoneSpecs("6.56\" HD+ IPS, 90Hz", "৬.৫৬\" HD+ IPS, ৯০Hz", "Dimensity 6020", "ডাইমেনসিটি ৬০২০", "6GB", "128GB", "13MP + 0.08MP ∣ 5MP", "১৩ মেপি ∣ ৫ মেপি", "5000mAh, 15W", "৫০০০ mAh, ১৫W"),
    variants: phoneVariants(["Crystal Purple", "Aqua Green"], ["6GB+128GB", "8GB+128GB"]),
  },
  {
    slug: "infinix-hot-50-pro-plus", nameEn: "Infinix Hot 50 Pro+", nameBn: "ইনফিনিক্স হট ৫০ প্রো+",
    brand: "Infinix", cat: "smartphones", price: 16499, oldPrice: 17999, stock: 25, flash: true,
    ram: "8GB", storage: "256GB", images: imgs("p-infinix-hot-50"),
    rating: 4.6, reviewCount: 132, sold: 198, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "A curved AMOLED masterpiece at a shocking price — just 6.8mm thin with 256GB of storage. The Helio G100 chipset handles PUBG and BGMI at smooth frame rates.",
    descBn: "অবিশ্বাস্য দামে কার্ভড AMOLED ডিসপ্লে — মাত্র ৬.৮ মিমি পাতলা, সাথে ২৫৬ জিবি স্টোরেজ। হেলিও G১০০ চিপসেটে PUBG ও BGMI মসৃণ ফ্রেমরেটে চলে।",
    specs: phoneSpecs("6.78\" Curved AMOLED, 120Hz", "৬.৭৮\" কার্ভড AMOLED, ১২০Hz", "Helio G100", "হেলিও G100", "8GB", "256GB", "50MP + 2MP ∣ 13MP", "৫০+২ মেপি ∣ ১৩ মেপি", "5000mAh, 33W", "৫০০০ mAh, ৩৩W"),
    variants: phoneVariants(["Black", "Titanium Grey", "Dreamy Blue"], ["8GB+256GB"]),
  },
  {
    slug: "iphone-13-128gb", nameEn: "Apple iPhone 13 (128GB)", nameBn: "অ্যাপল আইফোন ১৩ (১২৮ জিবি)",
    brand: "Apple", cat: "smartphones", price: 92999, oldPrice: 97999, stock: 5, best: true,
    ram: "4GB", storage: "128GB", images: imgs("p-iphone-13"),
    rating: 4.9, reviewCount: 342, sold: 460, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "The A15 Bionic powerhouse with dual 12MP cameras, Cinematic mode and industry-leading battery efficiency. Still the best-value iPhone in Bangladesh — sealed box with official warranty.",
    descBn: "A15 বায়োনিক চিপ, ডুয়াল ১২ মেপি ক্যামেরা ও সিনেমাটিক মোডসহ দুর্দান্ত ব্যাটারি ব্যাকআপ। বাংলাদেশে সেরা ভ্যালু আইফোন — সিলড বক্স, অফিসিয়াল ওয়ারেন্টিসহ।",
    specs: phoneSpecs("6.1\" Super Retina XDR OLED", "৬.১\" সুপার রেটিনা XDR OLED", "Apple A15 Bionic", "অ্যাপল A15 বায়োনিক", "4GB", "128GB", "12MP + 12MP ∣ 12MP", "১২+১২ মেপি ∣ ১২ মেপি", "3240mAh, 20W", "৩২৪০ mAh, ২০W"),
    variants: phoneVariants(["Midnight", "Starlight", "Blue", "Pink", "Red"], ["4GB+128GB"]),
  },
  {
    slug: "symphony-g96", nameEn: "Symphony G96", nameBn: "সিম্ফনি G96",
    brand: "Symphony", cat: "smartphones", price: 9499, oldPrice: 9999, stock: 30,
    ram: "4GB", storage: "64GB", images: imgs("p-symphony"),
    rating: 4.3, reviewCount: 64, sold: 88, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "A true Bangladeshi favourite — big 6.79\" display, 50MP camera and clean Android under 10K. Local service centers everywhere make ownership completely worry-free.",
    descBn: "বাংলাদেশের নিজের ব্র্যান্ডের জনপ্রিয় ফোন — বড় ৬.৭৯\" ডিসপ্লে, ৫০ মেপি ক্যামেরা ও ১০ হাজারের নিচে পরিষ্কার অ্যান্ড্রয়েড। সারাদেশে সার্ভিস সেন্টার, তাই চিন্তামুক্ত।",
    specs: phoneSpecs("6.79\" HD+ 90Hz", "৬.৭৯\" HD+, ৯০Hz", "Unisoc T616", "ইউনিসক T616", "4GB", "64GB", "50MP ∣ 8MP", "৫০ মেপি ∣ ৮ মেপি", "5000mAh, 18W", "৫০০০ mAh, ১৮W"),
    variants: phoneVariants(["Black", "Green"], ["4GB+64GB"]),
  },
  {
    slug: "walton-xolon-x20", nameEn: "Walton Xolon X20", nameBn: "ওয়ালটন Xolon X20",
    brand: "Walton", cat: "smartphones", price: 7999, stock: 0, stockStatus: "out_of_stock",
    ram: "4GB", storage: "64GB", images: imgs("p-walton"),
    rating: 4.2, reviewCount: 21, sold: 30, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "Walton's budget hero with a 90Hz screen and a full-day 5000mAh battery. Grab it when restocked — this Xolon X20 sells out fast every time.",
    descBn: "ওয়ালটনের বাজেট ফ্রেন্ডলি ফোন — ৯০Hz স্ক্রিন ও সারাদিন চলার মতো ৫০০০ mAh ব্যাটারি। আবার স্টকে এলে আগে কিনে ফেলুন, দ্রুতই শেষ হয়ে যায়!",
    specs: phoneSpecs("6.6\" HD+ IPS, 90Hz", "৬.৬\" HD+ IPS, ৯০Hz", "Unisoc T612", "ইউনিসক T612", "4GB", "64GB", "13MP + AI ∣ 8MP", "১৩ মেপি ∣ ৮ মেপি", "5000mAh, 10W", "৫০০০ mAh, ১০W"),
    variants: phoneVariants(["Black", "Green"], ["4GB+64GB"]),
  },
  // ── feature phones ────────────────────────────────────────────────────────
  {
    slug: "nokia-105-2023", nameEn: "Nokia 105 (2023)", nameBn: "নকিয়া ১০৫ (২০২৩)",
    brand: "Nokia", cat: "feature-phones", price: 2399, stock: 40, best: true,
    images: imgs("p-nokia-105"),
    rating: 4.7, reviewCount: 158, sold: 380, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "The legendary Nokia durability in a modern avatar — weeks of standby, wireless FM and a loudspeaker that fills the room. The perfect backup phone or gift for parents.",
    descBn: "নকিয়ার কিংবদন্তি টেকসই ডিজাইন — সপ্তাহজুড়ে স্ট্যান্ডবাই, ওয়্যারলেস এফএম ও শক্তিশালী লাউডস্পিকার। ব্যাকআপ ফোন বা বাবা-মায়ের জন্য উপহার হিসেবে সেরা।",
    specs: [
      sp("Display", "ডিসপ্লে", "1.8\" QQVGA", "১.৮\" QQVGA"),
      sp("Battery", "ব্যাটারি", "800mAh, up to 15 days standby", "৮০০ mAh, ১৫ দিন পর্যন্ত স্ট্যান্ডবাই"),
      sp("SIM", "সিম", "Dual SIM (Mini)", "ডুয়াল সিম (মিনি)"),
      sp("Storage", "স্টোরেজ", "Phonebook + microSD up to 32GB", "ফোনবুক + ৩২ জিবি পর্যন্ত মাইক্রোএসডি"),
    ],
    variants: colorVariants(["Black", "Blue", "Red"]),
  },
  {
    slug: "symphony-l280", nameEn: "Symphony L280", nameBn: "সিম্ফনি L280",
    brand: "Symphony", cat: "feature-phones", price: 1899, oldPrice: 2199, stock: 35, flash: true,
    images: [...(IMAGES["p-symphony"] ?? [])].reverse(),
    rating: 4.4, reviewCount: 45, sold: 120, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "A big-button feature phone with a 2.4\" display and a huge 2500mAh removable battery. Torch, wireless FM and dual SIM — everything a simple phone needs.",
    descBn: "বড় বাটন ও ২.৪\" ডিসপ্লেসহ ফিচার ফোন, সাথে বিশাল ২৫০০ mAh রিমুভেবল ব্যাটারি। টর্চ, ওয়্যারলেস এফএম ও ডুয়াল সিম — সিম্পল ফোনের সব চাহিদা পূরণ।",
    specs: [
      sp("Display", "ডিসপ্লে", "2.4\" QVGA", "২.৪\" QVGA"),
      sp("Battery", "ব্যাটারি", "2500mAh removable", "২৫০০ mAh রিমুভেবল"),
      sp("SIM", "সিম", "Dual SIM", "ডুয়াল সিম"),
      sp("Extras", "এক্সট্রা", "Torch + Wireless FM", "টর্চ + ওয়্যারলেস এফএম"),
    ],
    variants: colorVariants(["Black", "Blue"]),
  },
  // ── tablets ───────────────────────────────────────────────────────────────
  {
    slug: "samsung-galaxy-tab-a9-plus", nameEn: "Samsung Galaxy Tab A9+", nameBn: "স্যামসাং গ্যালাক্সি ট্যাব A9+",
    brand: "Samsung", cat: "tablets", price: 29999, oldPrice: 31999, stock: 7, best: true,
    ram: "8GB", storage: "128GB", images: imgs("p-tab-a9"),
    rating: 4.6, reviewCount: 98, sold: 210, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "An 11\" 90Hz screen with quad speakers tuned by AKG — perfect for online classes, movies and light gaming. Quad stereo sound makes it the best family tablet in its class.",
    descBn: "১১ ইঞ্চির ৯০Hz ডিসপ্লে ও AKG-টিউনড কোয়াড স্পিকার — অনলাইন ক্লাস, মুভি ও লাইট গেমিংয়ের জন্য পারফেক্ট। ফ্যামিলি ট্যাবলেট হিসেবে এর মধ্যে সেরা।",
    specs: phoneSpecs("11\" 90Hz LCD", "১১\" ৯০Hz LCD", "Snapdragon 695", "স্ন্যাপড্রাগন ৬৯৫", "8GB", "128GB", "8MP ∣ 8MP", "৮ মেপি ∣ ৮ মেপি", "7040mAh, 15W", "৭০৪০ mAh, ১৫W"),
    variants: phoneVariants(["Graphite", "Silver", "Blue"], ["8GB+128GB"]),
  },
  {
    slug: "walton-pad-11", nameEn: "Walton Pad 11 Wi-Fi", nameBn: "ওয়ালটন প্যাড ১১ ওয়াই-ফাই",
    brand: "Walton", cat: "tablets", price: 14999, stock: 0, stockStatus: "pre_order", fresh: true,
    ram: "4GB", storage: "64GB", images: imgs("p-walton-tab"),
    rating: 4.3, reviewCount: 12, sold: 25, warrantyEn: W_PHONE[0], warrantyBn: W_PHONE[1],
    descEn: "A 2K IPS tablet tuned for study and entertainment at a local-brand price. Pre-order now — limited first batch arrives within 7 working days.",
    descBn: "লোকাল ব্র্যান্ডের দামে পড়াশোনা ও বিনোদনের জন্য ২কে IPS ট্যাবলেট। এখনই প্রি-অর্ডার করুন — প্রথম ব্যাচ ৭ কার্যদিবসের মধ্যে পৌঁছে যাবে।",
    specs: phoneSpecs("10.95\" 2K IPS", "১০.৯৫\" ২কে IPS", "Unisoc T616", "ইউনিসক T616", "4GB", "64GB", "5MP ∣ 2MP", "৫ মেপি ∣ ২ মেপি", "7000mAh, 10W", "৭০০০ mAh, ১০W"),
    variants: phoneVariants(["Grey", "Blue"], ["4GB+64GB"]),
  },
  // ── chargers & cables ─────────────────────────────────────────────────────
  {
    slug: "anker-313-20w-charger", nameEn: "Anker 313 20W Type-C Charger", nameBn: "অ্যাংকার ৩১৩ ২০ওয়াট টাইপ-সি চার্জার",
    brand: "Anker", cat: "chargers-cables", price: 1750, oldPrice: 1999, stock: 50, flash: true,
    images: imgs("p-anker-charger"),
    rating: 4.8, reviewCount: 176, sold: 230, warrantyEn: W_ACC[0], warrantyBn: W_ACC[1],
    descEn: "Anker's best-selling compact charger with PowerIQ 3.0 delivering a full 20W to any phone or tablet. ActiveShield temperature monitoring keeps every charge completely safe.",
    descBn: "অ্যাংকারের জনপ্রিয় কমপ্যাক্ট চার্জার — PowerIQ 3.0 দিয়ে যেকোনো ফোনে পুরো ২০ ওয়াট। ActiveShield তাপমাত্রা নিয়ন্ত্রণে প্রতিটি চার্জ সম্পূর্ণ নিরাপদ।",
    specs: [
      sp("Output", "আউটপুট", "20W PowerIQ 3.0 (PD)", "২০ ওয়াট PowerIQ 3.0 (PD)"),
      sp("Port", "পোর্ট", "Single USB-C", "সিঙ্গেল ইউএসবি-সি"),
      sp("Compatibility", "সামঞ্জস্যতা", "iPhone, Galaxy, Redmi & all Type-C devices", "আইফোন, গ্যালাক্সি, রেডমি ও সব টাইপ-সি ডিভাইস"),
      sp("Safety", "নিরাপত্তা", "ActiveShield™ 2.0 temperature monitoring", "ActiveShield™ 2.0 তাপমাত্রা নিয়ন্ত্রণ"),
      sp("Warranty", "ওয়ারেন্টি", "6 months replacement", "৬ মাসের রিপ্লেসমেন্ট"),
    ],
    variants: [],
  },
  {
    slug: "baseus-cafule-cable-2m", nameEn: "Baseus Cafule Type-C Cable 2m", nameBn: "বেসাস ক্যাফুল টাইপ-সি কেবল ২ মিটার",
    brand: "Baseus", cat: "chargers-cables", price: 450, stock: 100,
    images: imgs("p-baseus-cable"),
    rating: 4.5, reviewCount: 89, sold: 72, warrantyEn: W_ACC[0], warrantyBn: W_ACC[1],
    descEn: "Nylon-braided toughness rated for 10,000+ bends, carrying up to 3A fast charge. The extra 2-metre length lets you charge comfortably from anywhere on the bed or sofa.",
    descBn: "১০,০০০+ বেন্ড সহ্য করতে পারে এমন নাইলন-ব্রেইডেড মজবুত কেবল, ৩A পর্যন্ত ফাস্ট চার্জ সাপোর্ট। ২ মিটার লম্বা হওয়ায় বিছানা বা সোফা থেকেও আরামে চার্জ দিতে পারবেন।",
    specs: [
      sp("Length", "দৈর্ঘ্য", "2 metres", "২ মিটার"),
      sp("Current", "কারেন্ট", "Up to 3A fast charging", "৩A পর্যন্ত ফাস্ট চার্জিং"),
      sp("Material", "উপাদান", "Nylon braided + aluminium shell", "নাইলন ব্রেইডেড + অ্যালুমিনিয়াম শেল"),
      sp("Compatibility", "সামঞ্জস্যতা", "All Type-C phones & tablets", "সব টাইপ-সি ফোন ও ট্যাবলেট"),
      sp("Warranty", "ওয়ারেন্টি", "6 months replacement", "৬ মাসের রিপ্লেসমেন্ট"),
    ],
    variants: [],
  },
  // ── earphones & headphones ────────────────────────────────────────────────
  {
    slug: "redmi-buds-5", nameEn: "Xiaomi Redmi Buds 5", nameBn: "শাওমি রেডমি বাডস ৫",
    brand: "Xiaomi", cat: "earphones-headphones", price: 2899, oldPrice: 3299, stock: 22, fresh: true, best: true,
    images: imgs("p-redmi-buds"),
    rating: 4.6, reviewCount: 143, sold: 260, warrantyEn: W_ACC[0], warrantyBn: W_ACC[1],
    descEn: "46dB hybrid active noise cancellation and a huge 40-hour total playback — flagship TWS features at a budget price. 12.4mm dynamic drivers deliver punchy bass and clear calls.",
    descBn: "৪৬dB হাইব্রিড অ্যাক্টিভ নয়েজ ক্যান্সেলেশন ও মোট ৪০ ঘণ্টা প্লেব্যাক — বাজেট দামে ফ্ল্যাগশিপ TWS ফিচার। ১২.৪ মিমি ড্রাইভারে শক্তিশালী বেজ ও পরিষ্কার কল।",
    specs: [
      sp("Playback", "প্লেব্যাক টাইম", "Up to 40 hours with case", "কেসসহ ৪০ ঘণ্টা পর্যন্ত"),
      sp("ANC", "এএনসি", "46dB hybrid active noise cancellation", "৪৬dB হাইব্রিড অ্যাক্টিভ নয়েজ ক্যান্সেলেশন"),
      sp("Driver", "ড্রাইভার", "12.4mm dynamic titanium driver", "১২.৪ মিমি ডাইনামিক টাইটানিয়াম ড্রাইভার"),
      sp("Bluetooth", "ব্লুটুথ", "v5.3, dual-device connection", "v5.3, ডুয়াল-ডিভাইস কানেকশন"),
      sp("Warranty", "ওয়ারেন্টি", "6 months replacement", "৬ মাসের রিপ্লেসমেন্ট"),
    ],
    variants: colorVariants(["Black", "White", "Blue"]),
  },
  {
    slug: "baseus-bowie-h1", nameEn: "Baseus Bowie H1 Wireless Headphone", nameBn: "বেসাস বোয়ি H1 ওয়্যারলেস হেডফোন",
    brand: "Baseus", cat: "earphones-headphones", price: 1650, oldPrice: 1899, stock: 15, flash: true,
    images: imgs("p-neckband"),
    rating: 4.4, reviewCount: 67, sold: 95, warrantyEn: W_ACC[0], warrantyBn: W_ACC[1],
    descEn: "A comfortable neckband earphone with magnetic buds and up to 25 hours of uninterrupted playback. IPX5 sweat resistance makes it ideal for commutes and workouts alike.",
    descBn: "ম্যাগনেটিক বাডস ও ২৫ ঘণ্টা পর্যন্ত নন-স্টপ প্লেব্যাকসহ আরামদায়ক নেকব্যান্ড ইয়ারফোন। IPX5 সোয়েট রেজিস্ট্যান্স — রোজকার যাতায়াত ও ওয়ার্কআউট দুটোতেই চমৎকার।",
    specs: [
      sp("Playback", "প্লেব্যাক টাইম", "Up to 25 hours", "২৫ ঘণ্টা পর্যন্ত"),
      sp("Type", "ধরন", "Neckband with magnetic buds", "ম্যাগনেটিক বাডসসহ নেকব্যান্ড"),
      sp("Bluetooth", "ব্লুটুথ", "v5.0, 10m range", "v5.0, ১০ মিটার রেঞ্জ"),
      sp("Charging", "চার্জিং", "USB-C, 10 min = 3 hours", "ইউএসবি-সি, ১০ মিনিটে ৩ ঘণ্টা"),
      sp("Warranty", "ওয়ারেন্টি", "6 months replacement", "৬ মাসের রিপ্লেসমেন্ট"),
    ],
    variants: colorVariants(["Black", "Blue"]),
  },
  // ── power banks ───────────────────────────────────────────────────────────
  {
    slug: "anker-powercore-10000", nameEn: "Anker PowerCore 10000mAh", nameBn: "অ্যাংকার পাওয়ারকোর ১০০০০ mAh",
    brand: "Anker", cat: "power-banks", price: 2950, oldPrice: 3200, stock: 18, best: true,
    images: imgs("p-anker-powercore"),
    rating: 4.8, reviewCount: 201, sold: 340, warrantyEn: W_ACC[0], warrantyBn: W_ACC[1],
    descEn: "Pocket-sized 10,000mAh with 20W Power Delivery — charges an iPhone nearly twice and fast-charges Samsung & Xiaomi too. The world's most trusted power bank brand, now in Bangladesh.",
    descBn: "পকেট সাইজের ১০,০০০ mAh, ২০W পাওয়ার ডেলিভারিসহ — আইফোন প্রায় দুবার চার্জ করে, স্যামসাং ও শাওমিও ফাস্ট চার্জ হয়। বিশ্বের সবচেয়ে বিশ্বস্ত পাওয়ার ব্যাংক ব্র্যান্ড এখন বাংলাদেশে।",
    specs: [
      sp("Capacity", "ক্যাপাসিটি", "10000mAh (37Wh)", "১০০০০ mAh (৩৭Wh)"),
      sp("Output", "আউটপুট", "20W Power Delivery", "২০ ওয়াট পাওয়ার ডেলিভারি"),
      sp("Ports", "পোর্ট", "USB-C in/out + USB-A", "ইউএসবি-সি ইন/আউট + ইউএসবি-এ"),
      sp("Recharge Time", "রিচার্জ টাইম", "~5 hours with 20W charger", "২০ ওয়াট চার্জারে ~৫ ঘণ্টা"),
      sp("Warranty", "ওয়ারেন্টি", "6 months replacement", "৬ মাসের রিপ্লেসমেন্ট"),
    ],
    variants: [],
  },
  {
    slug: "xiaomi-powerbank-20000-33w", nameEn: "Xiaomi 20000mAh 33W Power Bank", nameBn: "শাওমি ২০০০০ mAh ৩৩ওয়াট পাওয়ার ব্যাংক",
    brand: "Xiaomi", cat: "power-banks", price: 3499, stock: 14, fresh: true,
    images: imgs("p-xiaomi-powerbank"),
    rating: 4.7, reviewCount: 112, sold: 85, warrantyEn: W_ACC[0], warrantyBn: W_ACC[1],
    descEn: "A travel-day hero: 20,000mAh charges a phone 4-5 times, with 33W output that even tops up laptops. Triple-port design lets you charge three devices at the same time.",
    descBn: "ভ্রমণের সেরা সঙ্গী: ২০,০০০ mAh — ফোন ৪-৫ বার চার্জ করে, আর ৩৩ ওয়াট আউটপুটে ল্যাপটপও চার্জ হয়। ট্রিপল-পোর্টে একসাথে তিনটি ডিভাইস চার্জ করা যায়।",
    specs: [
      sp("Capacity", "ক্যাপাসিটি", "20000mAh (74Wh)", "২০০০০ mAh (৭৪Wh)"),
      sp("Output", "আউটপুট", "33W max fast charging", "৩৩ ওয়াট ম্যাক্স ফাস্ট চার্জিং"),
      sp("Ports", "পোর্ট", "USB-C + dual USB-A", "ইউএসবি-সি + ডুয়াল ইউএসবি-এ"),
      sp("Recharge Time", "রিচার্জ টাইম", "~6.9 hours with 33W input", "৩৩ ওয়াট ইনপুটে ~৬.৯ ঘণ্টা"),
      sp("Warranty", "ওয়ারেন্টি", "6 months replacement", "৬ মাসের রিপ্লেসমেন্ট"),
    ],
    variants: [],
  },
  // ── smart watches ─────────────────────────────────────────────────────────
  {
    slug: "amazfit-bip-5", nameEn: "Amazfit Bip 5 Smart Watch", nameBn: "অ্যামাজফিট বিপ ৫ স্মার্ট ওয়াচ",
    brand: "Amazfit", cat: "smart-watches", price: 6999, oldPrice: 7999, stock: 9, fresh: true,
    images: imgs("p-amazfit-bip5"),
    rating: 4.5, reviewCount: 54, sold: 60, warrantyEn: W_WATCH[0], warrantyBn: W_WATCH[1],
    descEn: "A big 1.91\" display with built-in GPS and up to 10 days of battery life. SpO2, heart-rate and 120+ sports modes make it the smartest health companion under 7K.",
    descBn: "বড় ১.৯১\" ডিসপ্লে, বিল্ট-ইন জিপিএস ও ১০ দিন পর্যন্ত ব্যাটারি লাইফ। SpO2, হার্ট-রেট ও ১২০+ স্পোর্টস মোড — ৭ হাজারের নিচের সেরা হেলথ কম্প্যানিয়ন।",
    specs: [
      sp("Display", "ডিসপ্লে", "1.91\" HD TFT, 2.5D glass", "১.৯১\" HD TFT, 2.5D গ্লাস"),
      sp("Battery", "ব্যাটারি", "Up to 10 days typical use", "সাধারণ ব্যবহারে ১০ দিন পর্যন্ত"),
      sp("GPS", "জিপিএস", "Built-in dual-band GPS", "বিল্ট-ইন ডুয়াল-ব্যান্ড জিপিএস"),
      sp("Health", "হেলথ মনিটর", "SpO2, heart rate, sleep & stress", "SpO2, হার্ট রেট, ঘুম ও স্ট্রেস"),
      sp("Warranty", "ওয়ারেন্টি", "1 year brand warranty", "১ বছরের ব্র্যান্ড ওয়ারেন্টি"),
    ],
    variants: colorVariants(["Black", "Blue", "Pink"]),
  },
  {
    slug: "redmi-watch-5-lite", nameEn: "Xiaomi Redmi Watch 5 Lite", nameBn: "শাওমি রেডমি ওয়াচ ৫ লাইট",
    brand: "Xiaomi", cat: "smart-watches", price: 4999, oldPrice: 5499, stock: 16, flash: true,
    images: imgs("p-redmi-watch"),
    rating: 4.4, reviewCount: 77, sold: 140, warrantyEn: W_WATCH[0], warrantyBn: W_WATCH[1],
    descEn: "A 1.96\" AMOLED beauty with 5ATM water resistance and 150+ sport modes. Up to 18 days of battery means you can almost forget the charger.",
    descBn: "১.৯৬\" AMOLED ডিসপ্লে, 5ATM ওয়াটার রেজিস্ট্যান্স ও ১৫০+ স্পোর্টস মোড। ১৮ দিন পর্যন্ত ব্যাটারি — চার্জার নিয়ে প্রায় ভাবতেই হবে না।",
    specs: [
      sp("Display", "ডিসপ্লে", "1.96\" AMOLED, 600 nits", "১.৯৬\" AMOLED, ৬০০ নিটস"),
      sp("Battery", "ব্যাটারি", "Up to 18 days", "১৮ দিন পর্যন্ত"),
      sp("Sports Modes", "স্পোর্টস মোড", "150+ workout modes", "১৫০+ ওয়ার্কআউট মোড"),
      sp("Water Resistance", "ওয়াটার রেজিস্ট্যান্স", "5ATM", "5ATM"),
      sp("Warranty", "ওয়ারেন্টি", "1 year brand warranty", "১ বছরের ব্র্যান্ড ওয়ারেন্টি"),
    ],
    variants: colorVariants(["Black", "Blue", "Silver"]),
  },
  // ── cases & protectors ────────────────────────────────────────────────────
  {
    slug: "spigen-liquid-air-a16", nameEn: "Spigen Liquid Air Case (Galaxy A16)", nameBn: "স্পিগেন লিকুইড এয়ার কেস (গ্যালাক্সি A16)",
    brand: "Spigen", cat: "cases-protectors", price: 950, oldPrice: 1150, stock: 30,
    images: imgs("p-spigen-case"),
    rating: 4.6, reviewCount: 38, sold: 65, warrantyEn: W_ACC[0], warrantyBn: W_ACC[1],
    descEn: "Original Spigen Liquid Air with air-cushion corners that absorb drops and shocks. Slim, grippy and fingerprint-free — the everyday armour your Galaxy A16 deserves.",
    descBn: "অরিজিনাল স্পিগেন লিকুইড এয়ার — এয়ার-কুশন কর্নার ড্রপ ও শক শুষে নেয়। স্লিম, গ্রিপি ও ফিঙ্গারপ্রিন্ট-ফ্রি — আপনার গ্যালাক্সি A16-এর জন্য পারফেক্ট ডেইলি আর্মার।",
    specs: [
      sp("Compatibility", "সামঞ্জস্যতা", "Samsung Galaxy A16 5G/4G", "স্যামসাং গ্যালাক্সি A16 5G/4G"),
      sp("Material", "উপাদান", "Flexible TPU with matte finish", "ম্যাট ফিনিশ ফ্লেক্সিবল TPU"),
      sp("Protection", "প্রোটেকশন", "Air Cushion® corner protection", "Air Cushion® কর্নার প্রোটেকশন"),
      sp("Warranty", "ওয়ারেন্টি", "6 months replacement", "৬ মাসের রিপ্লেসমেন্ট"),
    ],
    variants: colorVariants(["Black", "Dark Green"]),
  },
  {
    slug: "nillkin-h-pro-glass-rn14", nameEn: "Nillkin Amazing H+ Pro Glass (Redmi Note 14)", nameBn: "নিলকিন অ্যামেজিং H+ প্রো গ্লাস (রেডমি নোট ১৪)",
    brand: "Nillkin", cat: "cases-protectors", price: 390, stock: 60,
    images: imgs("p-glass"),
    rating: 4.5, reviewCount: 29, sold: 80, warrantyEn: W_ACC[0], warrantyBn: W_ACC[1],
    descEn: "9H hardened tempered glass with an anti-explosion film layer keeps your Note 14's AMOLED flawless. Oleophobic coating repels fingerprints and keeps touches silky smooth.",
    descBn: "9H হার্ডনেসের টেম্পারড গ্লাস ও অ্যান্টি-এক্সপ্লোশন লেয়ার আপনার নোট ১৪-এর AMOLED স্ক্রিন সবসময় নিরাপদ রাখে। অলিওফোবিক কোটিংয়ে ফিঙ্গারপ্রিন্ট লাগে না, টাচ থাকে মসৃণ।",
    specs: [
      sp("Compatibility", "সামঞ্জস্যতা", "Redmi Note 14 4G/5G", "রেডমি নোট ১৪ 4G/5G"),
      sp("Hardness", "হার্ডনেস", "9H tempered glass", "9H টেম্পারড গ্লাস"),
      sp("Thickness", "বেধ", "0.33mm, full coverage", "০.৩৩ মিমি, ফুল কভারেজ"),
      sp("Coating", "কোটিং", "Anti-fingerprint oleophobic", "অ্যান্টি-ফিঙ্গারপ্রিন্ট অলিওফোবিক"),
      sp("Warranty", "ওয়ারেন্টি", "6 months replacement", "৬ মাসের রিপ্লেসমেন্ট"),
    ],
    variants: [],
  },
  // ── sim & recharge ────────────────────────────────────────────────────────
  {
    slug: "gp-recharge-200", nameEn: "Grameenphone Recharge ৳200", nameBn: "গ্রামীণফোন রিচার্জ ৳২০০",
    brand: "Grameenphone", cat: "sim-recharge", price: 200, stock: 999,
    images: [IMAGES["p-samsung-a16"][0]],
    rating: 4.8, reviewCount: 210, sold: 90, warrantyEn: W_DIGITAL[0], warrantyBn: W_DIGITAL[1],
    descEn: "Top up ৳200 talktime to any Grameenphone number instantly — no PIN, no hassle. Credit lands on the number within seconds of payment confirmation.",
    descBn: "যেকোনো গ্রামীণফোন নম্বরে সাথে সাথে ৳২০০ টকটাইম রিচার্জ — কোনো পিন বা ঝামেলা নেই। পেমেন্ট নিশ্চিত হওয়ার কয়েক সেকেন্ডেই ব্যালেন্স যোগ হয়ে যাবে।",
    specs: [
      sp("Operator", "অপারেটর", "Grameenphone", "গ্রামীণফোন"),
      sp("Amount", "পরিমাণ", "৳200 talktime", "৳২০০ টকটাইম"),
      sp("Delivery", "ডেলিভারি", "Instant, PIN-less", "সাথে সাথে, পিন-লেস"),
      sp("Validity", "ভ্যালিডিটি", "As per operator rules", "অপারেটরের নিয়ম অনুযায়ী"),
      sp("Warranty", "ওয়ারেন্টি", "Digital item — no warranty", "ডিজিটাল আইটেম — কোনো ওয়ারেন্টি নেই"),
    ],
    variants: [],
  },
  {
    slug: "robi-recharge-100", nameEn: "Robi Recharge ৳100", nameBn: "রবি রিচার্জ ৳১০০",
    brand: "Robi", cat: "sim-recharge", price: 100, stock: 999,
    images: [IMAGES["p-redmi-note-14"][0]],
    rating: 4.7, reviewCount: 120, sold: 70, warrantyEn: W_DIGITAL[0], warrantyBn: W_DIGITAL[1],
    descEn: "Recharge ৳100 to any Robi number in seconds and get full talktime as per operator rules. Works for prepaid connections, 24/7 — even on holidays.",
    descBn: "যেকোনো রবি নম্বরে কয়েক সেকেন্ডে ৳১০০ রিচার্জ, অপারেটরের নিয়ম অনুযায়ী পুরো টকটাইম। প্রিপেইড কানেকশনে ২৪/৭ কাজ করে — ছুটির দিনেও।",
    specs: [
      sp("Operator", "অপারেটর", "Robi", "রবি"),
      sp("Amount", "পরিমাণ", "৳100 talktime", "৳১০০ টকটাইম"),
      sp("Delivery", "ডেলিভারি", "Instant, PIN-less", "সাথে সাথে, পিন-লেস"),
      sp("Validity", "ভ্যালিডিটি", "As per operator rules", "অপারেটরের নিয়ম অনুযায়ী"),
      sp("Warranty", "ওয়ারেন্টি", "Digital item — no warranty", "ডিজিটাল আইটেম — কোনো ওয়ারেন্টি নেই"),
    ],
    variants: [],
  },
  {
    slug: "banglalink-recharge-500", nameEn: "Banglalink Recharge ৳500", nameBn: "বাংলালিংক রিচার্জ ৳৫০০",
    brand: "Banglalink", cat: "sim-recharge", price: 500, stock: 999,
    images: [IMAGES["p-vivo-y28"][0]],
    rating: 4.6, reviewCount: 88, sold: 55, warrantyEn: W_DIGITAL[0], warrantyBn: W_DIGITAL[1],
    descEn: "A ৳500 Banglalink top-up for heavy users — perfect for monthly data bundles and long calls. Instant digital delivery to any Banglalink prepaid number.",
    descBn: "বেশি ব্যবহারের জন্য ৳৫০০ বাংলালিংক রিচার্জ — মাসিক ইন্টারনেট প্যাকেজ ও লম্বা কলের জন্য পারফেক্ট। যেকোনো বাংলালিংক প্রিপেইড নম্বরে সাথে সাথে ডেলিভারি।",
    specs: [
      sp("Operator", "অপারেটর", "Banglalink", "বাংলালিংক"),
      sp("Amount", "পরিমাণ", "৳500 talktime", "৳৫০০ টকটাইম"),
      sp("Delivery", "ডেলিভারি", "Instant, PIN-less", "সাথে সাথে, পিন-লেস"),
      sp("Validity", "ভ্যালিডিটি", "As per operator rules", "অপারেটরের নিয়ম অনুযায়ী"),
      sp("Warranty", "ওয়ারেন্টি", "Digital item — no warranty", "ডিজিটাল আইটেম — কোনো ওয়ারেন্টি নেই"),
    ],
    variants: [],
  },
  // ── spare parts ───────────────────────────────────────────────────────────
  {
    slug: "redmi-note-12-display", nameEn: "Redmi Note 12 Display (Original)", nameBn: "রেডমি নোট ১২ ডিসপ্লে (অরিজিনাল)",
    brand: "Xiaomi", cat: "spare-parts", price: 4200, oldPrice: 4800, stock: 6,
    images: imgs("p-display-part"),
    rating: 4.4, reviewCount: 18, sold: 35, warrantyEn: W_PART[0], warrantyBn: W_PART[1],
    descEn: "Original service-pack AMOLED display with touch panel for Redmi Note 12 (4G) — true colour and factory-level brightness. Professional installation is strongly recommended to keep warranty valid.",
    descBn: "রেডমি নোট ১২ (4G)-এর জন্য অরিজিনাল সার্ভিস-প্যাক AMOLED ডিসপ্লে ও টাচ প্যানেল — আসল রঙ ও ফ্যাক্টরি-লেভেল ব্রাইটনেস। ওয়ারেন্টি বহাল রাখতে পেশাদার ইনস্টলেশন জরুরি।",
    specs: [
      sp("Compatibility", "সামঞ্জস্যতা", "Redmi Note 12 (4G)", "রেডমি নোট ১২ (4G)"),
      sp("Type", "ধরন", "AMOLED + touch panel", "AMOLED + টাচ প্যানেল"),
      sp("Quality", "কোয়ালিটি", "Original service pack", "অরিজিনাল সার্ভিস প্যাক"),
      sp("Installation", "ইনস্টলেশন", "Professional installation recommended", "পেশাদার ইনস্টলেশন করানো উত্তম"),
      sp("Warranty", "ওয়ারেন্টি", "3 months service warranty", "৩ মাসের সার্ভিস ওয়ারেন্টি"),
    ],
    variants: [],
  },
  {
    slug: "iphone-11-battery", nameEn: "iPhone 11 Battery (Original)", nameBn: "আইফোন ১১ ব্যাটারি (অরিজিনাল)",
    brand: "Apple", cat: "spare-parts", price: 3500, stock: 8,
    images: imgs("p-battery"),
    rating: 4.3, reviewCount: 14, sold: 28, warrantyEn: W_PART[0], warrantyBn: W_PART[1],
    descEn: "Genuine-grade 0-cycle replacement battery for iPhone 11 with 3110mAh capacity — restore that like-new backup. Free installation is available at our Dhaka service counter.",
    descBn: "আইফোন ১১-এর জন্য জেনুইন-গ্রেড ০-সাইকেল রিপ্লেসমেন্ট ব্যাটারি, ৩১১০ mAh ক্যাপাসিটি — নতুনের মতো ব্যাকআপ ফিরে পান। আমাদের ঢাকা সার্ভিস কাউন্টারে ফ্রি ইনস্টলেশন।",
    specs: [
      sp("Compatibility", "সামঞ্জস্যতা", "iPhone 11", "আইফোন ১১"),
      sp("Capacity", "ক্যাপাসিটি", "3110mAh, 0-cycle cell", "৩১১০ mAh, ০-সাইকেল সেল"),
      sp("Quality", "কোয়ালিটি", "Genuine grade, built-in IC", "জেনুইন গ্রেড, বিল্ট-ইন IC"),
      sp("Installation", "ইনস্টলেশন", "Free at our Dhaka service counter", "ঢাকা সার্ভিস কাউন্টারে ফ্রি"),
      sp("Warranty", "ওয়ারেন্টি", "3 months service warranty", "৩ মাসের সার্ভিস ওয়ারেন্টি"),
    ],
    variants: [],
  },
];

// ── reviews (16 total across the top-10 products) ───────────────────────────
const REVIEWS: { slug: string; name: string; rating: number; comment: string; days: number }[] = [
  { slug: "samsung-galaxy-a16-5g", name: "Rahim Uddin", rating: 5, comment: "Original product with box seal intact. Delivery was super fast, got it the next morning. Highly recommended!", days: 4 },
  { slug: "samsung-galaxy-a16-5g", name: "Nusrat Jahan", rating: 4, comment: "Camera quality is really good for the price, but battery drains a bit faster on 90Hz. Overall satisfied.", days: 9 },
  { slug: "samsung-galaxy-a16-5g", name: "Sharmin Sultana", rating: 5, comment: "আগেরবারও এখান থেকে কিনেছি, সার্ভিস একদম ফার্স্ট ক্লাস। প্রোডাক্ট অরিজিনাল, প্যাকেজিংও দারুণ।", days: 15 },
  { slug: "redmi-note-14", name: "Tanvir Ahmed", rating: 5, comment: "প্যাকেজিং দারুণ ছিল, অরিজিনাল প্রোডাক্ট। Arpon Telecom থেকে নিশ্চিন্তে কিনতে পারবেন।", days: 2 },
  { slug: "redmi-note-14", name: "Mitu Akter", rating: 5, comment: "The 120Hz AMOLED display is stunning at this price. Flash deal e peyechi, taka bachche!", days: 6 },
  { slug: "redmi-note-14", name: "Imran Khan", rating: 5, comment: "Fast delivery inside Dhaka — ordered at night, got it within 24 hours. Sealed box, genuine product.", days: 11 },
  { slug: "realme-c75", name: "Sabbir Hossain", rating: 4, comment: "Value for money phone. Battery lasts two days easily. Delivery took 2 days outside Dhaka.", days: 7 },
  { slug: "oppo-a60", name: "Farhana Islam", rating: 4, comment: "ভালো ফোন, ডিজাইন সুন্দর। তবে চার্জার বক্সের ভেতরে দেওয়া নেই, আলাদা কিনতে হয়েছে।", days: 12 },
  { slug: "vivo-y28-5g", name: "Kamal Hossain", rating: 5, comment: "Battery backup excellent — 2 din porjonto charge dite hoy na! Network 5G is stable in Dhaka.", days: 5 },
  { slug: "infinix-hot-50-pro-plus", name: "Sumaiya Akter", rating: 4, comment: "এই দামে কার্ভড AMOLED আর ২৫৬ জিবি স্টোরেজ অসাধারণ। ডেলিভারিও দ্রুত ছিল।", days: 3 },
  { slug: "iphone-13-128gb", name: "Jahid Hasan", rating: 5, comment: "Genuine product with official warranty card. Seal box was intact. Trustworthy seller, will buy again.", days: 8 },
  { slug: "iphone-13-128gb", name: "Mizanur Rahman", rating: 5, comment: "Best price for iPhone 13 in BD right now. Customer support helped me track the order the whole way.", days: 20 },
  { slug: "symphony-g96", name: "Rupali Begum", rating: 4, comment: "বাজেট ফোন হিসেবে খুব ভালো। সাউন্ড কোয়ালিটি মোটামুটি, ডিসপ্লে বড় আর সুন্দর।", days: 10 },
  { slug: "nokia-105-2023", name: "Abdul Karim", rating: 5, comment: "আমার বাবার জন্য কিনেছি। ব্যাটারি অসাধারণ — এক চার্জে প্রায় দুই সপ্তাহ চলে!", days: 6 },
  { slug: "walton-xolon-x20", name: "Mahmudul Hasan", rating: 4, comment: "Budget friendly phone, camera is average but fine for the price. Waiting for restock to buy one more.", days: 14 },
  { slug: "symphony-l280", name: "Halima Begum", rating: 5, comment: "চাচার জন্য কিনেছি, বাটন বড় তাই চাপতে সুবিধা। টর্চ আর এফএম ফিচারটা পছন্দ হয়েছে।", days: 9 },
];

const COUPONS = [
  { code: "ARPON10", type: "percent", value: 10, minSubtotal: 5000, active: true },
  { code: "SAVE300", type: "fixed", value: 300, minSubtotal: 3000, active: true },
];

const SUBSCRIBERS = [
  "rakib.hasan@gmail.com",
  "nusrat.jahan@yahoo.com",
  "tanvir.ahmed@outlook.com",
  "mitu.akter@gmail.com",
  "sabbir.hossain@gmail.com",
  "farhana.islam@yahoo.com",
];

// ── main ────────────────────────────────────────────────────────────────────
async function main() {
  console.log("🌱 Seeding Arpon Telecom …");

  // wipe (FK-safe order)
  await db.orderItem.deleteMany();
  await db.order.deleteMany();
  await db.review.deleteMany();
  await db.product.deleteMany();
  await db.category.deleteMany();
  await db.coupon.deleteMany();
  await db.subscriber.deleteMany();
  await db.contactMessage.deleteMany();

  // categories
  const catIds = new Map<string, string>();
  for (let i = 0; i < CATEGORIES.length; i++) {
    const c = await db.category.create({
      data: { ...CATEGORIES[i], order: i + 1 },
    });
    catIds.set(c.slug, c.id);
  }

  // products
  const flashEndsAt = new Date(Date.now() + 36 * 60 * 60 * 1000);
  const productIds = new Map<string, string>();
  for (const p of PRODUCTS) {
    const created = await db.product.create({
      data: {
        slug: p.slug,
        nameEn: p.nameEn,
        nameBn: p.nameBn,
        brand: p.brand,
        categoryId: catIds.get(p.cat)!,
        price: p.price,
        oldPrice: p.oldPrice ?? null,
        stock: p.stock,
        stockStatus: p.stockStatus ?? "in_stock",
        images: JSON.stringify(p.images),
        specs: JSON.stringify(p.specs),
        variants: JSON.stringify(p.variants),
        ram: p.ram ?? null,
        storage: p.storage ?? null,
        rating: p.rating,
        reviewCount: p.reviewCount,
        isFlash: !!p.flash,
        flashEndsAt: p.flash ? flashEndsAt : null,
        isNew: !!p.fresh,
        isBestSeller: !!p.best,
        warrantyEn: p.warrantyEn,
        warrantyBn: p.warrantyBn,
        descriptionEn: p.descEn,
        descriptionBn: p.descBn,
        soldCount: p.sold,
      },
    });
    productIds.set(p.slug, created.id);
  }

  // reviews
  for (const r of REVIEWS) {
    await db.review.create({
      data: {
        productId: productIds.get(r.slug)!,
        name: r.name,
        rating: r.rating,
        comment: r.comment,
        createdAt: daysAgo(r.days),
      },
    });
  }

  // coupons
  for (const c of COUPONS) await db.coupon.create({ data: c });

  // subscribers
  for (const email of SUBSCRIBERS) {
    await db.subscriber.create({ data: { email } });
  }

  console.log(`✅ Seed complete:
   • ${CATEGORIES.length} categories
   • ${PRODUCTS.length} products
   • ${REVIEWS.length} reviews
   • ${COUPONS.length} coupons
   • ${SUBSCRIBERS.length} subscribers`);
}

main()
  .catch((e) => {
    console.error("❌ Seed failed:", e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
