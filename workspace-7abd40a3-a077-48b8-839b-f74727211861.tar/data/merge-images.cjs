// Merge image-search results into slug -> url mapping
import fs from "fs";
const path = "/home/z/my-project/data/img/";
const out = {};
const files = fs.readdirSync(path).filter((f) => f.endsWith(".json"));
for (const f of files) {
  const raw = fs.readFileSync(path + f, "utf8");
  const start = raw.indexOf("{");
  if (start < 0) continue;
  try {
    const data = JSON.parse(raw.slice(start));
    if (data.success && data.results && data.results.length > 0) {
      const slug = f.replace(".json", "");
      // prefer landscape-ish or first; just take first 2 URLs
      out[slug] = data.results.slice(0, 2).map((r) => r.original_url);
    }
  } catch (e) {
    console.error("parse fail:", f);
  }
}
fs.writeFileSync("/home/z/my-project/data/images.json", JSON.stringify(out, null, 2));
console.log("mapped", Object.keys(out).length, "slugs");
for (const k of Object.keys(out)) console.log(k, "→", out[k][0]);
