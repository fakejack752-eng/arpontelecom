#!/bin/bash
# Batch image search for Arpon Telecom — stdout-based (CLI -o flag is unreliable)
cd /home/z/my-project/data/img
: > fails.txt

cat > queries.txt << 'EOF'
banner-1|smartphone sale promotion banner design with mobile phone on orange background
banner-2|mobile phone flash sale banner dark background glowing smartphone
banner-3|electronics gadgets mega offer sale banner with phones and accessories
p-samsung-a16|Samsung Galaxy A16 5G smartphone official product photo
p-redmi-note-14|Xiaomi Redmi Note 14 smartphone official product photo
p-realme-c75|realme C75 smartphone official product photo
p-oppo-a60|OPPO A60 smartphone official product photo
p-vivo-y28|vivo Y28 5G smartphone official product photo
p-infinix-hot-50|Infinix Hot 50 Pro Plus smartphone official product photo
p-iphone-13|Apple iPhone 13 official product photo
p-symphony|Symphony smartphone Bangladesh official product photo
p-walton|Walton smartphone Bangladesh official product photo
p-nokia-105|Nokia 105 feature phone official product photo
p-tab-a9|Samsung Galaxy Tab A9 Plus tablet official product photo
p-walton-tab|budget android tablet product photo white background
p-anker-charger|Anker 20W USB C wall charger official product photo
p-baseus-cable|Baseus braided USB Type-C charging cable product photo
p-redmi-buds|Xiaomi Redmi Buds 5 true wireless earbuds product photo
p-neckband|wireless bluetooth neckband earphones product photo
p-anker-powercore|Anker PowerCore 10000 power bank official product photo
p-xiaomi-powerbank|Xiaomi power bank 20000mAh product photo
p-amazfit-bip5|Amazfit Bip 5 smartwatch official product photo
p-redmi-watch|Xiaomi Redmi Watch smartwatch product photo
p-spigen-case|Spigen phone back case cover product photo
p-glass|tempered glass screen protector for smartphone product photo
p-display-part|mobile phone LCD display screen replacement part product photo
p-battery|mobile phone battery replacement part product photo
EOF

cat queries.txt | xargs -P 6 -I {} bash -c '
  IFS="|" read -r slug query <<< "{}"
  out="/home/z/my-project/data/img/$slug.json"
  if [ ! -s "$out" ]; then
    z-ai image-search -q "$query" -c 3 --gl us --no-rank > "$out" 2>/dev/null
    if ! grep -q "\"success\": true" "$out"; then echo "$slug" >> /home/z/my-project/data/img/fails.txt; fi
  fi
'
echo "DONE $(date)" >> /home/z/my-project/data/img/fetch-status.txt
