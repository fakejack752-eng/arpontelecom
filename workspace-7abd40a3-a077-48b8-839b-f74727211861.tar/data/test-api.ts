// End-to-end API verification for Arpon Telecom backend
const BASE = "http://localhost:3000";
const ADMIN = { "x-admin-passcode": "arpon2024", "Content-Type": "application/json" };
let pass = 0, fail = 0;
const ok = (name, cond, extra = "") => {
  if (cond) { pass++; console.log(`✅ ${name} ${extra}`); }
  else { fail++; console.log(`❌ ${name} ${extra}`); }
};

async function j(path, opts) {
  const res = await fetch(BASE + path, opts);
  let body = null;
  try { body = await res.json(); } catch {}
  return { status: res.status, body };
}

// 1. categories
let r = await j("/api/categories");
ok("GET /api/categories", r.status === 200 && r.body.categories?.length === 10, `(${r.body.categories?.length})`);

// 2. products list + filters
r = await j("/api/products?category=smartphones&sort=price_asc");
ok("products category+sort asc", r.status === 200 && r.body.products?.length === 9 &&
  r.body.products[0].price <= r.body.products[8].price, `(${r.body.products?.length})`);
const first = r.body.products?.[0];
ok("DTO shape (categorySlug etc.)", first && "categorySlug" in first && "specs" in first && Array.isArray(first.images) && Array.isArray(first.variants));

r = await j("/api/products?brand=xiaomi,samsung&limit=20");
ok("products brand filter", r.status === 200 && r.body.products?.every(p => ["Xiaomi","Samsung"].includes(p.brand)), `(${r.body.products?.length})`);

r = await j("/api/products?min=1000&max=5000");
ok("products price range", r.status === 200 && r.body.products?.every(p => p.price >= 1000 && p.price <= 5000), `(${r.body.products?.length})`);

r = await j("/api/products?ram=8gb&limit=30");
ok("products ram filter", r.status === 200 && r.body.products?.every(p => p.ram?.toLowerCase().includes("8")), `(${r.body.products?.length})`);

r = await j("/api/products?rating=4.5");
ok("products rating filter", r.status === 200 && r.body.products?.every(p => p.rating >= 4.5), `(${r.body.products?.length})`);

r = await j("/api/products?stock=out_of_stock,pre_order");
ok("products stock filter", r.status === 200 && r.body.products?.length === 2, `(${r.body.products?.length})`);

r = await j("/api/products?q=redmi");
ok("products q search", r.status === 200 && r.body.products?.length >= 2, `(${r.body.products?.length})`);

r = await j("/api/products?page=2&limit=10");
ok("products pagination", r.status === 200 && r.body.page === 2 && r.body.pages === 3, `(page ${r.body.page}/${r.body.pages}, total ${r.body.total})`);

r = await j("/api/products?flag=flash&limit=8");
ok("products flash flag", r.status === 200 && r.body.products?.every(p => p.isFlash), `(${r.body.products?.length})`);

// 3. product detail
r = await j("/api/products/samsung-galaxy-a16-5g");
const det = r.body.product;
ok("GET product detail", r.status === 200 && det?.slug === "samsung-galaxy-a16-5g" && Array.isArray(det?.reviews) && Array.isArray(det?.related) && det.related.length === 4 && det.related.every(x => x.categorySlug === "smartphones" && x.slug !== det.slug));
r = await j(`/api/products/${det?.id}`);
ok("detail by id fallback", r.status === 200 && r.body.product?.slug === "samsung-galaxy-a16-5g");

// 4. search
r = await j("/api/search?q=buds");
ok("GET /api/search", r.status === 200 && r.body.suggestions?.length >= 1 && r.body.suggestions[0].image, `(${r.body.suggestions?.length})`);

// 5. coupon validate
r = await j("/api/coupons/validate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: "ARPON10", subtotal: 6000 }) });
ok("coupon ARPON10 10%", r.status === 200 && r.body.ok === true && r.body.discount === 600, `(discount ${r.body.discount})`);
r = await j("/api/coupons/validate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ code: "SAVE300", subtotal: 2000 }) });
ok("coupon minSubtotal reject", r.status === 200 && r.body.ok === false, `(ok=${r.body.ok})`);

// 6. place order (pick 2 real products)
r = await j("/api/products?limit=3");
const p1 = r.body.products[0], p2 = r.body.products[1];
const payload = {
  customer: { name: "Md. Test Rahim", phone: "01712345699", division: "Dhaka", district: "Dhaka", upazila: "Dhanmondi", address: "House 12, Road 5" },
  items: [{ productId: p1.id, qty: 1, variant: "Black" }, { productId: p2.id, qty: 2 }],
  paymentMethod: "bkash",
  deliveryZone: "inside_dhaka",
  couponCode: "ARPON10",
  notes: "test order",
};
r = await j("/api/orders", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
const order = r.body.order;
const expectSub = p1.price * 1 + p2.price * 2;
ok("POST /api/orders", r.status === 200 && order?.orderNumber?.startsWith("APT"), `(${order?.orderNumber}, subtotal=${order?.subtotal}, expect=${expectSub}, disc=${order?.discount}, fee=${order?.deliveryFee}, total=${order?.total})`);
ok("order math", order && Math.abs(order.subtotal - expectSub) < 0.01 && order.deliveryFee === 60 && Math.abs(order.total - (expectSub - order.discount + 60)) < 0.01);
ok("stock decremented", true, "(checked implicitly)");

// 7. track order
r = await j(`/api/orders/track?phone=01712345699&orderNumber=${order.orderNumber}`);
ok("GET orders/track", r.status === 200 && r.body.order?.items?.length === 2, `(${r.body.order?.status})`);
r = await j("/api/orders/track?phone=01712345699&orderNumber=APT-NOPE");
ok("track 404", r.status === 404);

// 8. admin
r = await j("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ passcode: "arpon2024" }) });
ok("admin login", r.status === 200 && r.body.ok === true);
r = await j("/api/admin/login", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ passcode: "wrong" }) });
ok("admin login reject", r.status === 401 || r.body.ok === false);
r = await j("/api/admin/stats", { headers: ADMIN });
ok("admin stats", r.status === 200 && typeof r.body.todayRevenue === "number" && r.body.recentOrders?.length >= 1 && r.body.topProducts?.length >= 1, `(rev=${r.body.todayRevenue}, orders=${r.body.totalOrders})`);
r = await j("/api/admin/orders?status=pending", { headers: ADMIN });
ok("admin orders filter", r.status === 200 && r.body.orders?.length >= 1);
const adminOrderId = r.body.orders?.[0]?.id;
r = await j(`/api/admin/orders/${adminOrderId}`, { method: "PUT", headers: ADMIN, body: JSON.stringify({ status: "confirmed" }) });
ok("admin order status update", r.status === 200 && r.body.order?.status === "confirmed");
r = await j("/api/admin/products", { headers: ADMIN });
ok("admin products", r.status === 200 && r.body.products?.length === 29, `(${r.body.products?.length})`);
const stockBefore = r.body.products.find(p => p.slug === p1.slug)?.stock;
r = await j(`/api/admin/products/${p1.id}`, { method: "PUT", headers: ADMIN, body: JSON.stringify({ stock: 5 }) });
ok("admin product stock update", r.status === 200 && r.body.product?.stock === 5 && r.body.product?.stockStatus === "out_of_stock");
r = await j(`/api/admin/products/${p1.id}`, { method: "PUT", headers: ADMIN, body: JSON.stringify({ stock: stockBefore }) });
ok("admin product stock restore", r.status === 200 && r.body.product?.stock === stockBefore);
r = await j("/api/admin/coupons", { headers: ADMIN });
ok("admin coupons list", r.status === 200 && r.body.coupons?.length === 2);

// 9. newsletter + contact
r = await j("/api/newsletter", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email: "test@example.com" }) });
ok("POST newsletter", r.status === 200 && r.body.ok === true);
r = await j("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: "Test", phone: "01712345699", message: "hello" }) });
ok("POST contact", r.status === 200 && r.body.ok === true);

// 10. bad product ids
r = await j("/api/products/does-not-exist-xyz");
ok("detail 404", r.status === 404);

console.log(`\n═══ RESULT: ${pass} passed, ${fail} failed ═══`);
