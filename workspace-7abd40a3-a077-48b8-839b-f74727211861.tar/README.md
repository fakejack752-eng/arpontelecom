# Arpon Telecom — E-commerce (arpontelecom.store)

Full e-commerce SPA for **Arpon Telecom**, a mobile phone & telecom accessories retailer in Bangladesh.
Built with **Next.js 16 (App Router) · TypeScript · Tailwind CSS 4 · shadcn/ui · Prisma + SQLite · Zustand**.

## Features

- **Home**: hero slider, 10-category grid, Flash Deals with live countdown, New Arrivals, Best Sellers, Shop-by-Brand, Why-Choose-Us, customer reviews, newsletter signup
- **Shop**: brand/price/RAM/storage/rating/availability filters, 5 sort modes, grid/list toggle, pagination
- **Product page**: hover-zoom gallery, color/storage variants, specs table, reviews, related products, warranty & delivery info
- **Cart & guest checkout**: coupon codes (ARPON10 = 10% over ৳5,000, SAVE300 = ৳300 off over ৳3,000), division/district selects, delivery zones (Dhaka ৳60 / outside ৳120), COD / bKash / Nagad / Rocket / Card
- **Order tracking** by phone + order number, **Admin panel** (dashboard, orders, products, coupons), **mobile recharge (demo)**, **blog**, and bilingual (EN/বাংলা) UI throughout
- Floating WhatsApp + Call buttons, live product search, wishlist, compare (up to 3), trust badges

## Run locally

```bash
bun install
bun run db:push        # create tables (DATABASE_URL in .env → db/custom.db)
bun prisma/seed.ts     # 28 products, 10 categories, reviews, coupons
bun run dev            # http://localhost:3000
```

## Admin panel

Open the site → footer **Quick Links → Admin** (or Home → any page → Admin). Demo passcode: **`arpon2024`**.

- **Dashboard**: today/month revenue, order counts, low-stock alerts, top sellers, recent orders
- **Orders**: filter by status, change status per row (pending → confirmed → shipped → delivered/cancelled) — customers see the same status on the tracking page
- **Products**: add products (dialog), edit stock inline, delete; stock 0 auto-marks *Out of Stock*
- **Coupons**: add percent/fixed coupons with minimum subtotal

## Deployment

### Vercel (recommended)
1. Push the repo to GitHub.
2. Import into Vercel → framework auto-detected (Next.js).
3. **Switch the database**: SQLite is for local/demo. Use a managed Postgres (Neon/Supabase) — change `prisma/schema.prisma` `provider = "postgresql"`, set `DATABASE_URL`, run `bunx prisma db push`, re-seed.
4. Build command `next build`, output auto. Add env vars (`DATABASE_URL`). Set domain `arpontelecom.store`.

### cPanel / VPS (Node.js app)
1. `bun install && bun run build`
2. Start with `bun run start` (standalone server) behind cPanel's Node.js selector or Nginx reverse proxy.
3. Keep `db/custom.db` on persistent storage; schedule offsite backups (it's a file).
4. For real payments, wire **SSLCommerz** in `src/app/api/orders/route.ts` (record method + add a redirect step), and replace the demo recharge flow.

### Go-live checklist
- Change the admin passcode (server-side check in `src/app/api/admin/login/route.ts` + `ADMIN_HEADER` in `src/lib/api.ts`) and put it behind env vars.
- Add real WhatsApp/hotline numbers (`src/lib/store.ts`: `WHATSAPP_NUMBER`, `HOTLINE_NUMBER`).
- Update address/social links in `src/components/store/footer.tsx`.
- Add Google Analytics 4 / Meta Pixel snippets in `src/app/layout.tsx`.
- Point `arpontelecom.store` DNS to the host; HTTPS is automatic on Vercel (enable AutoSSL on cPanel).

## Managing products without code

Use **Admin → Products → Add Product** (name EN/BN, brand, category, price, old price, stock, description). For bulk/seed edits, modify `prisma/seed.ts` and re-run `bun prisma/seed.ts` (idempotent — replaces catalog data).
