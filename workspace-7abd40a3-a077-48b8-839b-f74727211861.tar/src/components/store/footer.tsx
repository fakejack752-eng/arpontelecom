"use client";
// ─── Arpon Telecom — site footer ────────────────────────────────────────────
import { useEffect, useState } from "react";
import {
  Facebook,
  Instagram,
  Mail,
  MapPin,
  Music2,
  Phone,
  Smartphone,
  Youtube,
} from "lucide-react";

import { getJSON } from "@/lib/api";
import { useT } from "@/lib/i18n";
import { HOTLINE_NUMBER, useStore, type View } from "@/lib/store";
import type { CategoryDTO } from "@/lib/types";

const EMAIL = "support@arpontelecom.store";

const SOCIALS = [
  { label: "Facebook", Icon: Facebook },
  { label: "Instagram", Icon: Instagram },
  { label: "YouTube", Icon: Youtube },
  { label: "TikTok", Icon: Music2 },
];

const PAYMENTS = [
  { label: "bKash", bg: "#E2136E" },
  { label: "Nagad", bg: "#F6921E" },
  { label: "Rocket", bg: "#8C3494" },
  { label: "Visa", bg: "#1A1F71" },
  { label: "Mastercard", bg: "#EB001B" },
  { label: "COD", bg: "#16A34A" },
];

export default function Footer() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const navigate = useStore((s) => s.navigate);
  const [categories, setCategories] = useState<CategoryDTO[]>([]);

  useEffect(() => {
    let cancelled = false;
    getJSON<{ categories: CategoryDTO[] }>("/api/categories")
      .then((d) => {
        if (!cancelled) setCategories((d.categories ?? []).slice(0, 9));
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  const quickLinks: { label: string; view: View }[] = [
    { label: t("nav_about"), view: { name: "page", slug: "about" } },
    { label: t("nav_contact"), view: { name: "page", slug: "contact" } },
    { label: t("nav_faq"), view: { name: "page", slug: "faq" } },
    { label: t("nav_warranty"), view: { name: "page", slug: "warranty" } },
    { label: t("nav_privacy"), view: { name: "page", slug: "privacy" } },
    { label: t("nav_terms"), view: { name: "page", slug: "terms" } },
    { label: t("nav_blog"), view: { name: "blog" } },
    { label: t("nav_track"), view: { name: "tracking" } },
    { label: t("nav_recharge"), view: { name: "recharge" } },
    { label: t("nav_admin"), view: { name: "admin" } },
  ];

  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="mx-auto max-w-7xl px-4 py-12">
        <div className="grid gap-8 md:grid-cols-4">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10">
                <Smartphone className="h-5 w-5" aria-hidden="true" />
              </span>
              <span className="text-[15px] font-bold">{t("brandName")}</span>
            </div>
            <p className="mt-3 text-sm leading-relaxed text-white/80">
              {t("footerAbout")}
            </p>
            <ul className="mt-4 space-y-2.5 text-sm text-white/80">
              <li className="flex items-start gap-2">
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-white/60" aria-hidden="true" />
                <span>{t("shopAddress")}</span>
              </li>
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 shrink-0 text-white/60" aria-hidden="true" />
                <a
                  href={`tel:${HOTLINE_NUMBER.replace(/-/g, "")}`}
                  className="transition-colors hover:text-white"
                >
                  {HOTLINE_NUMBER}
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="h-4 w-4 shrink-0 text-white/60" aria-hidden="true" />
                <a href={`mailto:${EMAIL}`} className="transition-colors hover:text-white">
                  {EMAIL}
                </a>
              </li>
            </ul>
          </div>

          {/* Quick links */}
          <nav aria-label={t("quickLinks")}>
            <h3 className="text-sm font-semibold tracking-wide uppercase">
              {t("quickLinks")}
            </h3>
            <ul className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 text-sm md:grid-cols-1">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <button
                    type="button"
                    onClick={() => navigate(link.view)}
                    className="text-white/80 transition-colors hover:text-white"
                  >
                    {link.label}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Categories */}
          <nav aria-label={t("ourCategories")}>
            <h3 className="text-sm font-semibold tracking-wide uppercase">
              {t("ourCategories")}
            </h3>
            <ul className="mt-4 space-y-2 text-sm">
              {categories.map((c) => (
                <li key={c.id}>
                  <button
                    type="button"
                    onClick={() => navigate({ name: "shop", category: c.slug })}
                    className="text-white/80 transition-colors hover:text-white"
                  >
                    {lang === "bn" ? c.nameBn : c.nameEn}
                  </button>
                </li>
              ))}
            </ul>
          </nav>

          {/* Social + payments */}
          <div>
            <h3 className="text-sm font-semibold tracking-wide uppercase">
              {t("followUs")}
            </h3>
            <div className="mt-4 flex gap-2">
              {SOCIALS.map(({ label, Icon }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10 transition-colors hover:bg-white/20"
                >
                  <Icon className="h-4 w-4" aria-hidden="true" />
                </a>
              ))}
            </div>

            <h3 className="mt-6 text-sm font-semibold tracking-wide uppercase">
              {t("paymentMethods")}
            </h3>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {PAYMENTS.map((p) => (
                <span
                  key={p.label}
                  style={{ backgroundColor: p.bg }}
                  className="rounded px-2 py-1 text-[10px] font-semibold text-white"
                >
                  {p.label}
                </span>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-10 flex flex-col items-center justify-between gap-2 border-t border-white/15 pt-5 text-xs text-white/70 sm:flex-row">
          <p>{t("copyright")}</p>
          <p>{t("madeWith")}</p>
        </div>
      </div>
    </footer>
  );
}
