"use client";
// ─── Arpon Telecom — home: flash deals (countdown + scroll row) ─────────────
import { useEffect, useMemo, useState } from "react";
import { Zap } from "lucide-react";

import { useT } from "@/lib/i18n";
import type { ProductDTO } from "@/lib/types";
import { ProductCard } from "../product-card";

const pad2 = (n: number) => String(n).padStart(2, "0");

export default function FlashDeals({ products }: { products: ProductDTO[] }) {
  const t = useT();

  // Countdown target = soonest flashEndsAt among flash products;
  // fallback (none upcoming) = next midnight.
  const target = useMemo(() => {
    const times = products
      .map((p) => (p.flashEndsAt ? new Date(p.flashEndsAt).getTime() : NaN))
      .filter((n) => Number.isFinite(n));
    const soonest = times.length ? Math.min(...times) : NaN;
    if (Number.isFinite(soonest) && soonest > Date.now()) return soonest;
    const midnight = new Date();
    midnight.setHours(24, 0, 0, 0);
    return midnight.getTime();
  }, [products]);

  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  if (!products.length) return null;

  const diff = Math.max(0, target - now);
  const hh = Math.floor(diff / 3_600_000);
  const mm = Math.floor((diff % 3_600_000) / 60_000);
  const ss = Math.floor((diff % 60_000) / 1000);

  const boxCls =
    "rounded-lg bg-primary px-2 py-1 font-mono text-sm font-bold tabular-nums text-white sm:text-base";

  return (
    <section aria-label={t("section_flash")}>
      <div className="rounded-2xl border border-cta/20 bg-gradient-to-r from-cta/10 via-orange-50 to-background p-4 sm:p-6">
        {/* Header: title + OFF chip | countdown */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex min-w-0 items-center gap-2.5">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-cta/15">
              <Zap className="h-5 w-5 fill-cta text-cta" aria-hidden="true" />
            </span>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-xl font-bold text-foreground md:text-2xl">
                  {t("section_flash")}
                </h2>
                <span className="rounded-full bg-cta px-2.5 py-0.5 text-[11px] font-bold text-white shadow-sm">
                  🔥 {t("flash_up_to_off")}
                </span>
              </div>
              <p className="mt-0.5 text-sm text-muted-foreground">
                {t("section_flash_sub")}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground sm:text-sm">
              {t("section_flash_ends")}
            </span>
            <div
              className="flex items-center gap-1"
              role="timer"
              aria-live="off"
              aria-label={t("section_flash_ends")}
            >
              <span className={boxCls}>{pad2(hh)}</span>
              <span className="font-bold text-primary" aria-hidden="true">:</span>
              <span className={boxCls}>{pad2(mm)}</span>
              <span className="font-bold text-primary" aria-hidden="true">:</span>
              <span className={boxCls}>{pad2(ss)}</span>
            </div>
          </div>
        </div>

        {/* Horizontal scroll row of deal cards */}
        <div className="no-scrollbar -mx-1 mt-4 flex snap-x gap-3 overflow-x-auto px-1 pb-2">
          {products.map((p) => (
            <div key={p.id} className="w-40 shrink-0 snap-start sm:w-48">
              <ProductCard product={p} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
