"use client";
// ─── Arpon Telecom — home hero slider (3 auto-rotating banners) ─────────────
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import { cn } from "@/lib/utils";

const SLIDES = [
  {
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/6a5c84a277dc.jpg",
    badgeKey: "hero1_badge",
    titleKey: "hero1_title",
    subKey: "hero1_sub",
    ctaKey: "hero1_cta",
  },
  {
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/8064edbd75d1.jpg",
    badgeKey: "hero2_badge",
    titleKey: "hero2_title",
    subKey: "hero2_sub",
    ctaKey: "hero2_cta",
  },
  {
    image: "https://z-cdn.chatglm.cn/image-search-mcp/images-ppt/5d8080d63178.jpg",
    badgeKey: "hero3_badge",
    titleKey: "hero3_title",
    subKey: "hero3_sub",
    ctaKey: "hero3_cta",
  },
] as const;

const AUTOPLAY_MS = 5000;

export default function HeroSlider() {
  const t = useT();
  const navigate = useStore((s) => s.navigate);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  // Auto-advance every 5s (timer resets after manual nav; paused on hover).
  useEffect(() => {
    if (paused) return;
    const id = setInterval(
      () => setIndex((i) => (i + 1) % SLIDES.length),
      AUTOPLAY_MS
    );
    return () => clearInterval(id);
  }, [paused, index]);

  const go = (dir: 1 | -1) =>
    setIndex((i) => (i + dir + SLIDES.length) % SLIDES.length);

  const slide = SLIDES[index];

  return (
    <section
      aria-roledescription="carousel"
      aria-label={t("featuredOffers")}
      className="relative h-[220px] w-full overflow-hidden rounded-2xl bg-primary shadow-md sm:h-[300px] md:h-[380px]"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <AnimatePresence initial={false}>
        <motion.div
          key={index}
          initial={{ opacity: 0, x: 60 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -60 }}
          transition={{ duration: 0.45, ease: "easeInOut" }}
          className="absolute inset-0"
        >
          <img
            src={slide.image}
            alt={t(slide.titleKey)}
            loading={index === 0 ? "eager" : "lazy"}
            decoding="async"
            draggable={false}
            className="pointer-events-none absolute inset-0 h-full w-full object-cover select-none"
          />
          {/* Legibility overlay */}
          <div
            className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent"
            aria-hidden="true"
          />
          {/* Copy */}
          <div className="absolute inset-0 flex items-center">
            <div className="max-w-xl px-5 sm:px-10">
              <span className="inline-block rounded-full bg-cta px-3 py-1 text-[11px] font-bold tracking-wide text-cta-foreground uppercase shadow-sm sm:text-xs">
                {t(slide.badgeKey)}
              </span>
              <h2 className="mt-2 text-2xl leading-tight font-extrabold text-white sm:text-4xl md:text-5xl">
                {t(slide.titleKey)}
              </h2>
              <p className="mt-1.5 text-sm text-white/90 sm:text-base">
                {t(slide.subKey)}
              </p>
              <Button
                onClick={() => navigate({ name: "shop" })}
                className="mt-3 h-10 rounded-full bg-cta px-6 font-semibold text-cta-foreground shadow-lg hover:bg-cta/90 sm:mt-4 sm:h-11"
              >
                {t(slide.ctaKey)}
              </Button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Prev / Next (md+ only) */}
      <button
        type="button"
        aria-label={t("prev")}
        onClick={() => go(-1)}
        className="absolute top-1/2 left-3 z-10 hidden h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/30 text-white backdrop-blur-sm transition hover:bg-white/50 md:flex"
      >
        <ChevronLeft className="h-6 w-6" aria-hidden="true" />
      </button>
      <button
        type="button"
        aria-label={t("next")}
        onClick={() => go(1)}
        className="absolute top-1/2 right-3 z-10 hidden h-10 w-10 -translate-y-1/2 items-center justify-center rounded-full bg-white/30 text-white backdrop-blur-sm transition hover:bg-white/50 md:flex"
      >
        <ChevronRight className="h-6 w-6" aria-hidden="true" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-3 left-1/2 z-10 flex -translate-x-1/2 items-center gap-1.5">
        {SLIDES.map((s, i) => (
          <button
            key={s.image}
            type="button"
            aria-label={`${t("goToSlide")} ${i + 1}`}
            aria-current={i === index}
            onClick={() => setIndex(i)}
            className={cn(
              "h-2 rounded-full transition-all duration-300",
              i === index
                ? "w-6 bg-cta"
                : "w-2 bg-white/50 hover:bg-white/80"
            )}
          />
        ))}
      </div>
    </section>
  );
}
