"use client";
// ─── Arpon Telecom — home: newsletter subscribe block ───────────────────────
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { postJSON } from "@/lib/api";
import { useT } from "@/lib/i18n";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Newsletter() {
  const t = useT();
  const [email, setEmail] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting) return;

    if (!EMAIL_RE.test(email.trim())) {
      toast.error(t("subscribeFailed"));
      return;
    }

    setSubmitting(true);
    try {
      await postJSON("/api/newsletter", { email: email.trim() });
      toast.success(t("subscribed"));
      setEmail("");
    } catch (err) {
      console.error("Newsletter subscribe failed:", err);
      toast.error(t("subscribeFailed"));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <section aria-label={t("section_newsletter")}>
      <div className="relative overflow-hidden rounded-2xl bg-primary p-6 text-center text-primary-foreground sm:p-10">
        {/* Decorative circles */}
        <div
          className="absolute -top-16 -left-16 h-48 w-48 rounded-full bg-white/5"
          aria-hidden="true"
        />
        <div
          className="absolute -right-12 -bottom-20 h-64 w-64 rounded-full bg-white/5"
          aria-hidden="true"
        />
        <div
          className="absolute top-6 right-10 h-16 w-16 rounded-full bg-white/5"
          aria-hidden="true"
        />

        <div className="relative">
          <h2 className="text-xl font-bold sm:text-2xl">
            {t("section_newsletter")}
          </h2>
          <p className="mt-2 text-sm opacity-90">
            {t("section_newsletter_sub")}
          </p>

          <form
            onSubmit={handleSubmit}
            noValidate
            className="mx-auto mt-4 flex max-w-md flex-col gap-2 sm:flex-row"
          >
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={t("emailPlaceholder")}
              aria-label={t("emailPlaceholder")}
              className="h-11 flex-1 rounded-full border-transparent bg-white/95 text-foreground shadow-none placeholder:text-muted-foreground"
            />
            <Button
              type="submit"
              disabled={submitting}
              className="h-11 rounded-full bg-cta px-6 font-semibold text-cta-foreground hover:bg-cta/90"
            >
              {t("subscribe")}
            </Button>
          </form>
        </div>
      </div>
    </section>
  );
}
