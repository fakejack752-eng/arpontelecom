"use client";
// ─── Arpon Telecom — home: why choose us trust cards ────────────────────────
import { BadgeCheck, RefreshCcw, ShieldCheck, Truck, type LucideIcon } from "lucide-react";

import { useT } from "@/lib/i18n";
import { SectionHeading } from "../section-heading";

const ITEMS: { icon: LucideIcon; titleKey: string; descKey: string }[] = [
  { icon: BadgeCheck, titleKey: "why_genuine", descKey: "why_genuine_desc" },
  { icon: ShieldCheck, titleKey: "why_warranty", descKey: "why_warranty_desc" },
  { icon: Truck, titleKey: "why_delivery", descKey: "why_delivery_desc" },
  { icon: RefreshCcw, titleKey: "why_return", descKey: "why_return_desc" },
];

export default function WhyChooseUs() {
  const t = useT();

  return (
    <section aria-label={t("section_why")}>
      <SectionHeading titleKey="section_why" subtitleKey="section_why_sub" />
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
        {ITEMS.map(({ icon: Icon, titleKey, descKey }) => (
          <div
            key={titleKey}
            className="flex flex-col items-center gap-2 rounded-xl border bg-card p-4 text-center shadow-xs sm:gap-3 sm:p-6"
          >
            <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-cta/10 text-cta">
              <Icon className="h-6 w-6" aria-hidden="true" />
            </span>
            <h3 className="text-sm font-semibold text-foreground sm:text-base">
              {t(titleKey)}
            </h3>
            <p className="text-xs text-muted-foreground sm:text-sm">
              {t(descKey)}
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
