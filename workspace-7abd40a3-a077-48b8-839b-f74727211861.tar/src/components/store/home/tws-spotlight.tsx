"use client";
// ─── Arpon Telecom — TWS SPOTLIGHT (promotional section w/ custom image) ─────
import { motion, useReducedMotion } from "framer-motion";
import { CheckCircle2, ShieldCheck, ArrowRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";

const FEATURES = ["spotlight_f1", "spotlight_f2", "spotlight_f3"] as const;

const listVariants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.25 } },
};

const itemVariants = {
  hidden: { opacity: 0, x: 24 },
  show: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.45, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function TwsSpotlight() {
  const t = useT();
  const navigate = useStore((s) => s.navigate);
  const reduceMotion = useReducedMotion();

  // Respect users who prefer reduced motion — no directional slides.
  const dir = reduceMotion ? { x: 0 } : { x: -48 };
  const dirR = reduceMotion ? { x: 0 } : { x: 48 };

  return (
    <section
      aria-labelledby="tws-spotlight-title"
      className="overflow-hidden rounded-2xl bg-gradient-to-br from-[#0B3D91] via-[#10459f] to-[#062a68] text-white shadow-lg sm:rounded-3xl"
    >
      <div className="grid items-center gap-6 p-5 sm:p-8 lg:grid-cols-2 lg:gap-10 lg:p-10">
        {/* Image side — slides in from the left */}
        <motion.div
          className="relative order-1"
          initial={{ opacity: 0, ...dir }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
        >
          {/* soft glow behind the photo */}
          <div
            aria-hidden="true"
            className="absolute -inset-4 rounded-[2rem] bg-[#FF7A00]/20 blur-2xl"
          />
          <div className="relative overflow-hidden rounded-2xl shadow-xl ring-1 ring-white/15 sm:rounded-3xl">
            <img
              src="/uploads/promo-custom.jpg"
              alt="Black true-wireless earbuds charging case on a stone table"
              loading="lazy"
              className="h-52 w-full object-cover transition-transform duration-500 hover:scale-105 sm:h-64 lg:h-80"
            />
            {/* floating discount badge — springs in with a pop */}
            <motion.span
              initial={reduceMotion ? false : { scale: 0, rotate: -12 }}
              whileInView={{ scale: 1, rotate: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{
                type: "spring",
                stiffness: 260,
                damping: 14,
                delay: 0.45,
              }}
              className="absolute top-4 left-4 rounded-full bg-cta px-3.5 py-1.5 text-xs font-bold tracking-wide text-white uppercase shadow-lg sm:text-sm"
            >
              {t("spotlight_badge")}
            </motion.span>
          </div>
        </motion.div>

        {/* Content side — slides in from the right */}
        <motion.div
          className="order-2 text-center lg:text-left"
          initial={{ opacity: 0, ...dirR }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
        >
          <span className="inline-block rounded-full border border-white/25 bg-white/10 px-3 py-1 text-[11px] font-semibold tracking-widest text-cta uppercase sm:text-xs">
            {t("spotlight_eyebrow")}
          </span>

          <h2
            id="tws-spotlight-title"
            className="mt-3 text-2xl leading-tight font-bold sm:text-3xl lg:text-4xl"
          >
            {t("spotlight_title")}
          </h2>

          <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-white/75 sm:text-base lg:mx-0">
            {t("spotlight_sub")}
          </p>

          <motion.ul
            variants={listVariants}
            initial={reduceMotion ? false : "hidden"}
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            className="mt-5 space-y-2.5 text-left sm:text-left lg:mx-auto lg:max-w-sm"
          >
            {FEATURES.map((key) => (
              <motion.li
                key={key}
                variants={itemVariants}
                className="flex items-start gap-2.5 text-sm sm:text-[15px]"
              >
                <CheckCircle2
                  aria-hidden="true"
                  className="mt-0.5 h-5 w-5 shrink-0 text-cta"
                />
                <span className="text-white/90">{t(key)}</span>
              </motion.li>
            ))}
          </motion.ul>

          <div className="mt-6 flex flex-col items-center gap-4 sm:flex-row sm:justify-center lg:justify-start">
            <div className="flex items-baseline gap-1.5">
              <span className="text-sm text-white/70">{t("spotlight_from")}</span>
              <span className="text-2xl font-bold text-cta sm:text-3xl">৳1,650</span>
            </div>
            <Button
              size="lg"
              onClick={() =>
                navigate({ name: "shop", category: "earphones-headphones" })
              }
              className="w-full bg-cta text-white hover:bg-cta/90 sm:w-auto"
            >
              {t("spotlight_cta")}
              <ArrowRight aria-hidden="true" className="ml-1.5 h-4 w-4" />
            </Button>
          </div>

          <p className="mt-4 flex items-center justify-center gap-1.5 text-xs text-white/60 sm:justify-start sm:text-sm">
            <ShieldCheck aria-hidden="true" className="h-4 w-4 text-white/70" />
            {t("spotlight_note")}
          </p>
        </motion.div>
      </div>
    </section>
  );
}
