"use client";
// ─── Arpon Telecom — home: shop-by-category grid ────────────────────────────
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import type { CategoryDTO } from "@/lib/types";
import { CategoryIcon } from "../category-icon";
import { SectionHeading } from "../section-heading";

export default function CategoryGrid({
  categories,
}: {
  categories: CategoryDTO[];
}) {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const navigate = useStore((s) => s.navigate);

  if (!categories.length) return null;

  return (
    <section aria-label={t("section_categories")}>
      <SectionHeading
        titleKey="section_categories"
        subtitleKey="section_categories_sub"
      />
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-5 lg:grid-cols-10">
        {categories.map((cat) => {
          const name = lang === "bn" ? cat.nameBn : cat.nameEn;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => navigate({ name: "shop", category: cat.slug })}
              className="flex cursor-pointer flex-col items-center gap-2 rounded-xl border bg-card p-3 text-center shadow-xs transition hover:border-primary/40 hover:shadow-md sm:p-4"
            >
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary sm:h-12 sm:w-12">
                <CategoryIcon
                  icon={cat.icon}
                  className="h-5 w-5 sm:h-6 sm:w-6"
                />
              </span>
              <span className="line-clamp-2 text-[11px] leading-tight font-medium text-foreground sm:text-xs">
                {name}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
}
