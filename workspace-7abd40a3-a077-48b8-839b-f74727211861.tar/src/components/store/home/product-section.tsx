"use client";
// ─── Arpon Telecom — home: generic product grid section ─────────────────────
import { useT } from "@/lib/i18n";
import type { ProductDTO } from "@/lib/types";
import { ProductCard } from "../product-card";
import { SectionHeading } from "../section-heading";

export default function ProductSection({
  titleKey,
  subtitleKey,
  products,
  onViewAll,
}: {
  titleKey: string;
  subtitleKey: string;
  products: ProductDTO[];
  onViewAll?: () => void;
}) {
  const t = useT();

  if (!products.length) return null;

  return (
    <section aria-label={t(titleKey)}>
      <SectionHeading
        titleKey={titleKey}
        subtitleKey={subtitleKey}
        onViewAll={onViewAll}
      />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} />
        ))}
      </div>
    </section>
  );
}
