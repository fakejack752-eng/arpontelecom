"use client";
// ─── Arpon Telecom — home: static customer testimonials ─────────────────────
import { BadgeCheck } from "lucide-react";

import { useT } from "@/lib/i18n";
import { SectionHeading } from "../section-heading";
import { StarRating } from "../star-rating";

const REVIEWS = [
  {
    name: "Rahim Uddin",
    initials: "RU",
    location: "Dhaka",
    comment:
      "Original product with official warranty. Delivery was super fast — ordered at night, got it the next day!",
  },
  {
    name: "Nusrat Jahan",
    initials: "NJ",
    location: "Dhaka",
    comment:
      "খুব দ্রুত ডেলিভারি পেয়েছি। প্রোডাক্ট একদম অরিজিনাল। ধন্যবাদ আরপন টেলিকম!",
  },
  {
    name: "Tanvir Ahmed",
    initials: "TA",
    location: "Chattogram",
    comment:
      "Best price in the market. The phone arrived sealed and 100% genuine. Highly recommended.",
  },
  {
    name: "Mitu Akter",
    initials: "MA",
    location: "Dhaka",
    comment:
      "ওয়ারেন্টিসহ অরিজিনাল প্রোডাক্ট পেয়েছি। তাদের সার্ভিস সত্যিই অসাধারণ।",
  },
  {
    name: "Sabbir Hossain",
    initials: "SH",
    location: "Sylhet",
    comment:
      "Ordered a power bank and got it within 48 hours. Genuine Anker product, fair price.",
  },
  {
    name: "Farhana Islam",
    initials: "FI",
    location: "Dhaka",
    comment:
      "ক্যাশ অন ডেলিভারিতে নিয়েছি — প্রোডাক্ট হাতে পেয়ে চেক করে টাকা দিয়েছি। বিশ্বস্ত দোকান।",
  },
] as const;

export default function Testimonials() {
  const t = useT();

  return (
    <section aria-label={t("section_reviews")}>
      <SectionHeading
        titleKey="section_reviews"
        subtitleKey="section_reviews_sub"
      />
      <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-3">
        {REVIEWS.map((r) => (
          <figure
            key={r.name}
            className="flex flex-col gap-3 rounded-xl border bg-card p-5 shadow-xs"
          >
            <StarRating rating={5} />
            <blockquote className="text-sm leading-relaxed text-foreground/80">
              “{r.comment}”
            </blockquote>
            <figcaption className="mt-auto flex items-center gap-3 border-t pt-3">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary">
                {r.initials}
              </span>
              <span className="min-w-0 flex-1">
                <span className="block truncate text-sm font-semibold text-foreground">
                  {r.name}
                </span>
                <span className="block text-xs text-muted-foreground">
                  {r.location}
                </span>
              </span>
              <span className="flex shrink-0 items-center gap-1 text-xs font-medium text-emerald-600">
                <BadgeCheck className="h-4 w-4 text-emerald-500" aria-hidden="true" />
                {t("verifiedBuyer")}
              </span>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}
