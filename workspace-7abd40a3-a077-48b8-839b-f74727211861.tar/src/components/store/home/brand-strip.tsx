"use client";
// ─── Arpon Telecom — home: brand chips strip ────────────────────────────────
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import { SectionHeading } from "../section-heading";

const BRANDS = [
  "Samsung",
  "Xiaomi",
  "Apple",
  "Realme",
  "Oppo",
  "Vivo",
  "Infinix",
  "Walton",
  "Symphony",
  "Anker",
  "Baseus",
  "Amazfit",
  "Nokia",
] as const;

const DOT_COLORS = [
  "bg-sky-600",
  "bg-emerald-500",
  "bg-neutral-800",
  "bg-amber-500",
  "bg-rose-500",
] as const;

export default function BrandStrip() {
  const t = useT();
  const navigate = useStore((s) => s.navigate);

  return (
    <section aria-label={t("section_brands")}>
      <SectionHeading titleKey="section_brands" />
      <div className="flex flex-wrap justify-center gap-2 sm:gap-3">
        {BRANDS.map((brand, i) => (
          <button
            key={brand}
            type="button"
            onClick={() => navigate({ name: "shop", brand })}
            className="flex cursor-pointer items-center gap-2 rounded-full border bg-card px-4 py-2 text-sm font-semibold text-foreground shadow-xs transition hover:border-primary hover:text-primary"
          >
            <span
              className={`h-2 w-2 shrink-0 rounded-full ${DOT_COLORS[i % DOT_COLORS.length]}`}
              aria-hidden="true"
            />
            {brand}
          </button>
        ))}
      </div>
    </section>
  );
}
