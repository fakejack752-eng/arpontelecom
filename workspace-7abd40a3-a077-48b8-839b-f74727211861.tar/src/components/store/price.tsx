"use client";
// ─── Arpon Telecom — price display with strikethrough old price ─────────────
import { formatBDT } from "@/lib/format";
import { cn } from "@/lib/utils";

export function Price({
  price,
  oldPrice,
  size = "md",
}: {
  price: number;
  oldPrice?: number | null;
  size?: "sm" | "md" | "lg";
}) {
  const priceCls =
    size === "lg" ? "text-2xl" : size === "sm" ? "text-sm" : "text-base";
  const oldCls = size === "sm" ? "text-xs" : "text-sm";

  return (
    <span className="inline-flex flex-wrap items-baseline gap-x-1.5">
      <span className={cn("font-bold text-primary", priceCls)}>
        {formatBDT(price)}
      </span>
      {oldPrice != null && oldPrice > price && (
        <span className={cn("line-through text-muted-foreground", oldCls)}>
          {formatBDT(oldPrice)}
        </span>
      )}
    </span>
  );
}
