"use client";
// ─── Arpon Telecom — sticky site header (top strip, search, nav) ────────────
import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Heart, MessageCircle, Phone, Search, ShoppingBag, Smartphone } from "lucide-react";

import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { getJSON } from "@/lib/api";
import { formatBDT } from "@/lib/format";
import { useT } from "@/lib/i18n";
import { HOTLINE_NUMBER, WHATSAPP_NUMBER, useCartCount, useStore, useWishlistCount } from "@/lib/store";
import type { CategoryDTO } from "@/lib/types";
import { cn } from "@/lib/utils";
import { CategoryIcon } from "./category-icon";

interface Suggestion {
  id: string;
  slug: string;
  nameEn: string;
  nameBn: string;
  price: number;
  image: string;
}

/* ── Language toggle pill (EN | বাংলা) ──────────────────────────────────────── */
function LanguageToggle() {
  const lang = useStore((s) => s.lang);
  const setLang = useStore((s) => s.setLang);

  return (
    <div
      className="flex items-center rounded-full bg-white/15 p-0.5 text-[11px] font-semibold"
      role="group"
      aria-label="Language"
    >
      {(["en", "bn"] as const).map((l) => (
        <button
          key={l}
          type="button"
          onClick={() => setLang(l)}
          aria-pressed={lang === l}
          className={cn(
            "rounded-full px-2.5 py-0.5 transition-colors",
            lang === l ? "bg-cta text-white shadow-sm" : "text-white/80 hover:text-white"
          )}
        >
          {l === "en" ? "EN" : "বাংলা"}
        </button>
      ))}
    </div>
  );
}

/* ── Live search box with debounced suggestions ────────────────────────────── */
function SearchBox() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const navigate = useStore((s) => s.navigate);

  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const boxRef = useRef<HTMLDivElement>(null);

  // Debounced live suggestions (300ms).
  useEffect(() => {
    const q = query.trim();
    if (!open || q.length === 0) {
      setSuggestions([]);
      return;
    }
    let cancelled = false;
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const data = await getJSON<{ suggestions: Suggestion[] }>(
          `/api/search?q=${encodeURIComponent(q)}`
        );
        if (!cancelled) setSuggestions(data.suggestions ?? []);
      } catch {
        if (!cancelled) setSuggestions([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query, open]);

  // Close dropdown on Escape.
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") setOpen(false);
  };

  const submitSearch = () => {
    const q = query.trim();
    if (!q) return;
    setOpen(false);
    navigate({ name: "shop", search: q });
  };

  const pickSuggestion = (slug: string) => {
    setOpen(false);
    setQuery("");
    navigate({ name: "product", slug });
  };

  return (
    <div ref={boxRef} className="relative w-full">
      <form
        role="search"
        onSubmit={(e) => {
          e.preventDefault();
          submitSearch();
        }}
      >
        <Search
          className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground"
          aria-hidden="true"
        />
        <Input
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 200)}
          onKeyDown={handleKeyDown}
          placeholder={t("searchPlaceholder")}
          aria-label={t("search")}
          className="h-10 rounded-full border-input bg-muted/60 pr-4 pl-9 text-sm"
        />
      </form>

      {open && query.trim().length > 0 && (
        <div className="absolute inset-x-0 top-full z-50 mt-2 max-h-80 overflow-y-auto rounded-xl border bg-card shadow-lg">
          <p className="px-3 pt-2.5 pb-1 text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">
            {t("searchSuggestions")}
          </p>
          {loading && suggestions.length === 0 ? (
            <div className="space-y-2 px-3 pb-3">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-10 w-full rounded-lg" />
              ))}
            </div>
          ) : suggestions.length === 0 ? (
            <p className="px-3 pb-3 text-sm text-muted-foreground">
              {t("noSuggestions")}
            </p>
          ) : (
            suggestions.map((s) => (
              <button
                key={s.id}
                type="button"
                // Keep input focus until the click completes (blur closes with a timeout).
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => pickSuggestion(s.slug)}
                className="flex w-full items-center gap-3 px-3 py-2 text-left transition-colors hover:bg-accent"
              >
                {s.image ? (
                  <img
                    src={s.image}
                    alt=""
                    className="h-10 w-10 shrink-0 rounded border object-cover"
                  />
                ) : (
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded border bg-muted">
                    <Smartphone className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                  </span>
                )}
                <span className="min-w-0 flex-1 truncate text-sm font-medium text-foreground">
                  {lang === "bn" ? s.nameBn : s.nameEn}
                </span>
                <span className="shrink-0 text-sm font-bold text-primary">
                  {formatBDT(s.price)}
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}

/* ── Icon button with CTA count badge ──────────────────────────────────────── */
function IconButton({
  label,
  count,
  onClick,
  children,
}: {
  label: string;
  count?: number;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="relative flex h-10 w-10 items-center justify-center rounded-full text-foreground transition-colors hover:bg-accent"
    >
      {children}
      {typeof count === "number" && count > 0 && (
        <motion.span
          key={count}
          initial={{ scale: 0.3 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 500, damping: 16 }}
          className="absolute -top-1 -right-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-cta px-1 text-[10px] font-bold text-white"
        >
          {count > 99 ? "99+" : count}
        </motion.span>
      )}
    </button>
  );
}

/* ── Category fetch hook (shared by desktop nav + mobile chips) ─────────────── */
function useCategories() {
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  useEffect(() => {
    let cancelled = false;
    getJSON<{ categories: CategoryDTO[] }>("/api/categories")
      .then((d) => {
        if (!cancelled) setCategories(d.categories ?? []);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);
  return categories;
}

/* ── Header ────────────────────────────────────────────────────────────────── */
export default function Header() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const navigate = useStore((s) => s.navigate);
  const setCartOpen = useStore((s) => s.setCartOpen);
  const cartCount = useCartCount();
  const wishCount = useWishlistCount();
  const categories = useCategories();

  const goCategory = (slug: string) => navigate({ name: "shop", category: slug });

  return (
    <header className="sticky top-0 z-50">
      {/* Top strip */}
      <div className="bg-primary text-primary-foreground">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-3 px-4 py-1.5 text-xs">
          <p className="truncate">{t("topBarMsg")}</p>
          <div className="flex shrink-0 items-center gap-3">
            <a
              href={`tel:${HOTLINE_NUMBER.replace(/-/g, "")}`}
              className="hidden items-center gap-1.5 transition-opacity hover:opacity-85 sm:inline-flex"
            >
              <Phone className="h-3.5 w-3.5" aria-hidden="true" />
              <span>
                {t("hotline")}: {HOTLINE_NUMBER}
              </span>
            </a>
            <LanguageToggle />
          </div>
        </div>
      </div>

      {/* Main row */}
      <div className="border-b bg-card">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4">
          <button
            type="button"
            onClick={() => navigate({ name: "home" })}
            className="flex shrink-0 items-center gap-2.5"
            aria-label={t("brandName")}
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary text-primary-foreground shadow-sm">
              <Smartphone className="h-5 w-5" aria-hidden="true" />
            </span>
            <span className="text-left leading-tight">
              <span className="block text-[15px] font-bold text-primary">
                {t("brandName")}
              </span>
              <span className="hidden text-[11px] text-muted-foreground sm:block">
                {t("brandTagline")}
              </span>
            </span>
          </button>

          {/* Desktop search */}
          <div className="hidden min-w-0 flex-1 px-4 lg:block">
            <SearchBox />
          </div>

          <div className="ml-auto flex shrink-0 items-center gap-1 lg:gap-1.5">
            <IconButton
              label={t("nav_wishlist")}
              count={wishCount}
              onClick={() => navigate({ name: "wishlist" })}
            >
              <Heart className="h-5 w-5" aria-hidden="true" />
            </IconButton>
            <IconButton label={t("yourCart")} count={cartCount} onClick={() => setCartOpen(true)}>
              <ShoppingBag className="h-5 w-5" aria-hidden="true" />
            </IconButton>
            <a
              href={`https://wa.me/${WHATSAPP_NUMBER}`}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden h-9 items-center gap-2 rounded-full bg-whatsapp px-4 text-sm font-medium text-whatsapp-foreground transition hover:bg-whatsapp/90 sm:inline-flex"
            >
              <MessageCircle className="h-4 w-4" aria-hidden="true" />
              {t("chatWhatsApp")}
            </a>
          </div>
        </div>

        {/* Mobile search row */}
        <div className="px-4 pb-3 lg:hidden">
          <SearchBox />
        </div>
      </div>

      {/* Category nav — desktop */}
      <nav
        aria-label={t("nav_categories")}
        className="hidden border-b bg-card lg:block"
      >
        <div className="no-scrollbar mx-auto flex max-w-7xl items-center gap-1 overflow-x-auto px-4">
          {categories.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => goCategory(c.slug)}
              className="flex shrink-0 items-center gap-2 rounded-lg px-3 py-2.5 text-sm font-medium text-foreground/80 transition-colors hover:bg-accent hover:text-primary"
            >
              <CategoryIcon icon={c.icon} className="h-4 w-4 text-primary" />
              {lang === "bn" ? c.nameBn : c.nameEn}
            </button>
          ))}
        </div>
      </nav>

      {/* Category chips — mobile */}
      <nav
        aria-label={t("nav_categories")}
        className="no-scrollbar flex gap-2 overflow-x-auto border-b bg-card px-4 py-2 lg:hidden"
      >
        {categories.map((c) => (
          <button
            key={c.id}
            type="button"
            onClick={() => goCategory(c.slug)}
            className="flex shrink-0 items-center gap-1.5 rounded-full border bg-background px-3 py-1.5 text-xs font-medium text-foreground/80 transition-colors hover:border-primary/30 hover:text-primary"
          >
            <CategoryIcon icon={c.icon} className="h-3.5 w-3.5 text-primary" />
            {lang === "bn" ? c.nameBn : c.nameEn}
          </button>
        ))}
      </nav>
    </header>
  );
}
