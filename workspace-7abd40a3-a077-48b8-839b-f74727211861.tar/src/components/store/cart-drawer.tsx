"use client";
// ─── Arpon Telecom — cart drawer (controlled shadcn Sheet) ──────────────────
import { Minus, Plus, ShoppingBag, Smartphone, Trash2 } from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { useT } from "@/lib/i18n";
import { useCartCount, useCartSubtotal, useStore } from "@/lib/store";
import { Price } from "./price";

export default function CartDrawer() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const cart = useStore((s) => s.cart);
  const cartOpen = useStore((s) => s.cartOpen);
  const setCartOpen = useStore((s) => s.setCartOpen);
  const setQty = useStore((s) => s.setQty);
  const removeFromCart = useStore((s) => s.removeFromCart);
  const navigate = useStore((s) => s.navigate);
  const subtotal = useCartSubtotal();
  const count = useCartCount();

  const goCheckout = () => {
    setCartOpen(false);
    navigate({ name: "checkout" });
  };

  return (
    <Sheet open={cartOpen} onOpenChange={setCartOpen}>
      <SheetContent
        side="right"
        className="flex h-full w-full flex-col gap-0 p-0 sm:max-w-md"
      >
        <SheetHeader className="border-b p-4">
          <SheetTitle className="text-base font-bold">{t("yourCart")}</SheetTitle>
          <SheetDescription>
            {count} {t("itemsCount")}
          </SheetDescription>
        </SheetHeader>

        {cart.length === 0 ? (
          /* Empty state */
          <div className="flex flex-1 flex-col items-center justify-center gap-3 p-6 text-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
              <ShoppingBag className="h-8 w-8 text-muted-foreground" aria-hidden="true" />
            </span>
            <p className="font-semibold text-foreground">{t("cartEmpty")}</p>
            <p className="text-sm text-muted-foreground">{t("cartEmptyDesc")}</p>
            <Button onClick={() => setCartOpen(false)} className="mt-2">
              {t("continueShopping")}
            </Button>
          </div>
        ) : (
          <>
            {/* Items */}
            <ul className="flex-1 divide-y overflow-y-auto">
              {cart.map((item) => {
                const name = lang === "bn" ? item.nameBn : item.nameEn;
                return (
                  <li
                    key={`${item.productId}-${item.variant ?? "default"}`}
                    className="flex gap-3 p-3"
                  >
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={name}
                        className="h-20 w-20 shrink-0 rounded-lg border object-cover"
                      />
                    ) : (
                      <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-lg border bg-muted">
                        <Smartphone className="h-6 w-6 text-muted-foreground" aria-hidden="true" />
                      </span>
                    )}

                    <div className="flex min-w-0 flex-1 flex-col">
                      <button
                        type="button"
                        onClick={() => {
                          setCartOpen(false);
                          navigate({ name: "product", slug: item.slug });
                        }}
                        className="line-clamp-2 text-left text-sm font-medium text-foreground transition-colors hover:text-primary"
                      >
                        {name}
                      </button>
                      {item.variant && (
                        <p className="mt-0.5 text-xs text-muted-foreground">
                          {item.variant}
                        </p>
                      )}
                      <div className="mt-0.5">
                        <Price price={item.price} size="sm" />
                      </div>

                      <div className="mt-auto flex items-center justify-between pt-1.5">
                        <div
                          className="flex items-center gap-1"
                          role="group"
                          aria-label={t("quantity")}
                        >
                          <button
                            type="button"
                            aria-label={`- ${t("quantity")}`}
                            onClick={() =>
                              setQty(item.productId, item.variant, item.qty - 1)
                            }
                            className="flex h-7 w-7 items-center justify-center rounded-md border transition-colors hover:bg-accent"
                          >
                            <Minus className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                          <span className="w-7 text-center text-sm font-medium">
                            {item.qty}
                          </span>
                          <button
                            type="button"
                            aria-label={`+ ${t("quantity")}`}
                            onClick={() =>
                              setQty(item.productId, item.variant, item.qty + 1)
                            }
                            className="flex h-7 w-7 items-center justify-center rounded-md border transition-colors hover:bg-accent"
                          >
                            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                        </div>
                        <button
                          type="button"
                          aria-label={t("remove")}
                          onClick={() => removeFromCart(item.productId, item.variant)}
                          className="text-muted-foreground transition-colors hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                  </li>
                );
              })}
            </ul>

            {/* Footer */}
            <div className="space-y-3 border-t p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">
                  {t("cartSubtotal")}
                </span>
                <Price price={subtotal} size="lg" />
              </div>
              <p className="text-xs text-muted-foreground">
                {t("shoppingCartNote")}
              </p>
              <Button
                onClick={goCheckout}
                className="w-full bg-cta text-cta-foreground hover:bg-cta/90"
              >
                {t("proceedCheckout")}
              </Button>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => setCartOpen(false)}
              >
                {t("continueShopping")}
              </Button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
