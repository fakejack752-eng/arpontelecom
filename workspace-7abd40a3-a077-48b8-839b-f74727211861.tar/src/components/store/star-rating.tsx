"use client";
// ─── Arpon Telecom — star rating display ────────────────────────────────────
import { Star } from "lucide-react";

import { cn } from "@/lib/utils";

export function StarRating({
  rating,
  count,
  size = "sm",
}: {
  rating: number;
  count?: number;
  size?: "sm" | "md";
}) {
  const filled = Math.max(0, Math.min(5, Math.round(rating)));
  const iconCls = size === "md" ? "h-4.5 w-4.5" : "h-3.5 w-3.5";
  const textCls = size === "md" ? "text-sm" : "text-xs";

  return (
    <div
      className="flex items-center gap-1"
      role="img"
      aria-label={`${rating.toFixed(1)} / 5`}
    >
      <span className="flex items-center gap-0.5">
        {[1, 2, 3, 4, 5].map((i) => (
          <Star
            key={i}
            className={cn(
              iconCls,
              i <= filled
                ? "fill-amber-400 text-amber-400"
                : "text-muted-foreground/30"
            )}
          />
        ))}
      </span>
      <span className={cn("font-medium text-foreground/80", textCls)}>
        {rating.toFixed(1)}
      </span>
      {typeof count === "number" && count > 0 && (
        <span className={cn("text-muted-foreground", textCls)}>({count})</span>
      )}
    </div>
  );
}
