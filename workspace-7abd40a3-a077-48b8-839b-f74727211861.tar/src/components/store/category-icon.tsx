"use client";
// ─── Arpon Telecom — category lucide icon lookup ────────────────────────────
import {
  BatteryCharging,
  CardSim,
  Headphones,
  Phone,
  Plug,
  ShieldCheck,
  Smartphone,
  Tablet,
  Watch,
  Wrench,
  type LucideIcon,
} from "lucide-react";

import { cn } from "@/lib/utils";

// Static import map (no dynamic lookups) — "SimCard" maps to lucide's CardSim.
const ICONS: Record<string, LucideIcon> = {
  Smartphone,
  Phone,
  Tablet,
  Plug,
  Headphones,
  BatteryCharging,
  Watch,
  ShieldCheck,
  SimCard: CardSim,
  Wrench,
};

export function CategoryIcon({ icon, className }: { icon: string; className?: string }) {
  const Icon = ICONS[icon] ?? Smartphone;
  return <Icon className={cn("h-5 w-5", className)} aria-hidden="true" />;
}
