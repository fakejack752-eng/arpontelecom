"use client";
// ─── Arpon Telecom — stock status pill ──────────────────────────────────────
import { useT } from "@/lib/i18n";
import type { StockStatus } from "@/lib/types";
import { cn } from "@/lib/utils";

const VARIANTS: Record<
  StockStatus,
  { cls: string; dotCls?: string; key: string }
> = {
  in_stock: {
    cls: "border-emerald-200 bg-emerald-50 text-emerald-700",
    dotCls: "bg-emerald-500",
    key: "inStock",
  },
  out_of_stock: {
    cls: "border-rose-200 bg-rose-50 text-rose-700",
    key: "outOfStock",
  },
  pre_order: {
    cls: "border-amber-200 bg-amber-50 text-amber-700",
    key: "preOrder",
  },
};

export function StockBadge({
  status,
  className,
}: {
  status: StockStatus;
  className?: string;
}) {
  const t = useT();
  const v = VARIANTS[status] ?? VARIANTS.in_stock;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 text-[11px] font-medium whitespace-nowrap",
        v.cls,
        className
      )}
    >
      {v.dotCls && (
        <span className={cn("h-1.5 w-1.5 rounded-full", v.dotCls)} />
      )}
      {t(v.key)}
    </span>
  );
}
