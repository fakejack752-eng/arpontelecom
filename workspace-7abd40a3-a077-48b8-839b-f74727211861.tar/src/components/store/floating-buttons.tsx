"use client";
// ─── Arpon Telecom — floating WhatsApp / call buttons ───────────────────────
import { MessageCircle, Phone } from "lucide-react";

import { useT } from "@/lib/i18n";
import { HOTLINE_NUMBER, WHATSAPP_NUMBER } from "@/lib/store";

export default function FloatingButtons() {
  const t = useT();
  const telHref = `tel:+88${HOTLINE_NUMBER.replace(/-/g, "")}`;

  return (
    <div className="fixed right-4 bottom-4 z-40 flex flex-col items-end gap-2">
      <a
        href={`https://wa.me/${WHATSAPP_NUMBER}`}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={t("chatWhatsApp")}
        className="flex h-12 w-12 items-center justify-center rounded-full bg-whatsapp text-whatsapp-foreground shadow-lg transition-transform hover:scale-105"
      >
        <MessageCircle className="h-6 w-6" aria-hidden="true" />
        <span className="sr-only">{t("chatWhatsApp")}</span>
      </a>
      <a
        href={telHref}
        aria-label={t("callNow")}
        className="flex h-12 w-12 items-center justify-center rounded-full bg-cta text-cta-foreground shadow-lg transition-transform hover:scale-105 md:hidden"
      >
        <Phone className="h-6 w-6" aria-hidden="true" />
        <span className="sr-only">{t("callNow")}</span>
      </a>
    </div>
  );
}
