"use client";
// ─── Arpon Telecom — mobile recharge (demo service) ─────────────────────────
import { useState } from "react";
import { toast } from "sonner";
import { Info, Loader2, Smartphone } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useT } from "@/lib/i18n";
import { isValidBDPhone } from "@/lib/format";

interface Operator {
  id: string;
  name: string;
  initials: string;
  color: string;
}

const OPERATORS: Operator[] = [
  { id: "gp", name: "Grameenphone", initials: "GP", color: "#199CDE" },
  { id: "robi", name: "Robi", initials: "R", color: "#E2136E" },
  { id: "bl", name: "Banglalink", initials: "BL", color: "#F6921E" },
  { id: "airtel", name: "Airtel", initials: "A", color: "#E40000" },
  { id: "tt", name: "Teletalk", initials: "TT", color: "#00694B" },
];

const PRESETS = [50, 100, 200, 500, 1000];

export function RechargeView() {
  const t = useT();
  const [operator, setOperator] = useState<Operator | null>(null);
  const [phone, setPhone] = useState("");
  const [amount, setAmount] = useState("");
  const [processing, setProcessing] = useState(false);

  const amountNum = Number(amount);
  const amountValid = Number.isFinite(amountNum) && amountNum >= 20 && amountNum <= 5000;

  function recharge() {
    if (processing) return;
    if (!operator) {
      toast.error(t("selectOperator"));
      return;
    }
    if (!isValidBDPhone(phone)) {
      toast.error(t("phoneInvalid"));
      return;
    }
    if (!amountValid) {
      toast.error(t("amountInvalid"));
      return;
    }
    setProcessing(true);
    window.setTimeout(() => {
      setProcessing(false);
      toast.success(t("rechargeSuccess"));
      setOperator(null);
      setPhone("");
      setAmount("");
    }, 1200);
  }

  return (
    <div className="mx-auto max-w-3xl px-3 py-8 sm:px-4">
      {/* Header */}
      <div className="text-center">
        <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
          <Smartphone className="h-7 w-7 text-primary" aria-hidden="true" />
        </span>
        <h1 className="mt-3 text-2xl font-bold text-foreground">{t("rechargeTitle")}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{t("rechargeDesc")}</p>
      </div>

      {/* Demo notice */}
      <div
        className="mx-auto mt-5 flex max-w-xl items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800"
        role="note"
      >
        <Info className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
        {t("rechargeDemoNote")}
      </div>

      {/* Form card */}
      <section className="mt-6 rounded-xl border bg-card p-4 sm:p-6">
        <div className="space-y-6">
          {/* ① Operator */}
          <div>
            <h2 className="mb-3 text-sm font-semibold text-foreground">{t("selectOperator")}</h2>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-5" role="radiogroup" aria-label={t("selectOperator")}>
              {OPERATORS.map((op) => (
                <button
                  key={op.id}
                  type="button"
                  role="radio"
                  aria-checked={operator?.id === op.id}
                  onClick={() => setOperator(op)}
                  className={`flex flex-col items-center gap-2 rounded-xl border p-4 text-center transition-colors ${
                    operator?.id === op.id
                      ? "border-primary bg-primary/5"
                      : "hover:border-muted-foreground/30 hover:bg-muted/50"
                  }`}
                >
                  <span
                    className="flex h-10 w-10 items-center justify-center rounded-full text-xs font-bold text-white"
                    style={{ backgroundColor: op.color }}
                    aria-hidden="true"
                  >
                    {op.initials}
                  </span>
                  <span className="text-xs font-semibold text-foreground">{op.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* ② Phone */}
          <div className="space-y-1.5">
            <Label htmlFor="rc-phone">{t("mobileNumber")}</Label>
            <Input
              id="rc-phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 11))}
              placeholder={t("phonePh")}
              inputMode="numeric"
              autoComplete="tel"
            />
          </div>

          {/* ③ Amount */}
          <div>
            <Label htmlFor="rc-amount" className="mb-3 block">
              {t("amount")}
            </Label>
            <div className="mb-3 flex flex-wrap gap-2">
              {PRESETS.map((v) => (
                <button
                  key={v}
                  type="button"
                  onClick={() => setAmount(String(v))}
                  aria-pressed={amount === String(v)}
                  className={`rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
                    amount === String(v)
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border bg-background text-foreground hover:bg-muted/50"
                  }`}
                >
                  ৳{v}
                </button>
              ))}
            </div>
            <Input
              id="rc-amount"
              type="number"
              min={20}
              max={5000}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={t("enterAmount")}
            />
          </div>

          {/* Submit */}
          <Button
            onClick={recharge}
            disabled={processing}
            className="h-11 w-full bg-cta text-cta-foreground hover:bg-cta/90"
          >
            {processing ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                {t("loading")}
              </>
            ) : (
              t("rechargeNow")
            )}
          </Button>
        </div>
      </section>
    </div>
  );
}

export default RechargeView;
