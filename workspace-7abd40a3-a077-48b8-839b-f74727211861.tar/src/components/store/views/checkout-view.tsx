"use client";
// ─── Arpon Telecom — checkout (customer info, delivery, payment, summary) ───
import { useState } from "react";
import { toast } from "sonner";
import {
  Banknote,
  CheckCircle2,
  Copy,
  CreditCard,
  Loader2,
  Phone,
  ShoppingBag,
  Smartphone,
  Truck,
  User,
  X,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import {
  RadioGroup,
  RadioGroupItem,
} from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/lib/store";
import { useT } from "@/lib/i18n";
import { formatBDT, isValidBDPhone } from "@/lib/format";
import { postJSON } from "@/lib/api";
import { DELIVERY_FEES } from "@/lib/types";
import type { DeliveryZone, OrderDTO, PaymentMethod } from "@/lib/types";

const DIVISION_DISTRICTS: Record<string, string[]> = {
  Dhaka: ["Dhaka", "Gazipur", "Narayanganj", "Narsingdi", "Tangail", "Faridpur", "Kishoreganj", "Manikganj"],
  Chattogram: ["Chattogram", "Cox's Bazar", "Cumilla", "Noakhali", "Feni", "Chandpur", "Brahmanbaria"],
  Khulna: ["Khulna", "Jashore", "Satkhira", "Kushtia", "Bagerhat", "Jhenaidah"],
  Rajshahi: ["Rajshahi", "Bogura", "Pabna", "Sirajganj", "Natore", "Chapainawabganj"],
  Sylhet: ["Sylhet", "Moulvibazar", "Habiganj", "Sunamganj"],
  Barishal: ["Barishal", "Patuakhali", "Bhola", "Jhalokati", "Pirojpur"],
  Rangpur: ["Rangpur", "Dinajpur", "Kurigram", "Thakurgaon", "Panchagarh", "Nilphamari"],
  Mymensingh: ["Mymensingh", "Jamalpur", "Netrokona", "Sherpur"],
};

const MPAY_NOTES: Partial<Record<PaymentMethod, string>> = {
  bkash: "bkashDesc",
  nagad: "nagadDesc",
  rocket: "rocketDesc",
};

export function CheckoutView() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const cart = useStore((s) => s.cart);
  const clearCart = useStore((s) => s.clearCart);
  const setLastOrder = useStore((s) => s.setLastOrder);
  const navigate = useStore((s) => s.navigate);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [division, setDivision] = useState("");
  const [district, setDistrict] = useState("");
  const [upazila, setUpazila] = useState("");
  const [address, setAddress] = useState("");
  const [zone, setZone] = useState<DeliveryZone>("inside_dhaka");
  const [payment, setPayment] = useState<PaymentMethod>("cod");
  const [trxId, setTrxId] = useState("");
  const [notes, setNotes] = useState("");

  const [couponInput, setCouponInput] = useState("");
  const [couponCode, setCouponCode] = useState<string | null>(null);
  const [discount, setDiscount] = useState(0);
  const [applying, setApplying] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [placed, setPlaced] = useState<{ orderNumber: string; total: number; phone: string } | null>(null);

  const subtotal = cart.reduce((n, i) => n + i.qty * i.price, 0);
  const fee = DELIVERY_FEES[zone];
  const total = Math.max(0, subtotal - discount) + fee;

  function handleDivisionChange(v: string) {
    setDivision(v);
    setDistrict("");
    if (v !== "Dhaka") setZone("outside_dhaka");
    else if (district === "Dhaka") setZone("inside_dhaka");
  }

  function handleDistrictChange(v: string) {
    setDistrict(v);
    if (division === "Dhaka") setZone(v === "Dhaka" ? "inside_dhaka" : "outside_dhaka");
  }

  async function applyCoupon() {
    const code = couponInput.trim().toUpperCase();
    if (!code) return;
    setApplying(true);
    try {
      const data = await postJSON<{ ok: boolean; discount: number; message: string }>(
        "/api/coupons/validate",
        { code, subtotal }
      );
      if (data.ok && data.discount > 0) {
        setCouponCode(code);
        setDiscount(data.discount);
        toast.success(`${t("couponApplied")} (-${formatBDT(data.discount)})`);
      } else {
        setCouponCode(null);
        setDiscount(0);
        toast.error(t("couponInvalid"));
      }
    } catch {
      toast.error(t("couponInvalid"));
    } finally {
      setApplying(false);
    }
  }

  function removeCoupon() {
    setCouponCode(null);
    setDiscount(0);
    setCouponInput("");
  }

  function validate(): boolean {
    if (!isValidBDPhone(phone)) {
      toast.error(t("phoneInvalid"));
      return false;
    }
    if (name.trim().length < 2 || !division || !district || !upazila.trim() || address.trim().length < 3) {
      toast.error(t("fillAllFields"));
      return false;
    }
    return true;
  }

  async function placeOrder() {
    if (!validate() || placing) return;
    setPlacing(true);
    try {
      const noteParts: string[] = [];
      if (trxId.trim()) noteParts.push(`TrxID: ${trxId.trim()}`);
      if (notes.trim()) noteParts.push(notes.trim());
      const payload = {
        customer: {
          name: name.trim(),
          phone: phone.trim(),
          division,
          district,
          upazila: upazila.trim(),
          address: address.trim(),
        },
        items: cart.map((c) => ({
          productId: c.productId,
          qty: c.qty,
          ...(c.variant ? { variant: c.variant } : {}),
        })),
        paymentMethod: payment,
        deliveryZone: zone,
        ...(couponCode ? { couponCode } : {}),
        ...(noteParts.length ? { notes: noteParts.join(" · ") } : {}),
      };
      const data = await postJSON<{ order: OrderDTO }>("/api/orders", payload);
      const order = data.order;
      clearCart();
      setLastOrder({ orderNumber: order.orderNumber, phone: order.phone });
      setPlaced({ orderNumber: order.orderNumber, total: order.total, phone: order.phone });
      window.scrollTo({ top: 0 });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "";
      toast.error(msg ? `${t("orderFailed")} (${msg})` : t("orderFailed"));
    } finally {
      setPlacing(false);
    }
  }

  function copyOrderNumber() {
    if (!placed) return;
    navigator.clipboard
      .writeText(placed.orderNumber)
      .then(() => toast.success(t("copied")))
      .catch(() => toast.error(t("orderFailed")));
  }

  // ── Success panel ─────────────────────────────────────────────────────────
  if (placed) {
    return (
      <div className="mx-auto max-w-2xl px-3 py-10 sm:px-4 sm:py-14">
        <div className="rounded-xl border bg-card p-6 text-center sm:p-10" role="status">
          <CheckCircle2 className="mx-auto h-16 w-16 text-emerald-500" aria-hidden="true" />
          <h1 className="mt-4 text-2xl font-bold text-foreground">{t("orderPlaced")}</h1>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted-foreground">
            {t("orderPlacedDesc")}
          </p>

          <div className="mx-auto mt-6 max-w-sm space-y-3">
            <div className="rounded-lg bg-muted px-4 py-3">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                {t("orderNumber")}
              </p>
              <div className="mt-1 flex items-center justify-center gap-2">
                <span className="font-mono text-xl font-bold tracking-wide text-foreground">
                  {placed.orderNumber}
                </span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8"
                  onClick={copyOrderNumber}
                  aria-label={t("copy")}
                >
                  <Copy className="h-4 w-4" aria-hidden="true" />
                </Button>
              </div>
            </div>
            <div className="flex items-center justify-between rounded-lg border px-4 py-3 text-sm">
              <span className="text-muted-foreground">{t("totalPaid")}</span>
              <span className="font-bold text-primary">{formatBDT(placed.total)}</span>
            </div>
          </div>

          <div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row">
            <Button
              onClick={() => navigate({ name: "tracking" })}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {t("trackOrderNow")}
            </Button>
            <Button variant="outline" onClick={() => navigate({ name: "home" })}>
              {t("continueShopping")}
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // ── Empty cart ────────────────────────────────────────────────────────────
  if (cart.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-3 py-10 sm:px-4 sm:py-16">
        <div className="rounded-xl border bg-card p-10 text-center">
          <ShoppingBag className="mx-auto h-14 w-14 text-muted-foreground/50" aria-hidden="true" />
          <h1 className="mt-4 text-lg font-bold text-foreground">{t("cartEmpty")}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{t("cartEmptyDesc")}</p>
          <Button
            onClick={() => navigate({ name: "home" })}
            className="mt-6 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            {t("continueShopping")}
          </Button>
        </div>
      </div>
    );
  }

  // ── Checkout form ─────────────────────────────────────────────────────────
  const mpayNoteKey = MPAY_NOTES[payment];

  return (
    <div className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
      <h1 className="text-2xl font-bold text-foreground">{t("checkout")}</h1>
      <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
        <User className="h-4 w-4" aria-hidden="true" />
        {t("haveAccount")}
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_380px]">
        {/* LEFT — stacked cards */}
        <div className="space-y-6">
          {/* ① Customer info */}
          <section className="rounded-xl border bg-card p-4 sm:p-6" aria-labelledby="ci-h">
            <h2 id="ci-h" className="mb-4 font-semibold text-foreground">{t("customerInfo")}</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="co-name">{t("fullName")}</Label>
                <div className="relative">
                  <User className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                  <Input
                    id="co-name"
                    className="pl-9"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={t("fullNamePh")}
                    autoComplete="name"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="co-phone">{t("phone")}</Label>
                <div className="relative">
                  <Phone className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
                  <Input
                    id="co-phone"
                    className="pl-9"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 11))}
                    placeholder={t("phonePh")}
                    inputMode="numeric"
                    autoComplete="tel"
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="co-division">{t("division")}</Label>
                <Select value={division} onValueChange={handleDivisionChange}>
                  <SelectTrigger id="co-division" className="w-full">
                    <SelectValue placeholder={t("selectDivision")} />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.keys(DIVISION_DISTRICTS).map((d) => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="co-district">{t("district")}</Label>
                <Select
                  value={district}
                  onValueChange={handleDistrictChange}
                  disabled={!division}
                >
                  <SelectTrigger id="co-district" className="w-full">
                    <SelectValue placeholder={t("selectDistrict")} />
                  </SelectTrigger>
                  <SelectContent>
                    {(DIVISION_DISTRICTS[division] ?? []).map((d) => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="co-upazila">{t("upazila")}</Label>
                <Input
                  id="co-upazila"
                  value={upazila}
                  onChange={(e) => setUpazila(e.target.value)}
                  placeholder={t("upazilaPh")}
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="co-address">{t("address")}</Label>
                <Textarea
                  id="co-address"
                  rows={3}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder={t("addressPh")}
                />
              </div>
            </div>
          </section>

          {/* ② Delivery method */}
          <section className="rounded-xl border bg-card p-4 sm:p-6" aria-labelledby="dm-h">
            <h2 id="dm-h" className="mb-4 font-semibold text-foreground">{t("deliveryMethod")}</h2>
            <RadioGroup
              value={zone}
              onValueChange={(v) => setZone(v as DeliveryZone)}
              className="grid gap-3 sm:grid-cols-2"
            >
              {(
                [
                  { id: "inside_dhaka" as DeliveryZone, icon: Truck, title: "insideDhaka", desc: "insideDhakaDesc" },
                  { id: "outside_dhaka" as DeliveryZone, icon: Truck, title: "outsideDhaka", desc: "outsideDhakaDesc" },
                ]
              ).map((z) => (
                <Label
                  key={z.id}
                  htmlFor={`zone-${z.id}`}
                  className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 font-normal transition-colors ${
                    zone === z.id ? "border-primary bg-primary/5" : "hover:bg-muted/50"
                  }`}
                >
                  <RadioGroupItem id={`zone-${z.id}`} value={z.id} className="mt-0.5" />
                  <span className="flex items-start gap-2">
                    <z.icon className="mt-0.5 h-4 w-4 text-primary" aria-hidden="true" />
                    <span>
                      <span className="block text-sm font-semibold text-foreground">{t(z.title)}</span>
                      <span className="mt-0.5 block text-xs text-muted-foreground">{t(z.desc)}</span>
                    </span>
                  </span>
                </Label>
              ))}
            </RadioGroup>
          </section>

          {/* ③ Payment method */}
          <section className="rounded-xl border bg-card p-4 sm:p-6" aria-labelledby="pm-h">
            <h2 id="pm-h" className="mb-4 font-semibold text-foreground">{t("paymentMethod")}</h2>
            <RadioGroup
              value={payment}
              onValueChange={(v) => setPayment(v as PaymentMethod)}
              className="grid gap-3 sm:grid-cols-2"
            >
              {(
                [
                  { id: "cod" as PaymentMethod, icon: Banknote, label: "cod", desc: "codDesc", dot: null, recommended: true },
                  { id: "bkash" as PaymentMethod, icon: Smartphone, label: "bkash", desc: "bkashDesc", dot: "#E2136E", recommended: false },
                  { id: "nagad" as PaymentMethod, icon: Smartphone, label: "nagad", desc: "nagadDesc", dot: "#F6921E", recommended: false },
                  { id: "rocket" as PaymentMethod, icon: Smartphone, label: "rocket", desc: "rocketDesc", dot: "#8C3494", recommended: false },
                  { id: "card" as PaymentMethod, icon: CreditCard, label: "card", desc: "cardDesc", dot: null, recommended: false },
                ]
              ).map((p) => (
                <Label
                  key={p.id}
                  htmlFor={`pay-${p.id}`}
                  className={`flex cursor-pointer items-start gap-3 rounded-xl border p-4 font-normal transition-colors ${
                    payment === p.id ? "border-primary bg-primary/5" : "hover:bg-muted/50"
                  }`}
                >
                  <RadioGroupItem id={`pay-${p.id}`} value={p.id} className="mt-0.5" />
                  <span className="flex items-start gap-2">
                    <p.icon className="mt-0.5 h-4 w-4 text-primary" aria-hidden="true" />
                    <span>
                      <span className="flex flex-wrap items-center gap-1.5">
                        <span className="text-sm font-semibold text-foreground">{t(p.label)}</span>
                        {p.dot && (
                          <span
                            className="inline-block h-2 w-2 rounded-full"
                            style={{ backgroundColor: p.dot }}
                            aria-hidden="true"
                          />
                        )}
                        {p.recommended && (
                          <Badge className="border-transparent bg-emerald-100 text-emerald-700 hover:bg-emerald-100">
                            {t("recommended")}
                          </Badge>
                        )}
                      </span>
                      <span className="mt-0.5 block text-xs text-muted-foreground">{t(p.desc)}</span>
                    </span>
                  </span>
                </Label>
              ))}
            </RadioGroup>

            {mpayNoteKey && (
              <div className="mt-4 space-y-3 rounded-lg border border-amber-200 bg-amber-50 p-3" role="note">
                <p className="text-sm text-amber-800">{t(mpayNoteKey)}</p>
                <Input
                  value={trxId}
                  onChange={(e) => setTrxId(e.target.value)}
                  placeholder={t("transactionIdPh")}
                  aria-label={t("transactionId")}
                  className="border-amber-300 bg-white"
                />
              </div>
            )}
            {payment === "card" && (
              <div className="mt-4 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800" role="note">
                {t("cardRedirect")}
              </div>
            )}
          </section>

          {/* ④ Notes */}
          <section className="rounded-xl border bg-card p-4 sm:p-6" aria-labelledby="nt-h">
            <h2 id="nt-h" className="mb-4 font-semibold text-foreground">{t("notes")}</h2>
            <Textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={t("notesPh")}
            />
          </section>
        </div>

        {/* RIGHT — order summary */}
        <div className="self-start lg:sticky lg:top-24">
          <section className="rounded-xl border bg-card p-4 sm:p-6" aria-labelledby="os-h">
            <h2 id="os-h" className="mb-4 font-semibold text-foreground">{t("orderSummary")}</h2>

            <ul className="space-y-3">
              {cart.map((item) => (
                <li key={`${item.productId}-${item.variant ?? ""}`} className="flex items-center gap-3">
                  { }
                  <img
                    src={item.image}
                    alt={item.nameEn}
                    className="h-14 w-14 shrink-0 rounded-lg border object-cover"
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-foreground">
                      {lang === "bn" ? item.nameBn : item.nameEn}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {item.qty} × {formatBDT(item.price)}
                    </p>
                  </div>
                  <span className="text-sm font-semibold text-foreground">
                    {formatBDT(item.qty * item.price)}
                  </span>
                </li>
              ))}
            </ul>

            <Separator className="my-4" />

            <dl className="space-y-2 text-sm">
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">{t("cartSubtotal")}</dt>
                <dd className="font-medium text-foreground">{formatBDT(subtotal)}</dd>
              </div>
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">{t("deliveryFee")}</dt>
                <dd className="font-medium text-foreground">{formatBDT(fee)}</dd>
              </div>
              {discount > 0 && (
                <div className="flex items-center justify-between">
                  <dt className="text-muted-foreground">{t("couponCode")}</dt>
                  <dd className="font-medium text-emerald-600">-{formatBDT(discount)}</dd>
                </div>
              )}
            </dl>

            {/* Coupon */}
            <div className="mt-4">
              {couponCode ? (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
                  {couponCode}
                  <button
                    type="button"
                    onClick={removeCoupon}
                    aria-label={t("remove")}
                    className="rounded-full p-0.5 hover:bg-emerald-100"
                  >
                    <X className="h-3 w-3" aria-hidden="true" />
                  </button>
                </span>
              ) : (
                <div className="flex gap-2">
                  <Input
                    value={couponInput}
                    onChange={(e) => setCouponInput(e.target.value.toUpperCase())}
                    placeholder={t("couponPh")}
                    aria-label={t("couponCode")}
                    className="h-9 flex-1"
                  />
                  <Button variant="outline" size="sm" className="h-9" disabled={applying} onClick={applyCoupon}>
                    {applying ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : t("apply")}
                  </Button>
                </div>
              )}
            </div>

            <Separator className="my-4" />

            <div className="flex items-center justify-between">
              <span className="font-semibold text-foreground">{t("total")}</span>
              <span className="text-lg font-bold text-primary">{formatBDT(total)}</span>
            </div>

            <Button
              onClick={placeOrder}
              disabled={placing}
              className="mt-4 h-11 w-full bg-cta text-cta-foreground hover:bg-cta/90"
            >
              {placing ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  {t("placing")}
                </>
              ) : (
                t("placeOrder")
              )}
            </Button>
          </section>
        </div>
      </div>
    </div>
  );
}

export default CheckoutView;
