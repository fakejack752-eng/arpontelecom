"use client";
// ─── Arpon Telecom — HOME VIEW (data fetching + section composition) ────────
import { useEffect, useState } from "react";

import { Skeleton } from "@/components/ui/skeleton";
import { getJSON } from "@/lib/api";
import { useStore } from "@/lib/store";
import type { CategoryDTO, ProductDTO } from "@/lib/types";
import BrandStrip from "../home/brand-strip";
import CategoryGrid from "../home/category-grid";
import FlashDeals from "../home/flash-deals";
import HeroSlider from "../home/hero-slider";
import Newsletter from "../home/newsletter";
import ProductSection from "../home/product-section";
import Testimonials from "../home/testimonials";
import WhyChooseUs from "../home/why-choose-us";
import TwsSpotlight from "../home/tws-spotlight";
import { Reveal } from "../motion/reveal";

interface HomeData {
  categories: CategoryDTO[];
  flash: ProductDTO[];
  newArrivals: ProductDTO[];
  bestSellers: ProductDTO[];
}

const EMPTY_DATA: HomeData = {
  categories: [],
  flash: [],
  newArrivals: [],
  bestSellers: [],
};

/* ── Skeletons (shown while data loads) ─────────────────────────────────── */

function HeroSkeleton() {
  return (
    <Skeleton className="h-[220px] w-full rounded-2xl sm:h-[300px] md:h-[380px]" />
  );
}

function CategoryGridSkeleton() {
  return (
    <div aria-hidden="true">
      <Skeleton className="mb-5 h-8 w-52" />
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-5 lg:grid-cols-10">
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (
          <div
            key={i}
            className="flex flex-col items-center gap-2 rounded-xl border bg-card p-3 sm:p-4"
          >
            <Skeleton className="h-10 w-10 rounded-full sm:h-12 sm:w-12" />
            <Skeleton className="h-3 w-12" />
          </div>
        ))}
      </div>
    </div>
  );
}

function FlashDealsSkeleton() {
  return (
    <div aria-hidden="true" className="rounded-2xl border border-cta/20 bg-card p-4 sm:p-6">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <Skeleton className="h-10 w-10 rounded-full" />
          <div>
            <Skeleton className="h-6 w-36" />
            <Skeleton className="mt-1.5 h-4 w-48" />
          </div>
        </div>
        <Skeleton className="hidden h-9 w-44 rounded-lg sm:block" />
      </div>
      <div className="mt-4 flex gap-3 overflow-hidden">
        {[0, 1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-72 w-40 shrink-0 rounded-xl sm:w-48" />
        ))}
      </div>
    </div>
  );
}

function ProductGridSkeleton() {
  return (
    <div aria-hidden="true">
      <div className="mb-5">
        <Skeleton className="h-8 w-44" />
        <Skeleton className="mt-1.5 h-4 w-64" />
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
        {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (
          <div key={i} className="rounded-xl border bg-card p-3">
            <Skeleton className="aspect-square w-full rounded-lg" />
            <Skeleton className="mt-2 h-3 w-1/3" />
            <Skeleton className="mt-1.5 h-4 w-3/4" />
            <Skeleton className="mt-2 h-9 w-full rounded-md" />
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── HomeView ───────────────────────────────────────────────────────────── */

export default function HomeView() {
  const navigate = useStore((s) => s.navigate);
  const [data, setData] = useState<HomeData>(EMPTY_DATA);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    const fetchOne = async <T,>(url: string, fallback: T): Promise<T> => {
      try {
        return await getJSON<T>(url);
      } catch (err) {
        console.error(`HomeView: fetch failed for ${url}`, err);
        return fallback;
      }
    };

    (async () => {
      const [catsRes, flashRes, newRes, bestRes] = await Promise.all([
        fetchOne<{ categories: CategoryDTO[] }>("/api/categories", {
          categories: [],
        }),
        fetchOne<{ products: ProductDTO[] }>(
          "/api/products?flag=flash&limit=8",
          { products: [] }
        ),
        fetchOne<{ products: ProductDTO[] }>("/api/products?flag=new&limit=8", {
          products: [],
        }),
        fetchOne<{ products: ProductDTO[] }>(
          "/api/products?flag=best&limit=8",
          { products: [] }
        ),
      ]);

      if (!active) return;
      setData({
        categories: catsRes.categories ?? [],
        flash: flashRes.products ?? [],
        newArrivals: newRes.products ?? [],
        bestSellers: bestRes.products ?? [],
      });
      setLoading(false);
    })();

    return () => {
      active = false;
    };
  }, []);

  return (
    <div>
      {/* Hero (own container so the slider stays a rounded box) */}
      <div className="mx-auto max-w-7xl px-3 pt-4 sm:px-4 lg:px-6">
        {loading ? <HeroSkeleton /> : <HeroSlider />}
      </div>

      {/* Sections */}
      <div className="mx-auto max-w-7xl space-y-8 px-3 py-6 sm:space-y-10 sm:px-4 lg:px-6">
        {loading ? (
          <CategoryGridSkeleton />
        ) : (
          data.categories.length > 0 && (
            <Reveal>
              <CategoryGrid categories={data.categories} />
            </Reveal>
          )
        )}

        {loading ? (
          <FlashDealsSkeleton />
        ) : (
          data.flash.length > 0 && (
            <Reveal>
              <FlashDeals products={data.flash} />
            </Reveal>
          )
        )}

        <TwsSpotlight />

        {loading ? (
          <ProductGridSkeleton />
        ) : (
          <Reveal>
            <ProductSection
              titleKey="section_new"
              subtitleKey="section_new_sub"
              products={data.newArrivals}
              onViewAll={() => navigate({ name: "shop" })}
            />
          </Reveal>
        )}

        <Reveal>
          <BrandStrip />
        </Reveal>

        {loading ? (
          <ProductGridSkeleton />
        ) : (
          <Reveal>
            <ProductSection
              titleKey="section_best"
              subtitleKey="section_best_sub"
              products={data.bestSellers}
              onViewAll={() => navigate({ name: "shop" })}
            />
          </Reveal>
        )}

        <Reveal>
          <WhyChooseUs />
        </Reveal>
        <Reveal>
          <Testimonials />
        </Reveal>
        <Reveal>
          <Newsletter />
        </Reveal>
      </div>
    </div>
  );
}
