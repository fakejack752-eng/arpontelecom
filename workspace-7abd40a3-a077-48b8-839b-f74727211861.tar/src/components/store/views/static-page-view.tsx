"use client";
// ─── Arpon Telecom — static pages (about / contact / faq / policies) ────────
import { useState } from "react";
import { toast } from "sonner";
import {
  BadgeCheck,
  Clock,
  Facebook,
  HeartHandshake,
  Instagram,
  Loader2,
  Mail,
  MapPin,
  Phone,
  ShieldCheck,
  Truck,
  Youtube,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HOTLINE_NUMBER, useStore, type PageSlug } from "@/lib/store";
import { useT } from "@/lib/i18n";
import { isValidBDPhone } from "@/lib/format";
import { postJSON } from "@/lib/api";

const TITLES: Record<PageSlug, string> = {
  about: "aboutTitle",
  contact: "contactTitle",
  faq: "faqTitle",
  warranty: "warrantyTitle",
  privacy: "privacyTitle",
  terms: "termsTitle",
};

// ─── About ──────────────────────────────────────────────────────────────────
const ABOUT_PARAS: Record<"en" | "bn", string[]> = {
  en: [
    "Arpon Telecom is a trusted mobile & gadget shop in Dhaka, Bangladesh. Founded in 2020, we started with a small counter in Rapa Plaza, Dhanmondi — and today we serve more than 10,000 happy customers across the country, both from our physical shop and through our online store.",
    "Every phone, tablet and accessory we sell is 100% genuine and sourced through official channels, backed by the manufacturer's official warranty. Our team verifies IMEI numbers, warranty registration and box seals before any device reaches your hands — so you never have to worry about refurbished or gray-market units.",
    "We deliver to all 64 districts of Bangladesh within 24–72 hours, with cash on delivery, bKash, Nagad, Rocket and card payment options. Whether you visit us at Shop 12, Rapa Plaza, Mirpur Road, Dhanmondi or order online, you get the same honest advice, fair prices and after-sales support that made us who we are.",
  ],
  bn: [
    "আরপন টেলিকম ঢাকা, বাংলাদেশের একটি বিশ্বস্ত মোবাইল ও গ্যাজেট শপ। ২০২০ সালে ধানমন্ডির রাপা প্লাজায় ছোট একটি কাউন্টার দিয়ে যাত্রা শুরু — আজ আমাদের ফিজিক্যাল দোকান ও অনলাইন স্টোর মিলিয়ে সারাদেশে ১০,০০০-এর বেশি সন্তুষ্ট কাস্টমার রয়েছে।",
    "আমরা যে ফোন, ট্যাবলেট ও অ্যাক্সেসরিজ বিক্রি করি প্রতিটিই ১০০% জেনুইন এবং অফিসিয়াল চ্যানেলে সংগৃহীত, সাথে থাকে ম্যানুফ্যাকচারারের অফিসিয়াল ওয়ারেন্টি। কোনো ডিভাইস আপনার হাতে পৌঁছানোর আগেই আমাদের টিম IMEI নম্বর, ওয়ারেন্টি রেজিস্ট্রেশন ও বক্স সিল যাচাই করে — তাই রিফার্বিশড বা গ্রে-মার্কেট প্রোডাক্ট নিয়ে ভাবতে হবে না।",
    "আমরা ২৪–৭২ ঘণ্টায় বাংলাদেশের ৬৪ জেলায় ডেলিভারি দিই, সাথে থাকে ক্যাশ অন ডেলিভারি, বিকাশ, নগদ, রকেট ও কার্ড পেমেন্ট। দোকানে সরাসরি আসুন (দোকান ১২, রাপা প্লাজা, মিরপুর রোড, ধানমন্ডি) বা অনলাইনে অর্ডার করুন — দুই ক্ষেত্রেই পাবেন একই সৎ পরামর্শ, ন্যায্য দাম ও সেলস-আফটার সাপোর্ট।",
  ],
};

const ABOUT_STATS: { value: string; en: string; bn: string }[] = [
  { value: "28+", en: "Products", bn: "প্রোডাক্ট" },
  { value: "10k+", en: "Happy Customers", bn: "সন্তুষ্ট কাস্টমার" },
  { value: "64", en: "Districts Delivery", bn: "জেলায় ডেলিভারি" },
  { value: "4.9", en: "Average Rating", bn: "গড় রেটিং" },
];

const VALUES = [
  { icon: BadgeCheck, title: "why_genuine", desc: "why_genuine_desc" },
  { icon: ShieldCheck, title: "why_warranty", desc: "why_warranty_desc" },
  { icon: Truck, title: "why_delivery", desc: "why_delivery_desc" },
  { icon: HeartHandshake, title: "why_return", desc: "why_return_desc" },
] as const;

function AboutSection({ lang }: { lang: "en" | "bn" }) {
  const t = useT();
  return (
    <>
      <div className="space-y-4 leading-relaxed text-muted-foreground">
        {ABOUT_PARAS[lang].map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        {ABOUT_STATS.map((s) => (
          <div key={s.en} className="rounded-xl border bg-muted/40 p-4 text-center">
            <p className="text-2xl font-bold text-primary">{s.value}</p>
            <p className="mt-1 text-xs text-muted-foreground">{lang === "bn" ? s.bn : s.en}</p>
          </div>
        ))}
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {VALUES.map((v) => (
          <div key={v.title} className="flex items-start gap-3 rounded-xl border p-4">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
              <v.icon className="h-5 w-5 text-primary" aria-hidden="true" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-foreground">{t(v.title)}</h3>
              <p className="mt-0.5 text-sm text-muted-foreground">{t(v.desc)}</p>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// ─── Contact ────────────────────────────────────────────────────────────────
function ContactSection() {
  const t = useT();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (sending) return;
    if (!name.trim() || !message.trim()) {
      toast.error(t("fillAllFields"));
      return;
    }
    if (!isValidBDPhone(phone)) {
      toast.error(t("phoneInvalid"));
      return;
    }
    setSending(true);
    try {
      await postJSON("/api/contact", {
        name: name.trim(),
        phone: phone.trim(),
        email: email.trim() || undefined,
        message: message.trim(),
      });
      toast.success(t("messageSent"));
      setName("");
      setPhone("");
      setEmail("");
      setMessage("");
    } catch (err) {
      const msg = err instanceof Error ? err.message : "";
      toast.error(msg || t("orderFailed"));
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {/* Info card */}
      <div className="space-y-4">
        <ul className="space-y-4">
          <li className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
              <MapPin className="h-5 w-5 text-primary" aria-hidden="true" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-foreground">{t("ourAddress")}</h3>
              <p className="text-sm text-muted-foreground">{t("shopAddress")}</p>
            </div>
          </li>
          <li className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
              <Phone className="h-5 w-5 text-primary" aria-hidden="true" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-foreground">{t("hotline")}</h3>
              <a href={`tel:${HOTLINE_NUMBER}`} className="text-sm text-muted-foreground hover:text-primary">
                {HOTLINE_NUMBER}
              </a>
            </div>
          </li>
          <li className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
              <Mail className="h-5 w-5 text-primary" aria-hidden="true" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-foreground">Email</h3>
              <a href="mailto:support@arpontelecom.store" className="text-sm text-muted-foreground hover:text-primary">
                support@arpontelecom.store
              </a>
            </div>
          </li>
          <li className="flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-primary/10">
              <Clock className="h-5 w-5 text-primary" aria-hidden="true" />
            </span>
            <div>
              <h3 className="text-sm font-semibold text-foreground">{t("shopHours")}</h3>
            </div>
          </li>
        </ul>

        {/* Map placeholder */}
        <div className="flex h-40 flex-col items-center justify-center gap-3 rounded-xl border bg-gradient-to-br from-primary/10 to-cta/10">
          <MapPin className="h-8 w-8 text-primary" aria-hidden="true" />
          <Button asChild size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
            <a
              href="https://maps.google.com/?q=Rapa+Plaza+Dhanmondi+Dhaka"
              target="_blank"
              rel="noopener noreferrer"
            >
              {t("openInMaps")}
            </a>
          </Button>
        </div>

        {/* Socials */}
        <div className="flex items-center gap-2">
          {[
            { icon: Facebook, label: "Facebook", href: "https://facebook.com" },
            { icon: Instagram, label: "Instagram", href: "https://instagram.com" },
            { icon: Youtube, label: "YouTube", href: "https://youtube.com" },
          ].map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={s.label}
              className="flex h-9 w-9 items-center justify-center rounded-full border text-muted-foreground transition-colors hover:border-primary hover:bg-primary/5 hover:text-primary"
            >
              <s.icon className="h-4 w-4" aria-hidden="true" />
            </a>
          ))}
        </div>
      </div>

      {/* Form */}
      <form onSubmit={submit} className="space-y-4" noValidate>
        <div className="space-y-1.5">
          <Label htmlFor="ct-name">{t("yourName")}</Label>
          <Input id="ct-name" value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="ct-phone">{t("phone")}</Label>
          <Input
            id="ct-phone"
            value={phone}
            onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 11))}
            placeholder={t("phonePh")}
            inputMode="numeric"
            autoComplete="tel"
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="ct-email">{t("yourEmail")}</Label>
          <Input id="ct-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="ct-msg">{t("yourMessage")}</Label>
          <Textarea id="ct-msg" rows={5} value={message} onChange={(e) => setMessage(e.target.value)} />
        </div>
        <Button
          type="submit"
          disabled={sending}
          className="w-full bg-cta text-cta-foreground hover:bg-cta/90 sm:w-auto"
        >
          {sending ? (
            <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
          ) : (
            t("sendMessage")
          )}
        </Button>
      </form>
    </div>
  );
}

// ─── FAQ ────────────────────────────────────────────────────────────────────
const FAQS: { qEn: string; aEn: string; qBn: string; aBn: string }[] = [
  {
    qEn: "How do I place an order?",
    aEn: "Browse the shop, add products to your cart, and go to checkout. Fill in your name, phone and address — no account needed. You can pay cash on delivery or with bKash, Nagad, Rocket or card.",
    qBn: "অর্ডার করব কীভাবে?",
    aBn: "শপ থেকে পছন্দের প্রোডাক্ট কার্টে যোগ করে চেকআউটে যান। নাম, ফোন ও ঠিকানা দিন — অ্যাকাউন্ট লাগবে না। ক্যাশ অন ডেলিভারি অথবা বিকাশ, নগদ, রকেট বা কার্ডে পেমেন্ট করতে পারবেন।",
  },
  {
    qEn: "How long does delivery take?",
    aEn: "Inside Dhaka: 1–2 working days (৳60). Outside Dhaka: 2–4 working days (৳120). We deliver to all 64 districts through our courier partners.",
    qBn: "ডেলিভারিতে কত সময় লাগে?",
    aBn: "ঢাকার ভিতরে: ১–২ কর্মদিবস (৳৬০)। ঢাকার বাইরে: ২–৪ কর্মদিবস (৳১২০)। আমাদের কুরিয়ার পার্টনারদের মাধ্যমে ৬৪ জেলাতেই ডেলিভারি দিই।",
  },
  {
    qEn: "Which payment methods do you accept?",
    aEn: "Cash on Delivery (recommended), bKash, Nagad, Rocket and cards via SSLCommerz. For mobile payments, keep the TrxID to share with our delivery team.",
    qBn: "কোন কোন পেমেন্ট মাধ্যম ব্যবহার করা যায়?",
    aBn: "ক্যাশ অন ডেলিভারি (প্রস্তাবিত), বিকাশ, নগদ, রকেট এবং SSLCommerz-এর মাধ্যমে কার্ড। মোবাইল ব্যাংকিংয়ে পেমেন্ট করলে ডেলিভারি ম্যানকে TrxID দেখানোর জন্য সংরক্ষণ করুন।",
  },
  {
    qEn: "Do products come with warranty?",
    aEn: "Yes. Phones include a 1-year official manufacturer warranty and most accessories include 6 months. Warranty cards are provided with every purchase and valid at authorized service centers nationwide.",
    qBn: "প্রোডাক্টে কি ওয়ারেন্টি থাকে?",
    aBn: "হ্যাঁ। ফোনে থাকে ১ বছরের অফিসিয়াল ম্যানুফ্যাকচারার ওয়ারেন্টি এবং বেশিরভাগ অ্যাক্সেসরিজে ৬ মাস। প্রতিটি কেনাকাটায় ওয়ারেন্টি কার্ড দেওয়া হয়, যা সারাদেশের অনুমোদিত সার্ভিস সেন্টারে বৈধ।",
  },
  {
    qEn: "What is your return policy?",
    aEn: "You can request a replacement or return within 7 days of delivery if the product has a manufacturing defect. The product must be unused with all accessories and the box intact. For details see our Warranty & Returns page.",
    qBn: "রিটার্ন পলিসি কী?",
    aBn: "ডেলিভারির ৭ দিনের মধ্যে ম্যানুফ্যাকচারিং ত্রুটি থাকলে রিপ্লেসমেন্ট বা রিটার্ন চাইতে পারবেন। প্রোডাক্ট অব্যবহৃত থাকতে হবে, সব অ্যাক্সেসরিজ ও বক্স অক্ষতসহ। বিস্তারিত জানতে আমাদের ওয়ারেন্টি ও রিটার্ন পেজ দেখুন।",
  },
  {
    qEn: "Are your products genuine?",
    aEn: "Absolutely — 100%. All products come from official distributors with verifiable IMEI and warranty registration. You can check anything in front of our staff before paying.",
    qBn: "প্রোডাক্টগুলো কি জেনুইন?",
    aBn: "অবশ্যই — ১০০%। সব প্রোডাক্ট অফিসিয়াল ডিস্ট্রিবিউটরের কাছ থেকে আসে, যাচাইযোগ্য IMEI ও ওয়ারেন্টি রেজিস্ট্রেশনসহ। চাইলে টাকা দেওয়ার আগে আমাদের স্টাফের সামনে যাচাই করে নিতে পারবেন।",
  },
  {
    qEn: "How can I track my order?",
    aEn: "Go to the Track Order page, enter your phone number and the order number from your confirmation, and you will see live status: pending → confirmed → shipped → delivered.",
    qBn: "অর্ডার কীভাবে ট্র্যাক করব?",
    aBn: "অর্ডার ট্র্যাক পেজে যান, আপনার ফোন নম্বর ও কনফার্মেশনে পাওয়া অর্ডার নম্বর দিন — লাইভ স্ট্যাটাস দেখতে পাবেন: পেন্ডিং → কনফার্মড → শিপড → ডেলিভারড।",
  },
  {
    qEn: "How can I contact support?",
    aEn: "Call our hotline 01712-345678 (Sat–Thu, 10AM–9PM), message us on WhatsApp, use the contact form on this site, or visit our shop at Rapa Plaza, Dhanmondi.",
    qBn: "সাপোর্টে কীভাবে যোগাযোগ করব?",
    aBn: "হটলাইন ০১৭১২-৩৪৫৬৭৮ (শনি–বৃহস্পতি, সকাল ১০টা–রাত ৯টা) নম্বরে কল করুন, WhatsApp-এ মেসেজ দিন, এই সাইটের কন্টাক্ট ফর্ম ব্যবহার করুন অথবা রাপা প্লাজা, ধানমন্ডির দোকানে আসুন।",
  },
];

function FaqSection({ lang }: { lang: "en" | "bn" }) {
  return (
    <Accordion type="single" collapsible className="w-full">
      {FAQS.map((f, i) => (
        <AccordionItem key={i} value={`faq-${i}`}>
          <AccordionTrigger className="text-sm font-medium sm:text-base">
            {lang === "bn" ? f.qBn : f.qEn}
          </AccordionTrigger>
          <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
            {lang === "bn" ? f.aBn : f.aEn}
          </AccordionContent>
        </AccordionItem>
      ))}
    </Accordion>
  );
}

// ─── Policies (warranty / privacy / terms) ──────────────────────────────────
interface PolicySection {
  h: string;
  ps: string[];
}

const WARRANTY_POLICY: Record<"en" | "bn", PolicySection[]> = {
  en: [
    {
      h: "7-Day Replacement & Return",
      ps: [
        "If a product has a manufacturing defect, you may request a replacement or return within 7 days of delivery. The product must be unused, with all included accessories, free gifts and the original box intact.",
        "Refunds for accepted returns are issued via bKash/Nagad or store credit within 3–5 working days of receiving the item at our shop. Delivery fees are non-refundable unless the defect is ours.",
      ],
    },
    {
      h: "Official Warranty",
      ps: [
        "All phones carry a 1-year official manufacturer warranty; most accessories carry 6 months. The warranty card provided with your purchase is valid at all authorized service centers in Bangladesh.",
        "Warranty covers manufacturing defects only. Physical damage, water damage, unauthorized repair and burnt charging ports are not covered.",
      ],
    },
    {
      h: "Conditions",
      ps: [
        "A valid warranty card and original invoice are required for any warranty claim. IMEI on the device must match our records.",
        "Software issues, factory resets and data loss are not covered by hardware warranty; our service desk can assist with basic setup free of charge.",
      ],
    },
    {
      h: "How to Claim",
      ps: [
        "Call our hotline (01712-345678) or visit Shop 12, Rapa Plaza, Dhanmondi with the product, warranty card and invoice. Our team will verify the issue and forward it to the authorized service center, usually resolving within 3–7 working days.",
      ],
    },
  ],
  bn: [
    {
      h: "৭ দিনের রিপ্লেসমেন্ট ও রিটার্ন",
      ps: [
        "প্রোডাক্টে ম্যানুফ্যাকচারিং ত্রুটি থাকলে ডেলিভারির ৭ দিনের মধ্যে রিপ্লেসমেন্ট বা রিটার্ন চাইতে পারবেন। প্রোডাক্ট অব্যবহৃত থাকতে হবে; সব অ্যাক্সেসরিজ, ফ্রি গিফট ও অরিজিনাল বক্স অক্ষত থাকতে হবে।",
        "গৃহীত রিটার্নের টাকা বিকাশ/নগদ বা স্টোর ক্রেডিটে ৩–৫ কর্মদিবসের মধ্যে ফেরত দেওয়া হয়। ত্রুটি আমাদের দিক থেকে হলে ছাড়া ডেলিভারি চার্জ ফেরতযোগ্য নয়।",
      ],
    },
    {
      h: "অফিসিয়াল ওয়ারেন্টি",
      ps: [
        "সব ফোনে ১ বছরের অফিসিয়াল ম্যানুফ্যাকচারার ওয়ারেন্টি এবং বেশিরভাগ অ্যাক্সেসরিজে ৬ মাসের ওয়ারেন্টি থাকে। কেনার সময় দেওয়া ওয়ারেন্টি কার্ড বাংলাদেশের সব অনুমোদিত সার্ভিস সেন্টারে বৈধ।",
        "ওয়ারেন্টি শুধু ম্যানুফ্যাকচারিং ত্রুটি কভার করে। শারীরিক ক্ষতি, পানিতে ক্ষতি, অননুমোদিত মেরামত ও পোড়া চার্জিং পোর্ট কভার হয় না।",
      ],
    },
    {
      h: "শর্তাবলী",
      ps: [
        "যেকোনো ওয়ারেন্টি ক্লেইমের জন্য বৈধ ওয়ারেন্টি কার্ড ও অরিজিনাল ইনভয়েস লাগবে। ডিভাইসের IMEI আমাদের রেকর্ডের সাথে মিলতে হবে।",
        "সফটওয়্যার সমস্যা, ফ্যাক্টরি রিসেট ও ডেটা লস হার্ডওয়্যার ওয়ারেন্টিতে কভার হয় না; বেসিক সেটআপে আমাদের সার্ভিস ডেস্ক ফ্রিতে সাহায্য করে।",
      ],
    },
    {
      h: "ক্লেইম করবেন যেভাবে",
      ps: [
        "হটলাইনে (০১৭১২-৩৪৫৬৭৮) কল করুন অথবা প্রোডাক্ট, ওয়ারেন্টি কার্ড ও ইনভয়েসসহ দোকান ১২, রাপা প্লাজা, ধানমন্ডিতে আসুন। আমাদের টিম সমস্যা যাচাই করে অনুমোদিত সার্ভিস সেন্টারে পাঠায়; সাধারণত ৩–৭ কর্মদিবসে সমাধান হয়।",
      ],
    },
  ],
};

const PRIVACY_POLICY: Record<"en" | "bn", PolicySection[]> = {
  en: [
    {
      h: "Information We Collect",
      ps: [
        "When you place an order or contact us, we collect your name, phone number, delivery address, and optionally your email. This is the minimum needed to deliver your order and reach you about it.",
      ],
    },
    {
      h: "How We Use Your Data",
      ps: [
        "We use your information only to process orders, arrange delivery, provide customer support, and — if you subscribe — send occasional offer updates. We never sell or rent your data to third parties.",
      ],
    },
    {
      h: "Cookies",
      ps: [
        "Our store uses minimal browser storage (localStorage) to remember your cart, wishlist and language preference. No advertising or cross-site tracking cookies are used.",
      ],
    },
    {
      h: "Data Sharing & Security",
      ps: [
        "Delivery details are shared only with our courier partners for shipment. Payment processing goes through verified providers (bKash, Nagad, Rocket, SSLCommerz); we never store your card details.",
      ],
    },
    {
      h: "Your Rights",
      ps: [
        "You may ask us to correct or delete your personal data anytime by calling the hotline or emailing support@arpontelecom.store.",
      ],
    },
  ],
  bn: [
    {
      h: "যে তথ্য আমরা সংগ্রহ করি",
      ps: [
        "অর্ডার করার সময় বা যোগাযোগ করলে আমরা আপনার নাম, ফোন নম্বর, ডেলিভারি ঠিকানা এবং ঐচ্ছিকভাবে ইমেইল সংগ্রহ করি। অর্ডার ডেলিভারি ও যোগাযোগের জন্য এটুকুই প্রয়োজন।",
      ],
    },
    {
      h: "তথ্য যেভাবে ব্যবহার করি",
      ps: [
        "আপনার তথ্য শুধু অর্ডার প্রসেস, ডেলিভারি আয়োজন, কাস্টমার সাপোর্ট এবং — সাবস্ক্রাইব করলে — মাঝে মাঝে অফারের খবর পাঠাতে ব্যবহার করি। আপনার ডেটা কখনো তৃতীয় পক্ষকে বিক্রি বা ভাড়া দিই না।",
      ],
    },
    {
      h: "কুকিজ",
      ps: [
        "আমাদের স্টোর কার্ট, উইশলিস্ট ও ভাষা মনে রাখতে সামান্য ব্রাউজার স্টোরেজ (localStorage) ব্যবহার করে। কোনো বিজ্ঞাপন বা ক্রস-সাইট ট্র্যাকিং কুকিজ ব্যবহার করা হয় না।",
      ],
    },
    {
      h: "ডেটা শেয়ারিং ও নিরাপত্তা",
      ps: [
        "ডেলিভারির তথ্য শুধু আমাদের কুরিয়ার পার্টনারদের সাথে শেয়ার করা হয়। পেমেন্ট প্রসেসিং যায় যাচাইকৃত প্রোভাইডারের (বিকাশ, নগদ, রকেট, SSLCommerz) মাধ্যমে; আপনার কার্ডের তথ্য কখনো সংরক্ষণ করি না।",
      ],
    },
    {
      h: "আপনার অধিকার",
      ps: [
        "যেকোনো সময় হটলাইনে কল করে বা support@arpontelecom.store-এ ইমেইল করে আপনার ব্যক্তিগত তথ্য সংশোধন বা মুছে ফেলার অনুরোধ করতে পারেন।",
      ],
    },
  ],
};

const TERMS_POLICY: Record<"en" | "bn", PolicySection[]> = {
  en: [
    {
      h: "Pricing & Orders",
      ps: [
        "All prices are in Bangladeshi Taka and include VAT where applicable. We reserve the right to correct pricing errors; if a listed price is clearly wrong, we will contact you before processing the order.",
        "An order is confirmed only after our team verifies stock and reaches you by phone. Prices and availability may change without prior notice.",
      ],
    },
    {
      h: "Payment",
      ps: [
        "We accept Cash on Delivery, bKash, Nagad, Rocket and cards via SSLCommerz. For advance mobile payments, the transaction must be made to the official numbers shown at checkout only.",
      ],
    },
    {
      h: "Warranty & Returns",
      ps: [
        "Warranty and return terms follow our Warranty & Return Policy (see the dedicated page). Products damaged by the customer are not eligible for return or free repair.",
      ],
    },
    {
      h: "Liability",
      ps: [
        "Arpon Telecom is not liable for delays caused by couriers, natural events, or network/operator service interruptions. Our maximum liability for any order is limited to the amount paid for that order.",
      ],
    },
    {
      h: "Changes to These Terms",
      ps: [
        "We may update these terms occasionally. Continued use of the store after changes means you accept the updated terms.",
      ],
    },
  ],
  bn: [
    {
      h: "মূল্য ও অর্ডার",
      ps: [
        "সব দাম বাংলাদেশি টাকায় এবং প্রযোজ্য ক্ষেত্রে VAT অন্তর্ভুক্ত। মূল্য-ত্রুটি সংশোধনের অধিকার আমরা সংরক্ষণ করি; তালিকাভুক্ত দাম স্পষ্টভাবে ভুল হলে অর্ডার প্রসেসের আগে আপনার সাথে যোগাযোগ করব।",
        "আমাদের টিম স্টক যাচাই করে এবং ফোনে যোগাযোগ করার পরেই অর্ডার কনফার্ম হয়। আগাম নোটিশ ছাড়া দাম ও স্টক পরিবর্তন হতে পারে।",
      ],
    },
    {
      h: "পেমেন্ট",
      ps: [
        "আমরা ক্যাশ অন ডেলিভারি, বিকাশ, নগদ, রকেট ও SSLCommerz-এর মাধ্যমে কার্ড গ্রহণ করি। অগ্রিম মোবাইল পেমেন্ট শুধুমাত্র চেকআউটে দেখানো অফিসিয়াল নম্বরেই করতে হবে।",
      ],
    },
    {
      h: "ওয়ারেন্টি ও রিটার্ন",
      ps: [
        "ওয়ারেন্টি ও রিটার্নের শর্ত আমাদের ওয়ারেন্টি ও রিটার্ন পলিসি অনুযায়ী (দেখুন নির্দিষ্ট পেজ)। কাস্টমারের অসাবধানতায় ক্ষতিগ্রস্ত প্রোডাক্ট রিটার্ন বা ফ্রি মেরামতের আওতাভুক্ত নয়।",
      ],
    },
    {
      h: "দায়বদ্ধতা",
      ps: [
        "কুরিয়ার, প্রাকৃতিক কারণ বা নেটওয়ার্ক/অপারেটর বিঘ্নের কারণে বিলম্বের জন্য আরপন টেলিকম দায়ী নয়। যেকোনো অর্ডারে আমাদের সর্বোচ্চ দায় সেই অর্ডারে পরিশোধিত অর্থের মধ্যে সীমাবদ্ধ।",
      ],
    },
    {
      h: "শর্তাবলীর পরিবর্তন",
      ps: [
        "আমরা মাঝে মাঝে এই শর্তাবলী হালনাগাদ করতে পারি। পরিবর্তনের পরেও স্টোর ব্যবহার চালিয়ে গেলে হালনাগাদ শর্তাবলী গ্রহণ করেছেন ধরা হবে।",
      ],
    },
  ],
};

function PolicyColumns({ policy }: { policy: Record<"en" | "bn", PolicySection[]> }) {
  return (
    <div className="grid gap-6 md:grid-cols-2">
      {(["en", "bn"] as const).map((lng) => (
        <div key={lng}>
          <p className="mb-3 inline-block rounded-full bg-muted px-3 py-1 text-xs font-semibold text-muted-foreground">
            {lng === "en" ? "English" : "বাংলা"}
          </p>
          <div className="space-y-5">
            {policy[lng].map((sec) => (
              <section key={sec.h}>
                <h3 className="text-sm font-semibold text-foreground">{sec.h}</h3>
                <div className="mt-1.5 space-y-2 leading-relaxed text-muted-foreground">
                  {sec.ps.map((p, i) => (
                    <p key={i} className="text-sm">
                      {p}
                    </p>
                  ))}
                </div>
              </section>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Main view ──────────────────────────────────────────────────────────────
export function StaticPageView() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const view = useStore((s) => s.view);
  const slug: PageSlug = view.name === "page" ? view.slug : "about";

  return (
    <div className="mx-auto max-w-4xl px-3 py-8 sm:px-4">
      <h1 className="mb-6 text-2xl font-bold text-foreground sm:text-3xl">{t(TITLES[slug])}</h1>
      <div className="rounded-xl border bg-card p-4 sm:p-8">
        {slug === "about" && <AboutSection lang={lang} />}
        {slug === "contact" && <ContactSection />}
        {slug === "faq" && <FaqSection lang={lang} />}
        {slug === "warranty" && <PolicyColumns policy={WARRANTY_POLICY} />}
        {slug === "privacy" && <PolicyColumns policy={PRIVACY_POLICY} />}
        {slug === "terms" && <PolicyColumns policy={TERMS_POLICY} />}
      </div>
    </div>
  );
}

export default StaticPageView;
