"use client";
// ─── Arpon Telecom — order tracking (phone + order number → status) ─────────
import { useState } from "react";
import { toast } from "sonner";
import { Check, Loader2, Package, PackageSearch, XCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useStore } from "@/lib/store";
import { useT } from "@/lib/i18n";
import { formatBDT, formatDate } from "@/lib/format";
import type { OrderDTO, OrderStatus, PaymentMethod } from "@/lib/types";

const STEPS: OrderStatus[] = ["pending", "confirmed", "shipped", "delivered"];

const STATUS_BADGE: Record<OrderStatus, string> = {
  pending: "border-transparent bg-amber-100 text-amber-700",
  confirmed: "border-transparent bg-primary/10 text-primary",
  shipped: "border-transparent bg-cyan-100 text-cyan-700",
  delivered: "border-transparent bg-emerald-100 text-emerald-700",
  cancelled: "border-transparent bg-rose-100 text-rose-700",
};

const PAYMENT_KEYS: Record<PaymentMethod, string> = {
  cod: "cod",
  bkash: "bkash",
  nagad: "nagad",
  rocket: "rocket",
  card: "card",
};

function Stepper({ status }: { status: OrderStatus }) {
  const t = useT();
  const idx = STEPS.indexOf(status);

  const circleCls = (done: boolean, current: boolean) =>
    [
      "relative z-10 flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-xs font-bold",
      done
        ? "bg-primary text-primary-foreground"
        : current
          ? "border-2 border-primary bg-background text-primary"
          : "bg-muted text-muted-foreground",
    ].join(" ");

  return (
    <div role="list" aria-label={t("orderStatus")}>
      {/* Horizontal (sm+) */}
      <ol className="hidden items-start sm:flex">
        {STEPS.map((s, i) => {
          const done = i <= idx;
          const current = i === idx;
          return (
            <li key={s} role="listitem" className="relative flex flex-1 flex-col items-center gap-1.5">
              {i < STEPS.length - 1 && (
                <span
                  aria-hidden="true"
                  className={`absolute top-4 left-[calc(50%+20px)] h-0.5 w-[calc(100%-40px)] ${
                    i < idx ? "bg-primary" : "bg-muted"
                  }`}
                />
              )}
              <span className={`${circleCls(done, current)} ${current ? "animate-pulse" : ""}`}>
                {done ? <Check className="h-4 w-4" aria-hidden="true" /> : i + 1}
              </span>
              <span
                className={`text-center text-xs ${
                  done ? "font-semibold text-primary" : "text-muted-foreground"
                }`}
              >
                {t(`status_${s}`)}
              </span>
            </li>
          );
        })}
      </ol>

      {/* Vertical (mobile) */}
      <ol className="flex flex-col sm:hidden">
        {STEPS.map((s, i) => {
          const done = i <= idx;
          const current = i === idx;
          return (
            <li key={s} role="listitem" className="flex gap-3">
              <div className="flex flex-col items-center">
                <span className={`${circleCls(done, current)} ${current ? "animate-pulse" : ""}`}>
                  {done ? <Check className="h-4 w-4" aria-hidden="true" /> : i + 1}
                </span>
                {i < STEPS.length - 1 && (
                  <span
                    aria-hidden="true"
                    className={`min-h-6 w-0.5 flex-1 ${i < idx ? "bg-primary" : "bg-muted"}`}
                  />
                )}
              </div>
              <span
                className={`pb-6 pt-1 text-sm ${
                  done ? "font-semibold text-primary" : "text-muted-foreground"
                }`}
              >
                {t(`status_${s}`)}
              </span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export function TrackingView() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const lastOrder = useStore((s) => s.lastOrder);

  const [phone, setPhone] = useState(lastOrder?.phone ?? "");
  const [orderNo, setOrderNo] = useState(lastOrder?.orderNumber ?? "");
  const [loading, setLoading] = useState(false);
  const [order, setOrder] = useState<OrderDTO | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [searched, setSearched] = useState(false);

  async function track(e?: React.FormEvent) {
    e?.preventDefault();
    if (loading) return;
    if (!phone.trim() || !orderNo.trim()) {
      toast.error(t("fillAllFields"));
      return;
    }
    setLoading(true);
    setOrder(null);
    setNotFound(false);
    try {
      const res = await fetch(
        `/api/orders/track?phone=${encodeURIComponent(phone.trim())}&orderNumber=${encodeURIComponent(orderNo.trim())}`
      );
      if (res.status === 404) {
        setNotFound(true);
      } else if (!res.ok) {
        toast.error(t("orderFailed"));
      } else {
        const data = (await res.json()) as { order: OrderDTO };
        setOrder(data.order);
      }
    } catch {
      toast.error(t("orderFailed"));
    } finally {
      setLoading(false);
      setSearched(true);
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-3 py-8 sm:px-4">
      <section className="rounded-xl border bg-card p-6">
        <div className="text-center">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
            <PackageSearch className="h-7 w-7 text-primary" aria-hidden="true" />
          </span>
          <h1 className="mt-3 text-2xl font-bold text-foreground">{t("trackTitle")}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{t("trackDesc")}</p>
        </div>

        <form onSubmit={track} className="mx-auto mt-6 max-w-md space-y-4" noValidate>
          <div className="space-y-1.5">
            <Label htmlFor="tr-phone">{t("phoneLabel")}</Label>
            <Input
              id="tr-phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 11))}
              placeholder={t("phonePh")}
              inputMode="numeric"
              autoComplete="tel"
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="tr-order">{t("orderNoLabel")}</Label>
            <Input
              id="tr-order"
              value={orderNo}
              onChange={(e) => setOrderNo(e.target.value.toUpperCase())}
              placeholder="APT250101XXXX"
              className="font-mono"
            />
          </div>
          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                {t("tracking")}
              </>
            ) : (
              t("trackBtn")
            )}
          </Button>
        </form>
      </section>

      {notFound && searched && (
        <Alert variant="destructive" className="mt-6">
          <XCircle aria-hidden="true" />
          <AlertTitle>{t("orderNotFound")}</AlertTitle>
          <AlertDescription>{t("demoHint")}</AlertDescription>
        </Alert>
      )}

      {order && (
        <section className="mt-6 rounded-xl border bg-card p-4 sm:p-6" aria-label={t("orderStatus")}>
          {/* Header */}
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="text-xs uppercase tracking-wide text-muted-foreground">{t("orderNumber")}</p>
              <p className="font-mono text-lg font-bold text-foreground">{order.orderNumber}</p>
            </div>
            <div className="text-right">
              <Badge className={STATUS_BADGE[order.status]}>{t(`status_${order.status}`)}</Badge>
              <p className="mt-1 text-xs text-muted-foreground">
                {t("orderPlacedOn")} {formatDate(order.createdAt, lang)}
              </p>
            </div>
          </div>

          <Separator className="my-5" />

          {/* Stepper / cancelled */}
          {order.status === "cancelled" ? (
            <Alert variant="destructive">
              <XCircle aria-hidden="true" />
              <AlertTitle>{t("status_cancelled")}</AlertTitle>
              <AlertDescription>{t("orderCancelled")}</AlertDescription>
            </Alert>
          ) : (
            <Stepper status={order.status} />
          )}

          <Separator className="my-5" />

          {/* Items */}
          <h2 className="mb-3 text-sm font-semibold text-foreground">{t("orderItems")}</h2>
          <ul className="space-y-3">
            {order.items.map((item) => (
              <li key={item.id} className="flex items-center gap-3">
                <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-muted">
                  <Package className="h-5 w-5 text-muted-foreground" aria-hidden="true" />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-foreground">
                    {lang === "bn" ? item.nameBn : item.nameEn}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {item.qty} × {formatBDT(item.price)}
                    {item.variant ? ` · ${item.variant}` : ""}
                  </p>
                </div>
                <span className="text-sm font-semibold text-foreground">
                  {formatBDT(item.qty * item.price)}
                </span>
              </li>
            ))}
          </ul>

          <Separator className="my-5" />

          {/* Summary */}
          <dl className="space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <dt className="text-muted-foreground">{t("cartSubtotal")}</dt>
              <dd className="font-medium text-foreground">{formatBDT(order.subtotal)}</dd>
            </div>
            <div className="flex items-center justify-between">
              <dt className="text-muted-foreground">{t("deliveryFee")}</dt>
              <dd className="font-medium text-foreground">{formatBDT(order.deliveryFee)}</dd>
            </div>
            {order.discount > 0 && (
              <div className="flex items-center justify-between">
                <dt className="text-muted-foreground">
                  {t("couponCode")} {order.couponCode ? `(${order.couponCode})` : ""}
                </dt>
                <dd className="font-medium text-emerald-600">-{formatBDT(order.discount)}</dd>
              </div>
            )}
            <Separator className="my-2" />
            <div className="flex items-center justify-between">
              <dt className="font-semibold text-foreground">{t("total")}</dt>
              <dd className="text-base font-bold text-primary">{formatBDT(order.total)}</dd>
            </div>
          </dl>

          <Separator className="my-5" />

          {/* Address + payment */}
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <h2 className="text-sm font-semibold text-foreground">{t("deliveryAddress")}</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                <span className="font-medium text-foreground">{order.customerName}</span> · {order.phone}
                <br />
                {order.address}, {order.upazila}, {order.district}, {order.division}
              </p>
            </div>
            <div>
              <h2 className="text-sm font-semibold text-foreground">{t("paymentInfo")}</h2>
              <p className="mt-1 text-sm text-muted-foreground">{t(PAYMENT_KEYS[order.paymentMethod])}</p>
            </div>
          </div>
        </section>
      )}
    </div>
  );
}

export default TrackingView;
