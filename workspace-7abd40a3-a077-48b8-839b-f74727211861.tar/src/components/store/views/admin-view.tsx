"use client";
// ─── Arpon Telecom — admin panel (login, dashboard, orders, products, coupons) ─
import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Banknote,
  Clock,
  LayoutDashboard,
  Loader2,
  LogOut,
  Lock,
  Package,
  Plus,
  ShoppingBag,
  Ticket,
  Trash2,
  TrendingUp,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useStore } from "@/lib/store";
import { useT } from "@/lib/i18n";
import { ADMIN_HEADER, getJSON, postJSON, putJSON } from "@/lib/api";
import { formatBDT, formatDate, firstImage } from "@/lib/format";
import type { CategoryDTO, OrderDTO, OrderStatus, ProductDTO, StockStatus } from "@/lib/types";

// ─── Helpers ────────────────────────────────────────────────────────────────
const ORDER_STATUSES: OrderStatus[] = ["pending", "confirmed", "shipped", "delivered", "cancelled"];

const STATUS_BADGE: Record<OrderStatus, string> = {
  pending: "border-transparent bg-amber-100 text-amber-700",
  confirmed: "border-transparent bg-primary/10 text-primary",
  shipped: "border-transparent bg-cyan-100 text-cyan-700",
  delivered: "border-transparent bg-emerald-100 text-emerald-700",
  cancelled: "border-transparent bg-rose-100 text-rose-700",
};

const PAYMENT_SHORT: Record<string, string> = {
  cod: "COD",
  bkash: "bKash",
  nagad: "Nagad",
  rocket: "Rocket",
  card: "Card",
};

interface AdminStats {
  todayRevenue: number;
  monthRevenue: number;
  totalOrders: number;
  pendingOrders: number;
  totalProducts: number;
  lowStock: { id: string; nameEn: string; stock: number }[];
  recentOrders: OrderDTO[];
  topProducts: { nameEn: string; soldCount: number }[];
}

/** Fetch with ADMIN_HEADER; auto-logout on 401. */
function adminFetch<T>(url: string, init?: RequestInit): Promise<T> {
  return fetch(url, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...ADMIN_HEADER,
      ...(init?.headers as Record<string, string> | undefined),
    },
  }).then(async (res) => {
    if (res.status === 401) {
      useStore.getState().setAdminAuthed(false);
      throw new Error("UNAUTHORIZED");
    }
    if (!res.ok) {
      const body = (await res.json().catch(() => ({}))) as { error?: string };
      throw new Error(body.error ?? `Request failed: ${res.status}`);
    }
    return res.json() as Promise<T>;
  });
}

function showErr(t: (k: string) => string, e: unknown) {
  const msg = e instanceof Error ? e.message : String(e);
  if (msg === "UNAUTHORIZED") toast.error(t("adminSessionExpired"));
  else toast.error(msg || t("orderFailed"));
}

// ─── Login ──────────────────────────────────────────────────────────────────
function AdminLogin() {
  const t = useT();
  const setAdminAuthed = useStore((s) => s.setAdminAuthed);
  const [passcode, setPasscode] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (loading) return;
    setLoading(true);
    try {
      const data = await postJSON<{ ok: boolean }>("/api/admin/login", { passcode });
      if (data.ok) setAdminAuthed(true);
      else toast.error(t("wrongPasscode"));
    } catch {
      toast.error(t("wrongPasscode"));
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-[60vh] items-center justify-center px-3 py-10">
      <div className="w-full max-w-sm rounded-xl border bg-card p-6 sm:p-8">
        <div className="text-center">
          <span className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-primary/10">
            <Lock className="h-7 w-7 text-primary" aria-hidden="true" />
          </span>
          <h1 className="mt-3 text-xl font-bold text-foreground">{t("adminLogin")}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{t("adminLoginDesc")}</p>
        </div>
        <form onSubmit={submit} className="mt-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="ad-pass">{t("passcode")}</Label>
            <Input
              id="ad-pass"
              type="password"
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              autoComplete="current-password"
            />
          </div>
          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
          >
            {loading ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : t("adminLogin")}
          </Button>
        </form>
        <p className="mt-4 text-center text-xs text-muted-foreground">{t("demoPasscodeHint")}</p>
      </div>
    </div>
  );
}

// ─── Dashboard ──────────────────────────────────────────────────────────────
function StatCard({
  icon: Icon,
  label,
  value,
  tone = "primary",
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  tone?: "primary" | "amber";
}) {
  return (
    <div className="flex items-center gap-4 rounded-xl border bg-card p-4 sm:p-5">
      <span
        className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${
          tone === "amber" ? "bg-amber-100 text-amber-600" : "bg-primary/10 text-primary"
        }`}
      >
        <Icon className="h-5 w-5" aria-hidden="true" />
      </span>
      <div className="min-w-0">
        <p className="truncate text-xs text-muted-foreground">{label}</p>
        <p className="text-xl font-bold text-foreground sm:text-2xl">{value}</p>
      </div>
    </div>
  );
}

function DashboardTab({ refreshKey, onGoProducts }: { refreshKey: number; onGoProducts: () => void }) {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let alive = true;
    adminFetch<AdminStats>("/api/admin/stats")
      .then((data) => {
        if (alive) setStats(data);
      })
      .catch((e) => {
        if (alive) showErr(t, e);
      })
      .finally(() => {
        if (alive) setLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [refreshKey]);

  if (loading && !stats) {
    return (
      <div className="flex justify-center py-16">
        <Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden="true" />
      </div>
    );
  }
  if (!stats) {
    return <p className="py-10 text-center text-sm text-muted-foreground">{t("noData")}</p>;
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Banknote} label={t("todayRevenue")} value={formatBDT(stats.todayRevenue)} />
        <StatCard icon={TrendingUp} label={t("monthRevenue")} value={formatBDT(stats.monthRevenue)} />
        <StatCard icon={ShoppingBag} label={t("totalOrdersLabel")} value={String(stats.totalOrders)} />
        <StatCard icon={Clock} label={t("pendingOrdersLabel")} value={String(stats.pendingOrders)} tone="amber" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-1">
          {/* Low stock */}
          <div className="rounded-xl border bg-card p-4">
            <div className="mb-3 flex items-center justify-between gap-2">
              <h3 className="text-sm font-semibold text-foreground">{t("lowStock")}</h3>
              <Button variant="ghost" size="sm" className="h-7 px-2 text-xs" onClick={onGoProducts}>
                {t("admin_products")}
              </Button>
            </div>
            {stats.lowStock.length === 0 ? (
              <p className="text-sm text-muted-foreground">{t("noData")}</p>
            ) : (
              <ul className="space-y-2">
                {stats.lowStock.map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-2 text-sm">
                    <span className="min-w-0 truncate text-foreground">{p.nameEn}</span>
                    <Badge className="border-transparent bg-amber-100 text-amber-700">{p.stock}</Badge>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Top products */}
          <div className="rounded-xl border bg-card p-4">
            <h3 className="mb-3 text-sm font-semibold text-foreground">{t("topProducts")}</h3>
            {stats.topProducts.length === 0 ? (
              <p className="text-sm text-muted-foreground">{t("noData")}</p>
            ) : (
              <ol className="space-y-2">
                {stats.topProducts.map((p, i) => (
                  <li key={p.nameEn} className="flex items-center gap-3 text-sm">
                    <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-bold text-primary">
                      {i + 1}
                    </span>
                    <span className="min-w-0 flex-1 truncate text-foreground">{p.nameEn}</span>
                    <span className="shrink-0 text-xs text-muted-foreground">
                      {p.soldCount} {t("sold")}
                    </span>
                  </li>
                ))}
              </ol>
            )}
          </div>
        </div>

        {/* Recent orders */}
        <div className="rounded-xl border bg-card p-4 lg:col-span-2">
          <h3 className="mb-3 text-sm font-semibold text-foreground">{t("recentOrders")}</h3>
          {stats.recentOrders.length === 0 ? (
            <p className="py-4 text-sm text-muted-foreground">{t("noData")}</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>{t("orderNumber")}</TableHead>
                  <TableHead>{t("customer")}</TableHead>
                  <TableHead>{t("total")}</TableHead>
                  <TableHead>{t("status")}</TableHead>
                  <TableHead className="hidden md:table-cell">{t("date")}</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stats.recentOrders.map((o) => (
                  <TableRow key={o.id}>
                    <TableCell className="font-mono text-xs font-semibold">{o.orderNumber}</TableCell>
                    <TableCell className="max-w-[140px] truncate text-xs">{o.customerName}</TableCell>
                    <TableCell className="text-xs font-semibold">{formatBDT(o.total)}</TableCell>
                    <TableCell>
                      <Badge className={`${STATUS_BADGE[o.status]} text-[10px]`}>
                        {t(`status_${o.status}`)}
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden text-xs text-muted-foreground md:table-cell">
                      {formatDate(o.createdAt, lang)}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Orders ─────────────────────────────────────────────────────────────────
function OrdersTab({ onStatsRefresh }: { onStatsRefresh: () => void }) {
  const t = useT();
  const [filter, setFilter] = useState<string>("all");
  const [orders, setOrders] = useState<OrderDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);

  const load = useCallback(
    async (status: string) => {
      setLoading(true);
      try {
        const qs = status && status !== "all" ? `?status=${status}` : "";
        const data = await adminFetch<{ orders: OrderDTO[] }>(`/api/admin/orders${qs}`);
        setOrders(data.orders);
      } catch (e) {
        showErr(t, e);
      } finally {
        setLoading(false);
      }
    },
     
    []
  );

  useEffect(() => {
    load(filter);
     
  }, [filter]);

  async function updateStatus(order: OrderDTO, status: OrderStatus) {
    if (status === order.status) return;
    setSavingId(order.id);
    try {
      await adminFetch(`/api/admin/orders/${order.id}`, {
        method: "PUT",
        body: JSON.stringify({ status }),
      });
      toast.success(t("saved"));
      await load(filter);
      onStatsRefresh();
    } catch (e) {
      showErr(t, e);
    } finally {
      setSavingId(null);
    }
  }

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-foreground">{t("admin_orders")}</h2>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[160px]" size="sm" aria-label={t("status")}>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("all")}</SelectItem>
            {ORDER_STATUSES.map((s) => (
              <SelectItem key={s} value={s}>
                {t(`status_${s}`)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden="true" />
        </div>
      ) : orders.length === 0 ? (
        <p className="py-10 text-center text-sm text-muted-foreground">{t("noData")}</p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t("orderNumber")}</TableHead>
              <TableHead>{t("customer")}</TableHead>
              <TableHead className="hidden md:table-cell">{t("district")}</TableHead>
              <TableHead className="hidden sm:table-cell">{t("itemsCount")}</TableHead>
              <TableHead>{t("total")}</TableHead>
              <TableHead className="hidden sm:table-cell">{t("paymentInfo")}</TableHead>
              <TableHead>{t("status")}</TableHead>
              <TableHead>{t("updateStatus")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.map((o) => (
              <TableRow key={o.id}>
                <TableCell className="font-mono text-xs font-semibold">{o.orderNumber}</TableCell>
                <TableCell>
                  <p className="max-w-[130px] truncate text-xs font-medium">{o.customerName}</p>
                  <p className="text-xs text-muted-foreground">{o.phone}</p>
                </TableCell>
                <TableCell className="hidden text-xs md:table-cell">{o.district}</TableCell>
                <TableCell className="hidden text-xs sm:table-cell">{o.items.length}</TableCell>
                <TableCell className="text-xs font-semibold">{formatBDT(o.total)}</TableCell>
                <TableCell className="hidden sm:table-cell">
                  <Badge variant="outline" className="text-[10px]">
                    {PAYMENT_SHORT[o.paymentMethod] ?? o.paymentMethod}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge className={`${STATUS_BADGE[o.status]} text-[10px]`}>
                    {t(`status_${o.status}`)}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Select
                    value={o.status}
                    onValueChange={(v) => updateStatus(o, v as OrderStatus)}
                    disabled={savingId === o.id}
                  >
                    <SelectTrigger size="sm" className="w-[120px]" aria-label={t("updateStatus")}>
                      {savingId === o.id ? (
                        <Loader2 className="h-3 w-3 animate-spin" aria-hidden="true" />
                      ) : (
                        <SelectValue />
                      )}
                    </SelectTrigger>
                    <SelectContent>
                      {ORDER_STATUSES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {t(`status_${s}`)}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </div>
  );
}

// ─── Products ───────────────────────────────────────────────────────────────
const STOCK_STATUSES: StockStatus[] = ["in_stock", "out_of_stock", "pre_order"];

interface ProductForm {
  nameEn: string;
  nameBn: string;
  slug: string;
  brand: string;
  categoryId: string;
  price: string;
  oldPrice: string;
  stock: string;
  stockStatus: StockStatus;
  descriptionEn: string;
}

const EMPTY_FORM: ProductForm = {
  nameEn: "",
  nameBn: "",
  slug: "",
  brand: "",
  categoryId: "",
  price: "",
  oldPrice: "",
  stock: "0",
  stockStatus: "in_stock",
  descriptionEn: "",
};

function ProductsTab({ onStatsRefresh }: { onStatsRefresh: () => void }) {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [categories, setCategories] = useState<CategoryDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [stockEdits, setStockEdits] = useState<Record<string, string>>({});
  const [savingStock, setSavingStock] = useState<string | null>(null);

  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState<ProductForm>(EMPTY_FORM);
  const [slugTouched, setSlugTouched] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const [deleteTarget, setDeleteTarget] = useState<ProductDTO | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [p, c] = await Promise.all([
        adminFetch<{ products: ProductDTO[] }>("/api/admin/products"),
        getJSON<{ categories: CategoryDTO[] }>("/api/categories"),
      ]);
      setProducts(p.products);
      setCategories(c.categories);
    } catch (e) {
      showErr(t, e);
    } finally {
      setLoading(false);
    }
     
  }, []);

  useEffect(() => {
    load();
     
  }, []);

  async function saveStock(p: ProductDTO) {
    const raw = stockEdits[p.id];
    if (raw === undefined) return;
    const stock = Number(raw);
    if (!Number.isFinite(stock) || stock < 0 || stock === p.stock) return;
    setSavingStock(p.id);
    try {
      await adminFetch(`/api/admin/products/${p.id}`, {
        method: "PUT",
        body: JSON.stringify({ stock }),
      });
      toast.success(t("saved"));
      await load();
      onStatsRefresh();
    } catch (e) {
      showErr(t, e);
    } finally {
      setSavingStock(null);
    }
  }

  async function deleteProduct() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await adminFetch(`/api/admin/products/${deleteTarget.id}`, { method: "DELETE" });
      toast.success(t("deleted"));
      setDeleteTarget(null);
      await load();
      onStatsRefresh();
    } catch (e) {
      showErr(t, e);
    } finally {
      setDeleting(false);
    }
  }

  function setField<K extends keyof ProductForm>(key: K, value: ProductForm[K]) {
    setForm((f) => {
      const next = { ...f, [key]: value };
      if (key === "nameEn" && !slugTouched) {
        next.slug = String(value)
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/(^-|-$)/g, "");
      }
      return next;
    });
  }

  async function addProduct(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    if (!form.nameEn.trim() || !form.nameBn.trim() || !form.brand.trim() || !form.categoryId || !(Number(form.price) > 0)) {
      toast.error(t("fillAllFields"));
      return;
    }
    setSubmitting(true);
    try {
      const slug =
        form.slug.trim() ||
        form.nameEn
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/(^-|-$)/g, "");
      await adminFetch<{ product: ProductDTO }>("/api/admin/products", {
        method: "POST",
        body: JSON.stringify({
          slug,
          nameEn: form.nameEn.trim(),
          nameBn: form.nameBn.trim(),
          brand: form.brand.trim(),
          categoryId: form.categoryId,
          price: Number(form.price),
          oldPrice: form.oldPrice ? Number(form.oldPrice) : null,
          stock: Number(form.stock) || 0,
          stockStatus: form.stockStatus,
          descriptionEn: form.descriptionEn.trim(),
        }),
      });
      toast.success(t("saved"));
      setAddOpen(false);
      setForm(EMPTY_FORM);
      setSlugTouched(false);
      await load();
      onStatsRefresh();
    } catch (err) {
      showErr(t, err);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-foreground">{t("admin_products")}</h2>
        <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setAddOpen(true)}>
          <Plus className="h-4 w-4" aria-hidden="true" />
          {t("addProduct")}
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden="true" />
        </div>
      ) : products.length === 0 ? (
        <p className="py-10 text-center text-sm text-muted-foreground">{t("noData")}</p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-12">{t("productCategory")}</TableHead>
              <TableHead>{t("productName")}</TableHead>
              <TableHead className="hidden md:table-cell">{t("productBrand")}</TableHead>
              <TableHead>{t("productPrice")}</TableHead>
              <TableHead>{t("productStock")}</TableHead>
              <TableHead className="hidden sm:table-cell">{t("availability")}</TableHead>
              <TableHead>{t("actions")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {products.map((p) => (
              <TableRow key={p.id}>
                <TableCell>
                  { }
                  <img
                    src={firstImage(p.images)}
                    alt={p.nameEn}
                    className="h-10 w-10 rounded object-cover"
                  />
                </TableCell>
                <TableCell>
                  <p className="max-w-[180px] truncate text-xs font-medium" title={lang === "bn" ? p.nameBn : p.nameEn}>
                    {lang === "bn" ? p.nameBn : p.nameEn}
                  </p>
                  <p className="text-[10px] text-muted-foreground md:hidden">{p.brand}</p>
                </TableCell>
                <TableCell className="hidden text-xs md:table-cell">{p.brand}</TableCell>
                <TableCell className="text-xs font-semibold">{formatBDT(p.price)}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <Input
                      type="number"
                      min={0}
                      value={stockEdits[p.id] ?? String(p.stock)}
                      onChange={(e) => setStockEdits((m) => ({ ...m, [p.id]: e.target.value }))}
                      onBlur={() => saveStock(p)}
                      className="h-8 w-16 text-center text-xs"
                      aria-label={`${t("productStock")} — ${p.nameEn}`}
                    />
                    {savingStock === p.id && (
                      <Loader2 className="h-3 w-3 animate-spin text-primary" aria-hidden="true" />
                    )}
                  </div>
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  <Badge
                    className={`border-transparent text-[10px] ${
                      p.stockStatus === "in_stock"
                        ? "bg-emerald-100 text-emerald-700"
                        : p.stockStatus === "pre_order"
                          ? "bg-amber-100 text-amber-700"
                          : "bg-rose-100 text-rose-700"
                    }`}
                  >
                    {t(p.stockStatus)}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-rose-600 hover:bg-rose-50 hover:text-rose-700"
                    onClick={() => setDeleteTarget(p)}
                    aria-label={`${t("delete")} — ${p.nameEn}`}
                  >
                    <Trash2 className="h-4 w-4" aria-hidden="true" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* Add product dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t("addProduct")}</DialogTitle>
          </DialogHeader>
          <form onSubmit={addProduct} className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="pf-nameEn">{t("productName")}</Label>
              <Input id="pf-nameEn" value={form.nameEn} onChange={(e) => setField("nameEn", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pf-nameBn">{t("productNameBn")}</Label>
              <Input id="pf-nameBn" value={form.nameBn} onChange={(e) => setField("nameBn", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pf-brand">{t("productBrand")}</Label>
              <Input id="pf-brand" value={form.brand} onChange={(e) => setField("brand", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pf-cat">{t("productCategory")}</Label>
              <Select value={form.categoryId} onValueChange={(v) => setField("categoryId", v)}>
                <SelectTrigger id="pf-cat" className="w-full">
                  <SelectValue placeholder={t("productCategory")} />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {lang === "bn" ? c.nameBn : c.nameEn}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pf-price">{t("productPrice")}</Label>
              <Input id="pf-price" type="number" min={1} value={form.price} onChange={(e) => setField("price", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pf-old">{t("productPrice")} ({t("off")})</Label>
              <Input id="pf-old" type="number" min={0} value={form.oldPrice} onChange={(e) => setField("oldPrice", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pf-stock">{t("productStock")}</Label>
              <Input id="pf-stock" type="number" min={0} value={form.stock} onChange={(e) => setField("stock", e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pf-status">{t("availability")}</Label>
              <Select value={form.stockStatus} onValueChange={(v) => setField("stockStatus", v as StockStatus)}>
                <SelectTrigger id="pf-status" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {STOCK_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {t(s)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="pf-desc">{t("productDesc")}</Label>
              <Textarea id="pf-desc" rows={3} value={form.descriptionEn} onChange={(e) => setField("descriptionEn", e.target.value)} />
            </div>
            <DialogFooter className="sm:col-span-2">
              <Button type="button" variant="outline" onClick={() => setAddOpen(false)}>
                {t("cancel")}
              </Button>
              <Button type="submit" disabled={submitting} className="bg-primary text-primary-foreground hover:bg-primary/90">
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : t("save")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{t("delete")}</AlertDialogTitle>
            <AlertDialogDescription>{t("confirmDeleteProduct")}</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>{t("cancel")}</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                deleteProduct();
              }}
              disabled={deleting}
              className="bg-rose-600 text-white hover:bg-rose-700"
            >
              {deleting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : t("delete")}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ─── Coupons ────────────────────────────────────────────────────────────────
interface CouponForm {
  code: string;
  type: "percent" | "fixed";
  value: string;
  minSubtotal: string;
}

const EMPTY_COUPON: CouponForm = { code: "", type: "percent", value: "", minSubtotal: "" };

function CouponsTab() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const [coupons, setCoupons] = useState<
    { id: string; code: string; type: "percent" | "fixed"; value: number; minSubtotal: number | null; active: boolean }[]
  >([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<CouponForm>(EMPTY_COUPON);
  const [submitting, setSubmitting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await adminFetch<{ coupons: typeof coupons }>("/api/admin/coupons");
      setCoupons(data.coupons);
    } catch (e) {
      showErr(t, e);
    } finally {
      setLoading(false);
    }
     
  }, []);

  useEffect(() => {
    load();
     
  }, []);

  async function addCoupon(e: React.FormEvent) {
    e.preventDefault();
    if (submitting) return;
    const value = Number(form.value);
    if (form.code.trim().length < 2 || !Number.isFinite(value) || value <= 0) {
      toast.error(t("fillAllFields"));
      return;
    }
    setSubmitting(true);
    try {
      await adminFetch("/api/admin/coupons", {
        method: "POST",
        body: JSON.stringify({
          code: form.code.trim().toUpperCase(),
          type: form.type,
          value,
          minSubtotal: form.minSubtotal ? Number(form.minSubtotal) : null,
        }),
      });
      toast.success(t("saved"));
      setOpen(false);
      setForm(EMPTY_COUPON);
      await load();
    } catch (err) {
      showErr(t, err);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="rounded-xl border bg-card p-4">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-foreground">{t("admin_coupons")}</h2>
        <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setOpen(true)}>
          <Plus className="h-4 w-4" aria-hidden="true" />
          {t("addCoupon")}
        </Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-primary" aria-hidden="true" />
        </div>
      ) : coupons.length === 0 ? (
        <p className="py-10 text-center text-sm text-muted-foreground">{t("noData")}</p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>{t("code")}</TableHead>
              <TableHead>{t("couponType")}</TableHead>
              <TableHead>{t("value")}</TableHead>
              <TableHead>{t("minSubtotal")}</TableHead>
              <TableHead>{t("status")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {coupons.map((c) => (
              <TableRow key={c.id}>
                <TableCell className="font-mono text-xs font-bold">{c.code}</TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-[10px]">
                    {c.type === "percent" ? t("percent") : t("fixed")}
                  </Badge>
                </TableCell>
                <TableCell className="text-xs font-semibold">
                  {c.type === "percent" ? `${c.value}%` : formatBDT(c.value)}
                </TableCell>
                <TableCell className="text-xs">{c.minSubtotal ? formatBDT(c.minSubtotal) : "—"}</TableCell>
                <TableCell>
                  <Badge
                    className={`border-transparent text-[10px] ${
                      c.active ? "bg-emerald-100 text-emerald-700" : "bg-rose-100 text-rose-700"
                    }`}
                  >
                    {c.active ? (lang === "bn" ? "চালু" : "Active") : lang === "bn" ? "বন্ধ" : "Inactive"}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t("addCoupon")}</DialogTitle>
          </DialogHeader>
          <form onSubmit={addCoupon} className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="cf-code">{t("code")}</Label>
              <Input
                id="cf-code"
                value={form.code}
                onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))}
                className="font-mono uppercase"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cf-type">{t("couponType")}</Label>
              <Select value={form.type} onValueChange={(v) => setForm((f) => ({ ...f, type: v as "percent" | "fixed" }))}>
                <SelectTrigger id="cf-type" className="w-full">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="percent">{t("percent")}</SelectItem>
                  <SelectItem value="fixed">{t("fixed")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cf-value">{t("value")}</Label>
              <Input
                id="cf-value"
                type="number"
                min={1}
                value={form.value}
                onChange={(e) => setForm((f) => ({ ...f, value: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cf-min">{t("minSubtotal")}</Label>
              <Input
                id="cf-min"
                type="number"
                min={0}
                value={form.minSubtotal}
                onChange={(e) => setForm((f) => ({ ...f, minSubtotal: e.target.value }))}
              />
            </div>
            <DialogFooter className="sm:col-span-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                {t("cancel")}
              </Button>
              <Button type="submit" disabled={submitting} className="bg-primary text-primary-foreground hover:bg-primary/90">
                {submitting ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" /> : t("save")}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Main ───────────────────────────────────────────────────────────────────
export function AdminView() {
  const t = useT();
  const authed = useStore((s) => s.adminAuthed);
  const setAdminAuthed = useStore((s) => s.setAdminAuthed);
  const [tab, setTab] = useState("dashboard");
  const [statsKey, setStatsKey] = useState(0);

  if (!authed) return <AdminLogin />;

  return (
    <div className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
      <div className="mb-6 flex items-center justify-between gap-3">
        <h1 className="flex items-center gap-2 text-xl font-bold text-foreground sm:text-2xl">
          <LayoutDashboard className="h-6 w-6 text-primary" aria-hidden="true" />
          {t("adminPanel")}
        </h1>
        <Button variant="outline" size="sm" onClick={() => setAdminAuthed(false)}>
          <LogOut className="h-4 w-4" aria-hidden="true" />
          {t("logout")}
        </Button>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="gap-4">
        <TabsList className="grid h-auto w-full grid-cols-4 sm:inline-flex sm:w-auto">
          <TabsTrigger value="dashboard" className="gap-1.5 px-2 py-1.5 text-xs sm:text-sm">
            <LayoutDashboard className="h-4 w-4" aria-hidden="true" />
            {t("admin_dashboard")}
          </TabsTrigger>
          <TabsTrigger value="orders" className="gap-1.5 px-2 py-1.5 text-xs sm:text-sm">
            <ShoppingBag className="h-4 w-4" aria-hidden="true" />
            {t("admin_orders")}
          </TabsTrigger>
          <TabsTrigger value="products" className="gap-1.5 px-2 py-1.5 text-xs sm:text-sm">
            <Package className="h-4 w-4" aria-hidden="true" />
            {t("admin_products")}
          </TabsTrigger>
          <TabsTrigger value="coupons" className="gap-1.5 px-2 py-1.5 text-xs sm:text-sm">
            <Ticket className="h-4 w-4" aria-hidden="true" />
            {t("admin_coupons")}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard">
          <DashboardTab refreshKey={statsKey} onGoProducts={() => setTab("products")} />
        </TabsContent>
        <TabsContent value="orders">
          <OrdersTab onStatsRefresh={() => setStatsKey((k) => k + 1)} />
        </TabsContent>
        <TabsContent value="products">
          <ProductsTab onStatsRefresh={() => setStatsKey((k) => k + 1)} />
        </TabsContent>
        <TabsContent value="coupons">
          <CouponsTab />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default AdminView;
