"use client";
// ─── Arpon Telecom — Wishlist view ───────────────────────────────────────────
import { useEffect, useState } from "react";
import { AlertCircle, Heart, RotateCcw, ShoppingCart } from "lucide-react";
import { toast } from "sonner";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { getJSON } from "@/lib/api";
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import type { ProductDTO } from "@/lib/types";
import { ProductCard } from "../product-card";

interface ProductsRes {
  products: ProductDTO[];
  total: number;
  page: number;
  pages: number;
}

export function WishlistView() {
  const t = useT();
  const navigate = useStore((s) => s.navigate);
  const wishlist = useStore((s) => s.wishlist);
  const addToCart = useStore((s) => s.addToCart);
  const idsKey = wishlist.join(",");

  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      if (!idsKey) {
        setProducts([]);
        setLoading(false);
        setError(null);
        return;
      }
      setLoading(true);
      setError(null);
      try {
        const d = await getJSON<ProductsRes>(
          `/api/products?ids=${encodeURIComponent(idsKey)}&limit=50`
        );
        if (cancelled) return;
        setProducts(d.products ?? []);
      } catch (e: unknown) {
        if (!cancelled)
          setError(e instanceof Error ? e.message : "Failed to load wishlist");
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => {
      cancelled = true;
    };
  }, [idsKey, reloadKey]);

  const handleMoveAllToCart = () => {
    let added = 0;
    for (const p of products) {
      if (p.stockStatus === "out_of_stock") continue;
      addToCart(
        {
          productId: p.id,
          slug: p.slug,
          nameEn: p.nameEn,
          nameBn: p.nameBn,
          price: p.price,
          image: p.images?.[0] ?? "",
          variant: undefined,
        },
        1
      );
      added++;
    }
    if (added > 0) toast.success(t("addedToCart"));
  };

  const hasData = !loading && !error && products.length > 0;

  return (
    <div className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold text-foreground sm:text-2xl">
            {t("wishlistTitle")}
          </h1>
          {wishlist.length > 0 && (
            <p className="mt-1 text-sm text-muted-foreground" aria-live="polite">
              {wishlist.length} {t("results")}
            </p>
          )}
        </div>
        {hasData && (
          <Button
            variant="outline"
            className="border-primary text-primary hover:bg-primary/5 hover:text-primary"
            onClick={handleMoveAllToCart}
          >
            <ShoppingCart className="h-4 w-4" aria-hidden="true" />
            {t("moveToCart")}
          </Button>
        )}
      </div>

      {/* Body */}
      <div className="mt-6">
        {loading ? (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div className="rounded-xl border bg-card p-2 shadow-sm" key={i}>
                <Skeleton className="aspect-square w-full rounded-lg" />
                <div className="space-y-2 p-1.5">
                  <Skeleton className="h-3 w-14" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-8 w-full rounded-md" />
                </div>
              </div>
            ))}
          </div>
        ) : error ? (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" aria-hidden="true" />
            <AlertTitle>{t("errorOccurred")}</AlertTitle>
            <AlertDescription>
              <p>{error}</p>
              <Button
                size="sm"
                variant="outline"
                className="mt-2"
                onClick={() => setReloadKey((k) => k + 1)}
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                {t("retry")}
              </Button>
            </AlertDescription>
          </Alert>
        ) : products.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-xl border border-dashed bg-card px-6 py-16 text-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-muted">
              <Heart
                className="h-10 w-10 text-muted-foreground/30"
                aria-hidden="true"
              />
            </div>
            <h2 className="mt-4 text-lg font-semibold text-foreground">
              {t("wishlistEmpty")}
            </h2>
            <p className="mt-1 max-w-xs text-sm text-muted-foreground">
              {t("wishlistEmptyDesc")}
            </p>
            <Button
              className="mt-5 bg-cta text-cta-foreground hover:bg-cta/90"
              onClick={() => navigate({ name: "home" })}
            >
              {t("continueShopping")}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>

    </div>
  );
}

export default WishlistView;
