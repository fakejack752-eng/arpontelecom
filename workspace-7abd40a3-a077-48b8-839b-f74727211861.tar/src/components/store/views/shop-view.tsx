"use client";
// ─── Arpon Telecom — Shop view (filters · sort · grid/list · pagination) ─────
import { useEffect, useMemo, useState } from "react";
import {
  AlertCircle,
  LayoutGrid,
  List,
  PackageSearch,
  RotateCcw,
  SlidersHorizontal,
  Star,
  X,
} from "lucide-react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { getJSON } from "@/lib/api";
import { formatBDT } from "@/lib/format";
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import {
  PRODUCT_SORTS,
  type CategoryDTO,
  type ProductDTO,
  type ProductSort,
  type StockStatus,
} from "@/lib/types";
import { cn } from "@/lib/utils";
import { ProductCard } from "../product-card";
import { StockBadge } from "../stock-badge";

// ─── Constants ───────────────────────────────────────────────────────────────
const PAGE_SIZE = 12;
const BRANDS = [
  "Samsung",
  "Xiaomi",
  "Apple",
  "Realme",
  "Oppo",
  "Vivo",
  "Infinix",
  "Walton",
  "Symphony",
  "Anker",
  "Baseus",
  "Amazfit",
  "Nokia",
];
const RAM_OPTIONS = ["4GB", "6GB", "8GB"];
const STORAGE_OPTIONS = ["64GB", "128GB", "256GB"];
const RATING_OPTIONS = [4.5, 4, 3.5];
const STOCK_OPTIONS: StockStatus[] = ["in_stock", "out_of_stock", "pre_order"];
const STOCK_LABEL_KEY: Record<StockStatus, string> = {
  in_stock: "inStock",
  out_of_stock: "outOfStock",
  pre_order: "preOrder",
};

interface ProductsRes {
  products: ProductDTO[];
  total: number;
  page: number;
  pages: number;
}

interface FilterState {
  brands: string[];
  minInput: string;
  maxInput: string;
  ram: string[];
  storage: string[];
  rating: number | null;
  stock: string[];
}

const EMPTY_FILTERS: FilterState = {
  brands: [],
  minInput: "",
  maxInput: "",
  ram: [],
  storage: [],
  rating: null,
  stock: [],
};

function parseNum(v: string): number | null {
  const t = v.trim();
  if (t === "") return null;
  const n = Number(t);
  return Number.isFinite(n) ? n : null;
}

function arraysEqual(a: string[], b: string[]): boolean {
  return a.length === b.length && a.every((v, i) => v === b[i]);
}

function pageWindow(current: number, total: number): number[] {
  if (total <= 1) return [1];
  let start = Math.max(1, current - 2);
  const end = Math.min(total, start + 4);
  start = Math.max(1, end - 4);
  const out: number[] = [];
  for (let i = start; i <= end; i++) out.push(i);
  return out;
}

function toggleIn(list: string[], v: string): string[] {
  return list.includes(v) ? list.filter((x) => x !== v) : [...list, v];
}

// ─── Main view ───────────────────────────────────────────────────────────────
export function ShopView() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const view = useStore((s) => s.view);
  const ctx = view.name === "shop" ? view : null;

  const [category, setCategory] = useState<string | null>(ctx?.category ?? null);
  const [search, setSearch] = useState<string | null>(ctx?.search ?? null);
  const [filters, setFilters] = useState<FilterState>(() => ({
    ...EMPTY_FILTERS,
    brands: ctx?.brand ? ctx.brand.split(",").filter(Boolean) : [],
  }));
  const [minPrice, setMinPrice] = useState<number | null>(null);
  const [maxPrice, setMaxPrice] = useState<number | null>(null);
  const [sort, setSort] = useState<ProductSort>("new");
  const [page, setPage] = useState(1);
  const [layout, setLayout] = useState<"grid" | "list">("grid");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  const [categories, setCategories] = useState<CategoryDTO[]>([]);

  // Re-sync when the store view context changes (e.g. header category click
  // while already inside the shop view).
  const ctxKey = ctx
    ? `${ctx.category ?? ""}|${ctx.brand ?? ""}|${ctx.search ?? ""}`
    : "";
  useEffect(() => {
    const sync = () => {
      const [c = "", b = "", s = ""] = ctxKey.split("|");
      setCategory(c || null);
      setSearch(s || null);
      setFilters((f) => {
        const nextBrands = b ? b.split(",").filter(Boolean) : [];
        if (arraysEqual(f.brands, nextBrands)) return f;
        return { ...f, brands: nextBrands };
      });
      setPage(1);
    };
    sync();
  }, [ctxKey]);

  // Categories (once) — used to resolve slug → localized name for the title.
  useEffect(() => {
    getJSON<{ categories: CategoryDTO[] }>("/api/categories")
      .then((d) => setCategories(d.categories ?? []))
      .catch(() => {});
  }, []);

  // Debounced price inputs → applied numeric range (300ms).
  const { minInput, maxInput } = filters;
  useEffect(() => {
    const id = setTimeout(() => {
      setMinPrice(parseNum(minInput));
      setMaxPrice(parseNum(maxInput));
      setPage(1);
    }, 300);
    return () => clearTimeout(id);
  }, [minInput, maxInput]);

  // Product fetch — re-runs on every filter / sort / page change.
  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      setLoading(true);
      const p = new URLSearchParams();
      if (category) p.set("category", category);
      if (filters.brands.length) p.set("brand", filters.brands.join(","));
      if (minPrice != null) p.set("min", String(minPrice));
      if (maxPrice != null) p.set("max", String(maxPrice));
      if (filters.ram.length) p.set("ram", filters.ram.join(","));
      if (filters.storage.length) p.set("storage", filters.storage.join(","));
      if (filters.rating != null) p.set("rating", String(filters.rating));
      if (filters.stock.length) p.set("stock", filters.stock.join(","));
      if (search) p.set("q", search);
      p.set("sort", sort);
      p.set("page", String(page));
      p.set("limit", String(PAGE_SIZE));

      try {
        const d = await getJSON<ProductsRes>(`/api/products?${p.toString()}`);
        if (cancelled) return;
        setProducts(d.products ?? []);
        setTotal(d.total ?? 0);
        setPages(Math.max(1, d.pages ?? 1));
        setError(null);
      } catch (e: unknown) {
        if (!cancelled)
          setError(e instanceof Error ? e.message : "Failed to load products");
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => {
      cancelled = true;
    };
  }, [
    category,
    filters.brands,
    filters.ram,
    filters.storage,
    filters.rating,
    filters.stock,
    minPrice,
    maxPrice,
    search,
    sort,
    page,
    reloadKey,
  ]);

  // ── Handlers ───────────────────────────────────────────────────────────────
  const update = (patch: Partial<FilterState>, resetPage = true) => {
    setFilters((f) => ({ ...f, ...patch }));
    if (resetPage) setPage(1);
  };

  const applyPrice = () => {
    setMinPrice(parseNum(filters.minInput));
    setMaxPrice(parseNum(filters.maxInput));
    setPage(1);
  };

  const clearAll = () => {
    setCategory(null);
    setSearch(null);
    setFilters(EMPTY_FILTERS);
    setMinPrice(null);
    setMaxPrice(null);
    setSort("new");
    setPage(1);
  };

  const goPage = (p: number) => {
    setPage(p);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // ── Derived ────────────────────────────────────────────────────────────────
  const catName = useMemo(() => {
    if (!category) return null;
    const c = categories.find((x) => x.slug === category);
    if (!c) return category;
    return lang === "bn" ? c.nameBn : c.nameEn;
  }, [category, categories, lang]);

  const title = catName
    ? catName
    : filters.brands.length === 1
      ? filters.brands[0]
      : search
        ? `“${search}”`
        : t("shopTitle");

  const chips: { key: string; label: string; onRemove: () => void }[] = [];
  if (category)
    chips.push({
      key: "cat",
      label: catName ?? category,
      onRemove: () => {
        setCategory(null);
        setPage(1);
      },
    });
  if (search)
    chips.push({
      key: "q",
      label: `“${search}”`,
      onRemove: () => {
        setSearch(null);
        setPage(1);
      },
    });
  filters.brands.forEach((b) =>
    chips.push({
      key: `b-${b}`,
      label: b,
      onRemove: () => update({ brands: filters.brands.filter((x) => x !== b) }),
    })
  );
  if (minPrice != null || maxPrice != null)
    chips.push({
      key: "price",
      label: `${minPrice != null ? formatBDT(minPrice) : "…"} – ${maxPrice != null ? formatBDT(maxPrice) : "…"}`,
      onRemove: () => {
        setMinPrice(null);
        setMaxPrice(null);
        update({ minInput: "", maxInput: "" }, false);
      },
    });
  if (filters.rating != null)
    chips.push({
      key: "rating",
      label: `${filters.rating}+`,
      onRemove: () => update({ rating: null }),
    });
  filters.ram.forEach((r) =>
    chips.push({
      key: `ram-${r}`,
      label: `${t("ram")} ${r}`,
      onRemove: () => update({ ram: filters.ram.filter((x) => x !== r) }),
    })
  );
  filters.storage.forEach((s) =>
    chips.push({
      key: `st-${s}`,
      label: `${t("storageFilter")} ${s}`,
      onRemove: () => update({ storage: filters.storage.filter((x) => x !== s) }),
    })
  );
  filters.stock.forEach((s) =>
    chips.push({
      key: `stock-${s}`,
      label: t(STOCK_LABEL_KEY[s as StockStatus] ?? s),
      onRemove: () => update({ stock: filters.stock.filter((x) => x !== s) }),
    })
  );

  const filterPanel = (
    <FiltersPanel
      state={filters}
      onToggleBrand={(b) => update({ brands: toggleIn(filters.brands, b) })}
      onMinInput={(v) => update({ minInput: v }, false)}
      onMaxInput={(v) => update({ maxInput: v }, false)}
      onApplyPrice={applyPrice}
      onToggleRam={(r) => update({ ram: toggleIn(filters.ram, r) })}
      onToggleStorage={(s) => update({ storage: toggleIn(filters.storage, s) })}
      onRating={(r) => update({ rating: r })}
      onToggleStock={(s) => update({ stock: toggleIn(filters.stock, s) })}
      onClear={clearAll}
    />
  );

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
      {/* Header */}
      <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
        <h1 className="text-xl font-bold text-foreground sm:text-2xl">{title}</h1>
        <p className="text-sm text-muted-foreground" aria-live="polite">
          {loading ? "…" : `${total} ${t("results")}`}
        </p>
      </div>

      {/* Controls row */}
      <div className="mt-4 flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          className="h-9 shrink-0 bg-card lg:hidden"
          onClick={() => setFiltersOpen(true)}
          aria-label={t("filters")}
        >
          <SlidersHorizontal className="h-4 w-4" aria-hidden="true" />
          <span className="hidden sm:inline">{t("filters")}</span>
        </Button>

        <div className="min-w-0 flex-1 sm:flex-none">
          <Select
            value={sort}
            onValueChange={(v) => {
              setSort(v as ProductSort);
              setPage(1);
            }}
          >
            <SelectTrigger
              size="sm"
              aria-label={t("sortBy")}
              className="h-9 w-full bg-card sm:w-[190px]"
            >
              <SelectValue placeholder={t("sortBy")} />
            </SelectTrigger>
            <SelectContent>
              {PRODUCT_SORTS.map((s) => (
                <SelectItem key={s} value={s}>
                  {t(`sort_${s}`)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div
          role="group"
          className="ml-auto flex shrink-0 items-center rounded-lg border bg-card p-0.5"
        >
          <button
            type="button"
            aria-label={t("gridView")}
            aria-pressed={layout === "grid"}
            onClick={() => setLayout("grid")}
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-md transition",
              layout === "grid"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <LayoutGrid className="h-4 w-4" aria-hidden="true" />
          </button>
          <button
            type="button"
            aria-label={t("listView")}
            aria-pressed={layout === "list"}
            onClick={() => setLayout("list")}
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-md transition",
              layout === "list"
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            )}
          >
            <List className="h-4 w-4" aria-hidden="true" />
          </button>
        </div>
      </div>

      {/* Desktop layout: filters sidebar + products */}
      <div className="mt-5 flex items-start gap-6">
        <aside className="hidden w-60 shrink-0 lg:block" aria-label={t("filters")}>
          <div className="sticky top-20">{filterPanel}</div>
        </aside>

        <div className="min-w-0 flex-1">
          {/* Active filter chips */}
          {chips.length > 0 && (
            <div className="mb-4 flex flex-wrap items-center gap-2">
              {chips.map((c) => (
                <span
                  key={c.key}
                  className="inline-flex max-w-full items-center gap-1 rounded-full border bg-card py-1 pr-1 pl-3 text-xs font-medium text-foreground shadow-sm"
                >
                  <span className="max-w-[160px] truncate">{c.label}</span>
                  <button
                    type="button"
                    aria-label={`${t("remove")} ${c.label}`}
                    onClick={c.onRemove}
                    className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground"
                  >
                    <X className="h-3 w-3" aria-hidden="true" />
                  </button>
                </span>
              ))}
            </div>
          )}

          {/* Body states */}
          {loading ? (
            <GridSkeleton layout={layout} />
          ) : error ? (
            <ErrorState message={error} onRetry={() => setReloadKey((k) => k + 1)} />
          ) : products.length === 0 ? (
            <EmptyState onClear={clearAll} />
          ) : (
            <>
              <div
                className={
                  layout === "grid"
                    ? "grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-4"
                    : "flex flex-col gap-3"
                }
              >
                {products.map((p) => (
                  <ProductCard key={p.id} product={p} layout={layout} />
                ))}
              </div>
              <Pagination page={page} pages={pages} onPage={goPage} />
            </>
          )}
        </div>
      </div>

      {/* Mobile filters dialog */}
      <Dialog open={filtersOpen} onOpenChange={setFiltersOpen}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>{t("filters")}</DialogTitle>
            <DialogDescription className="sr-only">
              {t("filters")}
            </DialogDescription>
          </DialogHeader>
          {filterPanel}
          <Button
            className="bg-cta text-cta-foreground hover:bg-cta/90"
            onClick={() => setFiltersOpen(false)}
          >
            {t("apply")}
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ─── Filters panel (desktop sidebar + mobile dialog) ──────────────────────────
function FiltersPanel({
  state,
  onToggleBrand,
  onMinInput,
  onMaxInput,
  onApplyPrice,
  onToggleRam,
  onToggleStorage,
  onRating,
  onToggleStock,
  onClear,
}: {
  state: FilterState;
  onToggleBrand: (b: string) => void;
  onMinInput: (v: string) => void;
  onMaxInput: (v: string) => void;
  onApplyPrice: () => void;
  onToggleRam: (r: string) => void;
  onToggleStorage: (s: string) => void;
  onRating: (r: number | null) => void;
  onToggleStock: (s: string) => void;
  onClear: () => void;
}) {
  const t = useT();

  return (
    <div className="rounded-xl border bg-card p-4 shadow-sm">
      {/* ① Brands */}
      <h3 className="text-sm font-semibold text-foreground">{t("brands")}</h3>
      <div className="mt-3 max-h-44 space-y-2 overflow-y-auto pr-1">
        {BRANDS.map((b) => (
          <label
            key={b}
            className="flex cursor-pointer items-center gap-2 text-sm text-foreground/90"
          >
            <Checkbox
              checked={state.brands.includes(b)}
              onCheckedChange={() => onToggleBrand(b)}
              aria-label={b}
            />
            {b}
          </label>
        ))}
      </div>

      <Separator className="my-4" />

      {/* ② Price range */}
      <h3 className="text-sm font-semibold text-foreground">{t("priceRange")}</h3>
      <div className="mt-3 flex items-center gap-2">
        <Input
          type="number"
          inputMode="numeric"
          min={0}
          placeholder={t("priceMin")}
          aria-label={t("priceMin")}
          value={state.minInput}
          onChange={(e) => onMinInput(e.target.value)}
          className="h-8 bg-background text-sm"
        />
        <span className="text-xs text-muted-foreground">–</span>
        <Input
          type="number"
          inputMode="numeric"
          min={0}
          placeholder={t("priceMax")}
          aria-label={t("priceMax")}
          value={state.maxInput}
          onChange={(e) => onMaxInput(e.target.value)}
          className="h-8 bg-background text-sm"
        />
      </div>
      <Button
        size="sm"
        variant="outline"
        className="mt-2 h-8 w-full border-primary text-primary hover:bg-primary/5 hover:text-primary"
        onClick={onApplyPrice}
      >
        {t("apply")}
      </Button>

      <Separator className="my-4" />

      {/* ③ RAM */}
      <h3 className="text-sm font-semibold text-foreground">{t("ram")}</h3>
      <div className="mt-3 flex flex-wrap gap-2">
        {RAM_OPTIONS.map((r) => (
          <button
            key={r}
            type="button"
            aria-pressed={state.ram.includes(r)}
            onClick={() => onToggleRam(r)}
            className={cn(
              "rounded-lg border px-3 py-1 text-xs font-medium transition",
              state.ram.includes(r)
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-background text-foreground/80 hover:border-primary/50"
            )}
          >
            {r}
          </button>
        ))}
      </div>

      <Separator className="my-4" />

      {/* ④ Storage */}
      <h3 className="text-sm font-semibold text-foreground">{t("storageFilter")}</h3>
      <div className="mt-3 flex flex-wrap gap-2">
        {STORAGE_OPTIONS.map((s) => (
          <button
            key={s}
            type="button"
            aria-pressed={state.storage.includes(s)}
            onClick={() => onToggleStorage(s)}
            className={cn(
              "rounded-lg border px-3 py-1 text-xs font-medium transition",
              state.storage.includes(s)
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-background text-foreground/80 hover:border-primary/50"
            )}
          >
            {s}
          </button>
        ))}
      </div>

      <Separator className="my-4" />

      {/* ⑤ Minimum rating */}
      <h3 className="text-sm font-semibold text-foreground">{t("minRating")}</h3>
      <RadioGroup
        value={state.rating != null ? String(state.rating) : "any"}
        onValueChange={(v) => onRating(v === "any" ? null : Number(v))}
        className="mt-3 gap-2.5"
      >
        {RATING_OPTIONS.map((r) => (
          <label
            key={r}
            className="flex cursor-pointer items-center gap-2 text-sm text-foreground/90"
          >
            <RadioGroupItem value={String(r)} />
            <span className="flex items-center gap-1">
              <span className="flex items-center gap-0.5" aria-hidden="true">
                {[1, 2, 3, 4, 5].map((i) => (
                  <Star
                    key={i}
                    className={cn(
                      "h-3 w-3",
                      i <= Math.round(r)
                        ? "fill-amber-400 text-amber-400"
                        : "text-muted-foreground/30"
                    )}
                  />
                ))}
              </span>
              {r} {t("andUp")}
            </span>
          </label>
        ))}
        <label className="flex cursor-pointer items-center gap-2 text-sm text-foreground/90">
          <RadioGroupItem value="any" />
          {t("any")}
        </label>
      </RadioGroup>

      <Separator className="my-4" />

      {/* ⑥ Availability */}
      <h3 className="text-sm font-semibold text-foreground">{t("availability")}</h3>
      <div className="mt-3 space-y-2.5">
        {STOCK_OPTIONS.map((s) => (
          <label
            key={s}
            className="flex cursor-pointer items-center gap-2 text-sm text-foreground/90"
          >
            <Checkbox
              checked={state.stock.includes(s)}
              onCheckedChange={() => onToggleStock(s)}
              aria-label={t(STOCK_LABEL_KEY[s])}
            />
            <StockBadge status={s} />
          </label>
        ))}
      </div>

      <Button
        variant="ghost"
        size="sm"
        onClick={onClear}
        className="mt-4 h-8 w-full text-muted-foreground hover:text-foreground"
      >
        <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
        {t("clearFilters")}
      </Button>
    </div>
  );
}

// ─── Pagination ──────────────────────────────────────────────────────────────
function Pagination({
  page,
  pages,
  onPage,
}: {
  page: number;
  pages: number;
  onPage: (p: number) => void;
}) {
  const t = useT();
  if (pages <= 1) return null;
  const nums = pageWindow(page, pages);

  return (
    <nav
      aria-label="Pagination"
      className="mt-8 flex flex-wrap items-center justify-center gap-1.5"
    >
      <Button
        variant="outline"
        size="sm"
        className="h-8 bg-card"
        disabled={page <= 1}
        onClick={() => onPage(page - 1)}
      >
        {t("prev")}
      </Button>
      {nums.map((n) => (
        <Button
          key={n}
          size="sm"
          variant={n === page ? "default" : "outline"}
          aria-current={n === page ? "page" : undefined}
          onClick={() => onPage(n)}
          className={cn(
            "h-8 w-8 p-0",
            n !== page && "bg-card"
          )}
        >
          {n}
        </Button>
      ))}
      <Button
        variant="outline"
        size="sm"
        className="h-8 bg-card"
        disabled={page >= pages}
        onClick={() => onPage(page + 1)}
      >
        {t("next")}
      </Button>
      <span className="ml-2 text-xs whitespace-nowrap text-muted-foreground">
        {t("page")} {page} / {pages}
      </span>
    </nav>
  );
}

// ─── Loading skeleton ────────────────────────────────────────────────────────
function GridSkeleton({ layout }: { layout: "grid" | "list" }) {
  if (layout === "list") {
    return (
      <div className="flex flex-col gap-3">
        {Array.from({ length: 5 }).map((_, i) => (
          <div
            key={i}
            className="flex gap-3 rounded-xl border bg-card p-3 shadow-sm"
          >
            <Skeleton className="aspect-square w-32 shrink-0 rounded-lg sm:w-40" />
            <div className="flex-1 space-y-2 py-1">
              <Skeleton className="h-3 w-16" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-24" />
              <Skeleton className="h-5 w-28" />
            </div>
          </div>
        ))}
      </div>
    );
  }
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 xl:grid-cols-4">
      {Array.from({ length: 8 }).map((_, i) => (
        <div className="rounded-xl border bg-card p-2 shadow-sm" key={i}>
          <Skeleton className="aspect-square w-full rounded-lg" />
          <div className="space-y-2 p-1.5">
            <Skeleton className="h-3 w-14" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-3 w-20" />
            <Skeleton className="h-5 w-24" />
            <Skeleton className="h-8 w-full rounded-md" />
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Error state ─────────────────────────────────────────────────────────────
function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  const t = useT();
  return (
    <Alert variant="destructive" className="mt-2">
      <AlertCircle className="h-4 w-4" aria-hidden="true" />
      <AlertTitle>{t("errorOccurred")}</AlertTitle>
      <AlertDescription>
        <p>{t("errorOccurredDesc")}</p>
        <p className="text-xs opacity-70">{message}</p>
        <Button size="sm" variant="outline" className="mt-2" onClick={onRetry}>
          <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
          {t("retry")}
        </Button>
      </AlertDescription>
    </Alert>
  );
}

// ─── Empty state ─────────────────────────────────────────────────────────────
function EmptyState({ onClear }: { onClear: () => void }) {
  const t = useT();
  return (
    <div className="flex flex-col items-center justify-center rounded-xl border border-dashed bg-card px-6 py-16 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
        <PackageSearch className="h-8 w-8 text-muted-foreground/50" aria-hidden="true" />
      </div>
      <h3 className="mt-4 text-lg font-semibold text-foreground">{t("noProducts")}</h3>
      <p className="mt-1 max-w-xs text-sm text-muted-foreground">
        {t("noProductsDesc")}
      </p>
      <Button
        variant="outline"
        className="mt-5 border-primary text-primary hover:bg-primary/5 hover:text-primary"
        onClick={onClear}
      >
        <RotateCcw className="h-4 w-4" aria-hidden="true" />
        {t("clearFilters")}
      </Button>
    </div>
  );
}

export default ShopView;
