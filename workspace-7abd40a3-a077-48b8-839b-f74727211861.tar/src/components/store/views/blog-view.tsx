"use client";
// ─── Arpon Telecom — blog list + article ────────────────────────────────────
import { ArrowLeft, Calendar, ChevronRight, Clock } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useStore } from "@/lib/store";
import { useT } from "@/lib/i18n";
import { formatDate } from "@/lib/format";
import { BLOG_POSTS, getBlogPost, type BlogCategory, type BlogPost } from "@/lib/blog-data";

const CATEGORY_LABEL: Record<BlogCategory, { en: string; bn: string; cls: string }> = {
  guide: { en: "Guide", bn: "গাইড", cls: "border-transparent bg-emerald-100 text-emerald-700" },
  comparison: { en: "Comparison", bn: "তুলনা", cls: "border-transparent bg-primary/10 text-primary" },
  news: { en: "News", bn: "নিউজ", cls: "border-transparent bg-amber-100 text-amber-700" },
};

function CategoryBadge({ category }: { category: BlogCategory }) {
  const lang = useStore((s) => s.lang);
  const c = CATEGORY_LABEL[category];
  return <Badge className={c.cls}>{lang === "bn" ? c.bn : c.en}</Badge>;
}

// ─── Article ────────────────────────────────────────────────────────────────
export function BlogArticleView({ slug }: { slug: string }) {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const navigate = useStore((s) => s.navigate);
  const post: BlogPost | undefined = getBlogPost(slug);

  if (!post) {
    return (
      <div className="mx-auto max-w-3xl px-3 py-10 sm:px-4">
        <div className="rounded-xl border bg-card p-10 text-center">
          <p className="text-sm text-muted-foreground">{t("noProducts")}</p>
          <Button variant="outline" className="mt-4" onClick={() => navigate({ name: "blog" })}>
            <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            {t("backToBlog")}
          </Button>
        </div>
      </div>
    );
  }

  const paragraphs = lang === "bn" ? post.contentBn : post.contentEn;

  return (
    <div className="mx-auto max-w-3xl px-3 py-8 sm:px-4">
      <Button
        variant="ghost"
        size="sm"
        className="-ml-2 mb-4 text-muted-foreground hover:text-primary"
        onClick={() => navigate({ name: "blog" })}
      >
        <ArrowLeft className="h-4 w-4" aria-hidden="true" />
        {t("backToBlog")}
      </Button>

      <article className="rounded-xl border bg-card p-5 sm:p-8">
        <CategoryBadge category={post.category} />
        <h1 className="mt-3 text-2xl font-bold leading-snug text-foreground sm:text-3xl">
          {lang === "bn" ? post.titleBn : post.titleEn}
        </h1>
        <div className="mt-3 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1.5">
            <Calendar className="h-4 w-4" aria-hidden="true" />
            {formatDate(post.date, lang)}
          </span>
          <span className="inline-flex items-center gap-1.5">
            <Clock className="h-4 w-4" aria-hidden="true" />
            {post.readTime} {t("minRead")}
          </span>
        </div>

        <Separator className="my-6" />

        <div className="space-y-4 leading-relaxed text-muted-foreground">
          {paragraphs.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-8 flex flex-col items-center justify-between gap-4 rounded-xl border bg-primary/5 p-5 sm:flex-row">
          <div>
            <h2 className="font-semibold text-foreground">{t("blogCta")}</h2>
            <p className="mt-0.5 text-sm text-muted-foreground">{t("blogCtaDesc")}</p>
          </div>
          <Button
            className="shrink-0 bg-cta text-cta-foreground hover:bg-cta/90"
            onClick={() => navigate({ name: "shop" })}
          >
            {t("shopNow")}
          </Button>
        </div>
      </article>
    </div>
  );
}

// ─── List ───────────────────────────────────────────────────────────────────
export function BlogView() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const view = useStore((s) => s.view);
  const navigate = useStore((s) => s.navigate);

  // If the active view is a single post, render the article instead.
  if (view.name === "blogPost") {
    return <BlogArticleView slug={view.slug} />;
  }

  function openPost(slug: string) {
    navigate({ name: "blogPost", slug });
  }

  return (
    <div className="mx-auto max-w-7xl px-3 py-8 sm:px-4 lg:px-6">
      <header className="mb-6 text-center">
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">{t("blogTitle")}</h1>
      </header>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {BLOG_POSTS.map((post) => (
          <article
            key={post.slug}
            className="group flex cursor-pointer flex-col overflow-hidden rounded-xl border bg-card transition-shadow hover:shadow-md"
            onClick={() => openPost(post.slug)}
          >
            <div className="relative flex h-28 items-center justify-center bg-gradient-to-br from-primary/10 to-cta/10">
              <span className="text-5xl transition-transform group-hover:scale-110" aria-hidden="true">
                {post.emoji}
              </span>
              <div className="absolute left-2 top-2">
                <CategoryBadge category={post.category} />
              </div>
            </div>

            <div className="flex flex-1 flex-col p-4">
              <h2 className="font-semibold leading-snug text-foreground">
                <button
                  type="button"
                  className="text-left line-clamp-2 hover:text-primary"
                  onClick={(e) => {
                    e.stopPropagation();
                    openPost(post.slug);
                  }}
                >
                  {lang === "bn" ? post.titleBn : post.titleEn}
                </button>
              </h2>
              <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">
                {lang === "bn" ? post.excerptBn : post.excerptEn}
              </p>

              <div className="mt-auto flex items-center justify-between gap-2 border-t pt-3 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" aria-hidden="true" />
                  {formatDate(post.date, lang)}
                </span>
                <span className="inline-flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" aria-hidden="true" />
                  {post.readTime} {t("minRead")}
                </span>
                <span className="inline-flex items-center gap-0.5 font-medium text-primary">
                  {t("readMore")}
                  <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

export default BlogView;
