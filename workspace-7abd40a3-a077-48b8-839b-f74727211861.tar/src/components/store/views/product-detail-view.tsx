"use client";
// ─── Arpon Telecom — Product detail view (gallery · variants · tabs · reviews) ─
import { useEffect, useMemo, useState } from "react";
import {
  BadgeCheck,
  ChevronRight,
  CreditCard,
  Headset,
  Heart,
  MapPin,
  Minus,
  PackageSearch,
  Plus,
  Scale,
  ShieldCheck,
  ShoppingCart,
  Smartphone,
  Truck,
} from "lucide-react";
import { toast } from "sonner";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getJSON } from "@/lib/api";
import { discountPercent, formatDate } from "@/lib/format";
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import type { ProductDetailDTO, Spec } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Price } from "../price";
import { ProductCard } from "../product-card";
import { SectionHeading } from "../section-heading";
import { StarRating } from "../star-rating";
import { StockBadge } from "../stock-badge";

// Common color-name → hex for variant dots (fallback: no dot).
const COLOR_HEX: [string, string][] = [
  ["black", "#1f2937"],
  ["midnight", "#1f2937"],
  ["blue", "#2563eb"],
  ["gold", "#d4af37"],
  ["green", "#16a34a"],
  ["white", "#f3f4f6"],
  ["starlight", "#f3f4f6"],
  ["purple", "#7c3aed"],
  ["silver", "#cbd5e1"],
  ["gray", "#6b7280"],
  ["grey", "#6b7280"],
  ["pink", "#ec4899"],
  ["red", "#dc2626"],
  ["orange", "#f97316"],
];

function colorHex(name: string): string | null {
  const n = name.toLowerCase();
  for (const [k, v] of COLOR_HEX) if (n.includes(k)) return v;
  return null;
}

export function ProductDetailView() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const navigate = useStore((s) => s.navigate);
  const addToCart = useStore((s) => s.addToCart);
  const toggleWishlist = useStore((s) => s.toggleWishlist);
  const toggleCompare = useStore((s) => s.toggleCompare);
  const view = useStore((s) => s.view);
  const slug = view.name === "product" ? view.slug : "";

  const [product, setProduct] = useState<ProductDetailDTO | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reloadKey, setReloadKey] = useState(0);

  // Gallery state
  const [imgIdx, setImgIdx] = useState(0);
  const [zoom, setZoom] = useState(false);
  const [origin, setOrigin] = useState("50% 50%");

  // Variant / qty state
  const [variantSel, setVariantSel] = useState<Record<string, string>>({});
  const [qty, setQty] = useState(1);

  // ── Fetch ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!slug) return;
    let cancelled = false;
    const run = async () => {
      setLoading(true);
      setNotFound(false);
      setError(null);
      setProduct(null);
      try {
        const d = await getJSON<{ product: ProductDetailDTO }>(
          `/api/products/${encodeURIComponent(slug)}`
        );
        if (cancelled) return;
        setProduct(d.product);
      } catch (e: unknown) {
        if (cancelled) return;
        const msg = e instanceof Error ? e.message : "Failed to load product";
        if (msg.includes("404")) setNotFound(true);
        else setError(msg);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => {
      cancelled = true;
    };
  }, [slug, reloadKey]);

  // Reset per-product UI state when the product loads/changes.
  useEffect(() => {
    if (!product) return;
    const reset = () => {
      const init: Record<string, string> = {};
      for (const g of product.variants ?? []) {
        if (g.options?.length) init[g.nameEn] = g.options[0];
      }
      setVariantSel(init);
      setQty(1);
      setImgIdx(0);
      setZoom(false);
    };
    reset();
  }, [product]);

  const wishlisted = useStore((s) =>
    product ? s.wishlist.includes(product.id) : false
  );

  // ── Derived ────────────────────────────────────────────────────────────────
  const name = product ? (lang === "bn" ? product.nameBn : product.nameEn) : "";
  const description = product
    ? lang === "bn"
      ? product.descriptionBn
      : product.descriptionEn
    : "";
  const warranty = product
    ? lang === "bn"
      ? product.warrantyBn
      : product.warrantyEn
    : "";
  const images = useMemo(
    () => (product?.images ?? []).filter(Boolean),
    [product]
  );
  const activeImg = images[imgIdx] ?? images[0];
  const discount = product ? discountPercent(product.price, product.oldPrice) : null;
  const outOfStock = product?.stockStatus === "out_of_stock";

  const variantStr = product
    ? (product.variants ?? [])
        .map((g) => variantSel[g.nameEn])
        .filter(Boolean)
        .join(" · ") || undefined
    : undefined;

  const firstSpecs = useMemo(
    () => (product?.specs ?? []).slice(0, 4),
    [product]
  );

  // ── Handlers ───────────────────────────────────────────────────────────────
  const handleZoomMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setOrigin(`${x}% ${y}%`);
    setZoom(true);
  };

  const cartItem = product
    ? {
        productId: product.id,
        slug: product.slug,
        nameEn: product.nameEn,
        nameBn: product.nameBn,
        price: product.price,
        image: images[0] ?? "",
        variant: variantStr,
      }
    : null;

  const handleAdd = (goCheckout: boolean) => {
    if (!product || !cartItem || outOfStock) return;
    addToCart(cartItem, qty);
    toast.success(t("addedToCart"));
    if (goCheckout) navigate({ name: "checkout" });
  };

  const handleWishlist = () => {
    if (!product) return;
    toggleWishlist(product.id);
    if (wishlisted) toast(t("wishlistRemove"));
    else toast.success(t("wishlistAdd"));
  };

  const handleCompare = () => {
    if (!product) return;
    const res = toggleCompare(product.id);
    if (res.status === "full") toast.error(t("compareFull"));
    else if (res.status === "added") toast.success(t("compareAdd"));
    else toast(t("compareRemove"));
  };

  // ── States ─────────────────────────────────────────────────────────────────
  if (loading) return <DetailSkeleton />;

  if (notFound) {
    return (
      <div className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
        <div className="mx-auto flex max-w-md flex-col items-center rounded-xl border bg-card px-6 py-16 text-center shadow-sm">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-muted">
            <PackageSearch
              className="h-8 w-8 text-muted-foreground/50"
              aria-hidden="true"
            />
          </div>
          <h1 className="mt-4 text-lg font-semibold text-foreground">
            {t("productNotFound")}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {t("productNotFoundDesc")}
          </p>
          <Button
            className="mt-5 bg-cta text-cta-foreground hover:bg-cta/90"
            onClick={() => navigate({ name: "shop" })}
          >
            {t("backToShop")}
          </Button>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
        <Alert variant="destructive">
          <AlertTitle>{t("errorOccurred")}</AlertTitle>
          <AlertDescription>
            <p>{error ?? t("errorOccurredDesc")}</p>
            <Button
              size="sm"
              variant="outline"
              className="mt-2"
              onClick={() => setReloadKey((k) => k + 1)}
            >
              {t("retry")}
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
      {/* Breadcrumb */}
      <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1 text-xs text-muted-foreground sm:text-sm">
        <button
          type="button"
          onClick={() => navigate({ name: "home" })}
          className="rounded px-0.5 transition-colors hover:text-primary"
        >
          {t("nav_home")}
        </button>
        <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
        <button
          type="button"
          onClick={() => navigate({ name: "shop", category: product.categorySlug })}
          className="rounded px-0.5 transition-colors hover:text-primary"
        >
          {lang === "bn" ? product.categoryNameBn : product.categoryNameEn}
        </button>
        <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
        <span aria-current="page" className="line-clamp-1 font-medium text-foreground">
          {name}
        </span>
      </nav>

      {/* Top grid */}
      <div className="mt-4 grid gap-6 lg:grid-cols-2">
        {/* ① Gallery */}
        <section aria-label={t("description")}>
          <div
            className="relative aspect-square cursor-zoom-in overflow-hidden rounded-2xl border bg-white"
            onMouseMove={handleZoomMove}
            onMouseLeave={() => setZoom(false)}
          >
            {activeImg ? (
              <img
                src={activeImg}
                alt={name}
                className="h-full w-full object-cover transition-transform duration-200 ease-out"
                style={{
                  transform: zoom ? "scale(1.8)" : "scale(1)",
                  transformOrigin: origin,
                }}
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center bg-muted text-muted-foreground/40">
                <Smartphone className="h-16 w-16" aria-hidden="true" />
              </div>
            )}
            {discount != null && (
              <span className="absolute top-3 left-3 z-10 rounded-full bg-cta px-2.5 py-1 text-xs font-bold text-white shadow-sm">
                -{discount}%
              </span>
            )}
            <span className="absolute top-3 right-3 z-10">
              <StockBadge status={product.stockStatus} />
            </span>
          </div>

          {images.length > 1 && (
            <div className="mt-3 flex flex-wrap gap-2" role="tablist" aria-label={name}>
              {images.map((img, i) => (
                <button
                  key={`${img}-${i}`}
                  type="button"
                  role="tab"
                  aria-selected={i === imgIdx}
                  aria-label={`${name} ${i + 1}`}
                  onClick={() => setImgIdx(i)}
                  className={cn(
                    "h-16 w-16 overflow-hidden rounded-lg border-2 transition",
                    i === imgIdx
                      ? "border-primary"
                      : "border-border hover:border-primary/50"
                  )}
                >
                  <img
                    src={img}
                    alt=""
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                </button>
              ))}
            </div>
          )}
        </section>

        {/* ② Info */}
        <section className="min-w-0">
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
            {product.brand}
          </p>
          <h1 className="mt-1 text-2xl font-bold text-foreground">{name}</h1>

          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1">
            <StarRating rating={product.rating} count={product.reviewCount} size="md" />
            {product.soldCount > 0 && (
              <span className="text-xs text-muted-foreground">
                {product.soldCount} {t("sold")}
              </span>
            )}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <Price price={product.price} oldPrice={product.oldPrice} size="lg" />
            {discount != null && (
              <span className="rounded-full bg-cta/10 px-2 py-0.5 text-xs font-bold text-cta">
                -{discount}%
              </span>
            )}
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-2">
            <StockBadge status={product.stockStatus} />
            {product.stockStatus === "in_stock" &&
              product.stock > 0 &&
              product.stock <= 5 && (
                <span className="text-xs font-semibold text-amber-600">
                  {t("onlyLeft")} ({product.stock})
                </span>
              )}
          </div>

          {/* Variants */}
          {(product.variants ?? []).length > 0 && (
            <div className="mt-5 space-y-4">
              {(product.variants ?? []).map((g) => (
                <div key={g.nameEn}>
                  <p className="text-sm font-medium text-foreground">
                    {lang === "bn" ? g.nameBn || g.nameEn : g.nameEn}
                  </p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {(g.options ?? []).map((opt) => {
                      const active = variantSel[g.nameEn] === opt;
                      const hex = g.type === "color" ? colorHex(opt) : null;
                      return (
                        <button
                          key={opt}
                          type="button"
                          aria-pressed={active}
                          onClick={() =>
                            setVariantSel((v) => ({ ...v, [g.nameEn]: opt }))
                          }
                          className={cn(
                            "flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm transition",
                            active
                              ? "border-primary bg-primary text-primary-foreground"
                              : "border-border bg-background text-foreground/85 hover:border-primary/50"
                          )}
                        >
                          {hex && (
                            <span
                              aria-hidden="true"
                              className="h-3 w-3 rounded-full border border-black/10"
                              style={{ background: hex }}
                            />
                          )}
                          {opt}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Qty + CTA row */}
          <div className="mt-6 flex flex-wrap items-center gap-2">
            <div
              className="flex h-11 items-center rounded-lg border bg-card"
              role="group"
              aria-label={t("quantity")}
            >
              <button
                type="button"
                aria-label="-"
                disabled={qty <= 1}
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="flex h-full w-9 items-center justify-center text-muted-foreground transition hover:text-foreground disabled:opacity-40"
              >
                <Minus className="h-4 w-4" aria-hidden="true" />
              </button>
              <span className="w-8 text-center text-sm font-semibold" aria-live="polite">
                {qty}
              </span>
              <button
                type="button"
                aria-label="+"
                onClick={() => setQty((q) => q + 1)}
                className="flex h-full w-9 items-center justify-center text-muted-foreground transition hover:text-foreground"
              >
                <Plus className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            <Button
              disabled={outOfStock}
              onClick={() => handleAdd(false)}
              className="h-11 min-w-[150px] flex-1 bg-cta text-cta-foreground hover:bg-cta/90"
            >
              <ShoppingCart className="h-4 w-4" aria-hidden="true" />
              {t("addToCart")}
            </Button>
            <Button
              disabled={outOfStock}
              onClick={() => handleAdd(true)}
              variant="outline"
              className="h-11 min-w-[110px] flex-1 border-primary text-primary hover:bg-primary/5 hover:text-primary"
            >
              {t("buyNow")}
            </Button>

            <Button
              variant="outline"
              size="icon"
              className="h-11 w-11"
              aria-label={wishlisted ? t("wishlistRemove") : t("wishlistAdd")}
              onClick={handleWishlist}
            >
              <Heart
                className={cn(
                  "h-5 w-5",
                  wishlisted ? "fill-rose-500 text-rose-500" : "text-muted-foreground"
                )}
                aria-hidden="true"
              />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="h-11 w-11"
              aria-label={t("compare")}
              onClick={handleCompare}
            >
              <Scale className="h-5 w-5 text-muted-foreground" aria-hidden="true" />
            </Button>
          </div>

          {/* Trust badges */}
          <div className="mt-5 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {[
              { icon: BadgeCheck, key: "trust_genuine" },
              { icon: ShieldCheck, key: "trust_warranty" },
              { icon: CreditCard, key: "trust_payment" },
              { icon: Headset, key: "trust_support" },
            ].map(({ icon: Icon, key }) => (
              <div
                key={key}
                className="flex items-center gap-1.5 rounded-lg border bg-card px-2.5 py-2 text-[11px] leading-tight text-muted-foreground"
              >
                <Icon className="h-4 w-4 shrink-0 text-primary" aria-hidden="true" />
                {t(key)}
              </div>
            ))}
          </div>

          {/* Delivery box */}
          <div className="mt-4 space-y-2 rounded-xl border bg-muted/50 p-4 text-sm">
            <p className="flex items-center gap-2 font-semibold text-foreground">
              <Truck className="h-4 w-4 text-primary" aria-hidden="true" />
              {t("deliveryEstimate")}
            </p>
            <p className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4 shrink-0 text-primary/70" aria-hidden="true" />
              {t("deliveryInside")}
            </p>
            <p className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-4 w-4 shrink-0 text-primary/70" aria-hidden="true" />
              {t("deliveryOutside")}
            </p>
            {warranty && (
              <p className="flex items-center gap-2 text-muted-foreground">
                <ShieldCheck
                  className="h-4 w-4 shrink-0 text-emerald-600"
                  aria-hidden="true"
                />
                {t("warrantyInfo")}: {warranty}
              </p>
            )}
          </div>
        </section>
      </div>

      {/* Description & Specifications */}
      <section className="mt-10">
        <Tabs defaultValue="description">
          <TabsList>
            <TabsTrigger value="description">{t("description")}</TabsTrigger>
            <TabsTrigger value="specs">{t("specifications")}</TabsTrigger>
          </TabsList>

          <TabsContent value="description" className="mt-4">
            <p className="max-w-3xl leading-relaxed text-muted-foreground whitespace-pre-line">
              {description || "—"}
            </p>
            {firstSpecs.length > 0 && (
              <div className="mt-6 max-w-3xl">
                <h3 className="text-sm font-semibold text-foreground">
                  {t("keySpecs")}
                </h3>
                <dl className="mt-3 divide-y overflow-hidden rounded-xl border">
                  {firstSpecs.map((s, i) => (
                    <div
                      key={`${s.labelEn}-${i}`}
                      className={cn(
                        "flex items-center justify-between gap-4 px-4 py-2.5 text-sm",
                        i % 2 === 1 && "bg-muted/40"
                      )}
                    >
                      <dt className="shrink-0 font-medium text-foreground">
                        {specLabel(s, lang)}
                      </dt>
                      <dd className="text-right text-muted-foreground">
                        {specValue(s, lang)}
                      </dd>
                    </div>
                  ))}
                </dl>
              </div>
            )}
          </TabsContent>

          <TabsContent value="specs" className="mt-4">
            {(product.specs ?? []).length > 0 ? (
              <div className="max-w-3xl overflow-hidden rounded-xl border">
                <table className="w-full text-sm">
                  <tbody>
                    {(product.specs ?? []).map((s, i) => (
                      <tr key={`${s.labelEn}-${i}`} className={cn(i % 2 === 1 && "bg-muted/40")}>
                        <th
                          scope="row"
                          className="w-2/5 px-4 py-2.5 text-left align-top font-medium text-foreground"
                        >
                          {specLabel(s, lang)}
                        </th>
                        <td className="px-4 py-2.5 align-top text-muted-foreground">
                          {specValue(s, lang)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">—</p>
            )}
          </TabsContent>
        </Tabs>
      </section>

      {/* Reviews */}
      <section className="mt-10" aria-label={t("reviewsTab")}>
        <div className="flex flex-wrap items-center gap-3">
          <h2 className="text-lg font-bold text-foreground">{t("reviewsTab")}</h2>
          <StarRating rating={product.rating} size="md" />
          <span className="text-sm text-muted-foreground">
            {product.reviewCount} {t("reviewsCount")}
          </span>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-2">
          {(product.reviews ?? []).map((r) => (
            <article key={r.id} className="rounded-xl border bg-card p-4 shadow-sm">
              <div className="flex items-center gap-3">
                <Avatar className="h-9 w-9">
                  <AvatarFallback className="bg-primary/10 text-xs font-bold text-primary">
                    {r.name
                      .split(/\s+/)
                      .map((w) => w[0])
                      .slice(0, 2)
                      .join("")
                      .toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-foreground">{r.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {formatDate(r.createdAt, lang)}
                  </p>
                </div>
                <div className="ml-auto shrink-0">
                  <StarRating rating={r.rating} />
                </div>
              </div>
              {r.comment && (
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                  {r.comment}
                </p>
              )}
            </article>
          ))}
        </div>
        {(product.reviews ?? []).length === 0 && (
          <p className="mt-3 text-sm text-muted-foreground">{t("noReviews")}</p>
        )}
      </section>

      {/* Related */}
      {(product.related ?? []).length > 0 && (
        <section className="mt-12">
          <SectionHeading titleKey="relatedProducts" />
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
            {(product.related ?? []).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

// ─── Helpers ─────────────────────────────────────────────────────────────────
function specLabel(s: Spec, lang: "en" | "bn"): string {
  return (lang === "bn" ? s.labelBn || s.labelEn : s.labelEn) || "—";
}

function specValue(s: Spec, lang: "en" | "bn"): string {
  return (lang === "bn" ? s.valueBn || s.valueEn : s.valueEn) || "—";
}

// ─── Loading skeleton ────────────────────────────────────────────────────────
function DetailSkeleton() {
  return (
    <div className="mx-auto max-w-7xl px-3 py-6 sm:px-4 lg:px-6">
      <Skeleton className="h-4 w-48" />
      <div className="mt-4 grid gap-6 lg:grid-cols-2">
        <div className="space-y-3">
          <Skeleton className="aspect-square w-full rounded-2xl" />
          <div className="flex gap-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-16 w-16 rounded-lg" />
            ))}
          </div>
        </div>
        <div className="space-y-3">
          <Skeleton className="h-3 w-16" />
          <Skeleton className="h-7 w-3/4" />
          <Skeleton className="h-4 w-40" />
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-6 w-32" />
          <div className="flex gap-2 pt-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-9 w-20 rounded-lg" />
            ))}
          </div>
          <div className="flex gap-2 pt-3">
            <Skeleton className="h-11 flex-1" />
            <Skeleton className="h-11 flex-1" />
            <Skeleton className="h-11 w-11" />
            <Skeleton className="h-11 w-11" />
          </div>
          <Skeleton className="h-20 w-full rounded-xl" />
        </div>
      </div>
    </div>
  );
}

export default ProductDetailView;
