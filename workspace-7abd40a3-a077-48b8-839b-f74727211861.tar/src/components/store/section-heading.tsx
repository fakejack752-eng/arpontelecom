"use client";
// ─── Arpon Telecom — section title + optional "View All" action ─────────────
import { ChevronRight } from "lucide-react";

import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";

export function SectionHeading({
  titleKey,
  subtitleKey,
  onViewAll,
}: {
  titleKey: string;
  subtitleKey?: string;
  onViewAll?: () => void;
}) {
  const t = useT();

  return (
    <div className="mb-5 flex items-end justify-between gap-4">
      <div className="min-w-0">
        <h2 className="text-xl font-bold text-foreground md:text-2xl">
          {t(titleKey)}
        </h2>
        {subtitleKey && (
          <p className="mt-1 text-sm text-muted-foreground">{t(subtitleKey)}</p>
        )}
      </div>
      {onViewAll && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onViewAll}
          className="-mb-1 shrink-0 text-primary hover:bg-primary/5 hover:text-primary"
        >
          {t("viewAll")}
          <ChevronRight className="h-4 w-4" aria-hidden="true" />
        </Button>
      )}
    </div>
  );
}
