"use client";
// ─── Arpon Telecom — product card (grid + list layouts) ─────────────────────
import { motion } from "framer-motion";
import { Heart, ShoppingCart, Smartphone } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { discountPercent } from "@/lib/format";
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import type { ProductDTO } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Price } from "./price";
import { StarRating } from "./star-rating";
import { StockBadge } from "./stock-badge";

export function ProductCard({
  product,
  layout = "grid",
}: {
  product: ProductDTO;
  layout?: "grid" | "list";
}) {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const navigate = useStore((s) => s.navigate);
  const addToCart = useStore((s) => s.addToCart);
  const toggleWishlist = useStore((s) => s.toggleWishlist);
  const wishlisted = useStore((s) => s.wishlist.includes(product.id));

  const name = lang === "bn" ? product.nameBn : product.nameEn;
  const description = lang === "bn" ? product.descriptionBn : product.descriptionEn;
  const image = product.images?.[0];
  const discount = discountPercent(product.price, product.oldPrice);
  const outOfStock = product.stockStatus === "out_of_stock";

  const openProduct = () => navigate({ name: "product", slug: product.slug });

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleWishlist(product.id);
    if (wishlisted) {
      toast(t("wishlistRemove"));
    } else {
      toast.success(t("wishlistAdd"));
    }
  };

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart({
      productId: product.id,
      slug: product.slug,
      nameEn: product.nameEn,
      nameBn: product.nameBn,
      price: product.price,
      image: image ?? "",
      variant: undefined,
    });
    toast.success(t("addedToCart"));
  };

  const discountBadge = discount != null && (
    <span className="absolute top-2 left-2 z-10 rounded-full bg-cta px-2 py-0.5 text-xs font-bold text-white shadow-sm">
      -{discount}%
    </span>
  );

  const imageFallback = (
    <div className="flex h-full w-full items-center justify-center bg-muted text-muted-foreground/40">
      <Smartphone className="h-12 w-12" aria-hidden="true" />
    </div>
  );

  const ctaCls = "bg-cta text-cta-foreground hover:bg-cta/90";

  // Subtle lift + spring on hover for both layouts.
  const hoverMotion = {
    whileHover: { y: -4 },
    transition: { type: "spring" as const, stiffness: 300, damping: 22 },
  };

  /* ── List layout ─────────────────────────────────────────────────────────── */
  if (layout === "list") {
    return (
      <motion.article
        onClick={openProduct}
        {...hoverMotion}
        className="group flex cursor-pointer overflow-hidden rounded-xl border bg-card shadow-sm transition-all hover:shadow-lg"
      >
        <div className="relative aspect-square w-32 shrink-0 overflow-hidden bg-muted sm:w-40">
          {image ? (
            <img
              src={image}
              alt={name}
              loading="lazy"
              className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            />
          ) : (
            imageFallback
          )}
          {discountBadge}
          {product.stockStatus !== "in_stock" && (
            <span className="absolute bottom-2 left-2 z-10">
              <StockBadge status={product.stockStatus} />
            </span>
          )}
          <button
            type="button"
            aria-label={
              wishlisted ? t("wishlistRemove") : t("wishlistAdd")
            }
            onClick={handleWishlist}
            className="absolute right-2 bottom-2 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 shadow transition hover:scale-110"
          >
            <Heart
              className={cn(
                "h-4 w-4",
                wishlisted ? "fill-rose-500 text-rose-500" : "text-muted-foreground"
              )}
            />
          </button>
        </div>

        <div className="flex min-w-0 flex-1 flex-col p-3 sm:p-4">
          <p className="text-[11px] font-medium tracking-wide text-muted-foreground uppercase">
            {product.brand}
          </p>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              openProduct();
            }}
            className="mt-0.5 line-clamp-2 text-left font-medium text-foreground transition-colors hover:text-primary sm:text-base"
          >
            {name}
          </button>
          <div className="mt-1">
            <StarRating rating={product.rating} count={product.reviewCount} />
          </div>
          <p className="mt-1.5 hidden text-sm leading-relaxed text-muted-foreground sm:line-clamp-2 sm:block">
            {description}
          </p>
          <div className="mt-auto flex flex-wrap items-end justify-between gap-x-4 gap-y-2 pt-2">
            <div>
              <Price price={product.price} oldPrice={product.oldPrice} size="md" />
              {product.soldCount > 0 && (
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  {product.soldCount} {t("sold")}
                </p>
              )}
            </div>
            {outOfStock ? (
              <Button
                variant="outline"
                disabled
                className="h-9 w-auto px-4 text-sm"
              >
                {t("outOfStock")}
              </Button>
            ) : (
              <Button
                onClick={handleAddToCart}
                className={cn(ctaCls, "h-9 w-auto px-4")}
              >
                <ShoppingCart className="h-4 w-4" aria-hidden="true" />
                {t("addToCart")}
              </Button>
            )}
          </div>
        </div>
      </motion.article>
    );
  }

  /* ── Grid layout ─────────────────────────────────────────────────────────── */
  return (
    <motion.article
      onClick={openProduct}
      {...hoverMotion}
      className="group cursor-pointer rounded-xl border bg-card shadow-sm transition-all hover:shadow-lg"
    >
      <div className="relative aspect-square overflow-hidden rounded-t-xl bg-muted">
        {image ? (
          <img
            src={image}
            alt={name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
        ) : (
          imageFallback
        )}
        {discountBadge}
        {product.stockStatus !== "in_stock" && (
          <span className="absolute top-2 right-2 z-10">
            <StockBadge status={product.stockStatus} />
          </span>
        )}
        <button
          type="button"
          aria-label={wishlisted ? t("wishlistRemove") : t("wishlistAdd")}
          onClick={handleWishlist}
          className="absolute right-2 bottom-2 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 shadow transition hover:scale-110"
        >
          <Heart
            className={cn(
              "h-4 w-4",
              wishlisted ? "fill-rose-500 text-rose-500" : "text-muted-foreground"
            )}
          />
        </button>
      </div>

      <div className="p-3">
        <p className="text-[11px] font-medium tracking-wide text-muted-foreground uppercase">
          {product.brand}
        </p>
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            openProduct();
          }}
          className="mt-0.5 line-clamp-2 min-h-[2.5rem] text-left text-sm leading-snug font-medium text-foreground transition-colors hover:text-primary"
        >
          {name}
        </button>
        <div className="mt-1">
          <StarRating rating={product.rating} count={product.reviewCount} />
        </div>
        <div className="mt-1.5">
          <Price price={product.price} oldPrice={product.oldPrice} size="md" />
        </div>
        {product.soldCount > 0 && (
          <p className="mt-0.5 text-[11px] text-muted-foreground">
            {product.soldCount} {t("sold")}
          </p>
        )}
        {outOfStock ? (
          <Button
            variant="outline"
            disabled
            className="mt-2 h-9 w-full text-sm"
          >
            {t("outOfStock")}
          </Button>
        ) : (
          <Button
            onClick={handleAddToCart}
            className={cn(ctaCls, "mt-2 h-9 w-full")}
          >
            <ShoppingCart className="h-4 w-4" aria-hidden="true" />
            {t("addToCart")}
          </Button>
        )}
      </div>
    </motion.article>
  );
}
