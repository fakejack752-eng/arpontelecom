"use client";
// ─── Arpon Telecom — floating compare bar (bottom, up to 3 products) ──────────
import { useEffect, useMemo, useState } from "react";
import { X } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { getJSON } from "@/lib/api";
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import type { ProductDTO } from "@/lib/types";
import { cn } from "@/lib/utils";

interface ProductsRes {
  products: ProductDTO[];
  total: number;
  page: number;
  pages: number;
}

export function CompareBar() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const compare = useStore((s) => s.compare);
  const toggleCompare = useStore((s) => s.toggleCompare);
  const setCompareOpen = useStore((s) => s.setCompareOpen);

  const idsKey = compare.join(",");
  const [products, setProducts] = useState<ProductDTO[]>([]);

  useEffect(() => {
    if (!idsKey) return;
    let cancelled = false;
    const run = async () => {
      try {
        const d = await getJSON<ProductsRes>(
          `/api/products?ids=${encodeURIComponent(idsKey)}&limit=10`
        );
        if (!cancelled) setProducts(d.products ?? []);
      } catch {
        // Bar stays with what it has; it's a secondary UI affordance.
      }
    };
    run();
    return () => {
      cancelled = true;
    };
  }, [idsKey]);

  const visible = compare.length > 0;

  // Preserve the store's compare order; skeleton placeholders while loading.
  const ordered = useMemo(
    () =>
      compare
        .map((id) => products.find((p) => p.id === id))
        .filter((p): p is ProductDTO => Boolean(p)),
    [compare, products]
  );
  const pendingCount = compare.length - ordered.length;

  return (
    <aside
      aria-label={t("compare")}
      inert={!visible}
      className={cn(
        "fixed inset-x-0 bottom-0 z-30 rounded-t-xl bg-primary p-3 text-white shadow-2xl transition-transform duration-300 sm:inset-x-auto sm:right-4 sm:bottom-4 sm:max-w-md sm:rounded-xl",
        visible ? "translate-y-0" : "pointer-events-none translate-y-full"
      )}
    >
      <div className="mx-auto flex max-w-7xl items-center gap-3 pr-24">
        <span
          className="shrink-0 text-xs font-bold whitespace-nowrap"
          aria-live="polite"
        >
          {compare.length}/3
        </span>

        <div className="flex min-w-0 flex-1 items-center gap-2 overflow-x-auto no-scrollbar">
          {ordered.map((p) => {
            const name = lang === "bn" ? p.nameBn : p.nameEn;
            const img = p.images?.[0];
            return (
              <span key={p.id} className="relative shrink-0" title={name}>
                {img ? (
                  <img
                    src={img}
                    alt={name}
                    className="h-10 w-10 rounded border-2 border-white/30 object-cover"
                  />
                ) : (
                  <span className="flex h-10 w-10 items-center justify-center rounded border-2 border-white/30 bg-white/10 text-xs">
                    ?
                  </span>
                )}
                <button
                  type="button"
                  aria-label={`${t("remove_compare")}: ${name}`}
                  onClick={() => toggleCompare(p.id)}
                  className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-cta text-white shadow-sm transition hover:scale-110"
                >
                  <X className="h-2.5 w-2.5" aria-hidden="true" />
                </button>
              </span>
            );
          })}
          {pendingCount > 0 &&
            Array.from({ length: pendingCount }).map((_, i) => (
              <Skeleton
                key={`pending-${i}`}
                className="h-10 w-10 shrink-0 rounded border-2 border-white/20 bg-white/20"
              />
            ))}
        </div>

        <Button
          onClick={() => setCompareOpen(true)}
          className="h-9 shrink-0 bg-cta text-xs text-cta-foreground hover:bg-cta/90"
        >
          {t("compareBar")}
        </Button>
      </div>
    </aside>
  );
}

export default CompareBar;
