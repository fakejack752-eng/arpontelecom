"use client";
// ─── Arpon Telecom — Compare modal (side-by-side spec table) ──────────────────
import { useEffect, useMemo, useState } from "react";
import { X } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { getJSON } from "@/lib/api";
import { useT } from "@/lib/i18n";
import { useStore } from "@/lib/store";
import type { ProductDTO } from "@/lib/types";
import { Price } from "./price";
import { StarRating } from "./star-rating";

// Spec rows matched against specs[].labelEn
const SPEC_LABELS = [
  "Display",
  "Processor",
  "RAM",
  "Storage",
  "Camera",
  "Battery",
] as const;

interface ProductsRes {
  products: ProductDTO[];
  total: number;
  page: number;
  pages: number;
}

function findSpec(p: ProductDTO, labelEn: string) {
  return (p.specs ?? []).find((s) => s.labelEn === labelEn);
}

export function CompareModal() {
  const t = useT();
  const lang = useStore((s) => s.lang);
  const open = useStore((s) => s.compareOpen);
  const setOpen = useStore((s) => s.setCompareOpen);
  const compare = useStore((s) => s.compare);
  const toggleCompare = useStore((s) => s.toggleCompare);
  const addToCart = useStore((s) => s.addToCart);
  const navigate = useStore((s) => s.navigate);

  const idsKey = compare.join(",");
  const [products, setProducts] = useState<ProductDTO[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !idsKey) return;
    let cancelled = false;
    const run = async () => {
      setLoading(true);
      try {
        const d = await getJSON<ProductsRes>(
          `/api/products?ids=${encodeURIComponent(idsKey)}&limit=10`
        );
        if (!cancelled) setProducts(d.products ?? []);
      } catch {
        if (!cancelled) setProducts([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => {
      cancelled = true;
    };
  }, [open, idsKey]);

  // Keep the store's compare order for columns.
  const ordered = useMemo(
    () =>
      compare
        .map((id) => products.find((p) => p.id === id))
        .filter((p): p is ProductDTO => Boolean(p)),
    [compare, products]
  );

  const handleAddToCart = (p: ProductDTO) => {
    addToCart(
      {
        productId: p.id,
        slug: p.slug,
        nameEn: p.nameEn,
        nameBn: p.nameBn,
        price: p.price,
        image: p.images?.[0] ?? "",
        variant: undefined,
      },
      1
    );
    toast.success(t("addedToCart"));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-3xl lg:max-w-5xl">
        <DialogHeader>
          <DialogTitle>{t("compareTitle")}</DialogTitle>
          <DialogDescription className="sr-only">
            {t("compareTitle")}
          </DialogDescription>
        </DialogHeader>

        {compare.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted-foreground">
            {t("compareEmpty")}
          </p>
        ) : loading ? (
          <div className="flex justify-center gap-4 py-8">
            {compare.map((id) => (
              <div key={id} className="flex flex-col items-center gap-3">
                <Skeleton className="h-24 w-24 rounded-lg" />
                <Skeleton className="h-4 w-28" />
                <Skeleton className="h-3 w-20" />
              </div>
            ))}
          </div>
        ) : ordered.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted-foreground">
            {t("compareEmpty")}
          </p>
        ) : (
          <div className="overflow-x-auto pb-1">
            <table
              className="w-full min-w-[560px] border-collapse text-sm"
              aria-label={t("compareTitle")}
            >
              <thead>
                <tr>
                  <th scope="col" className="w-28 min-w-24 p-2 align-bottom" />
                  {ordered.map((p) => {
                    const name = lang === "bn" ? p.nameBn : p.nameEn;
                    const img = p.images?.[0];
                    return (
                      <th
                        key={p.id}
                        scope="col"
                        className="min-w-[170px] p-2 align-top"
                      >
                        <div className="relative mx-auto w-fit">
                          {img ? (
                            <img
                              src={img}
                              alt={name}
                              className="h-24 w-24 rounded-lg border object-cover"
                            />
                          ) : (
                            <div className="flex h-24 w-24 items-center justify-center rounded-lg border bg-muted text-muted-foreground/40">
                              —
                            </div>
                          )}
                          <button
                            type="button"
                            aria-label={`${t("remove_compare")}: ${name}`}
                            onClick={() => toggleCompare(p.id)}
                            className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-cta text-white shadow-sm transition hover:scale-110"
                          >
                            <X className="h-3 w-3" aria-hidden="true" />
                          </button>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setOpen(false);
                            navigate({ name: "product", slug: p.slug });
                          }}
                          className="mt-2 line-clamp-2 text-left text-sm leading-snug font-medium text-foreground transition-colors hover:text-primary"
                        >
                          {name}
                        </button>
                      </th>
                    );
                  })}
                </tr>
              </thead>

              <tbody>
                {/* Price */}
                <tr className="border-t">
                  <th
                    scope="row"
                    className="bg-muted/60 px-3 py-2.5 text-left align-middle text-[11px] font-semibold tracking-wide text-muted-foreground uppercase"
                  >
                    {t("productPrice")}
                  </th>
                  {ordered.map((p) => (
                    <td key={p.id} className="border-t px-3 py-2.5 align-middle">
                      <Price price={p.price} oldPrice={p.oldPrice} size="sm" />
                    </td>
                  ))}
                </tr>

                {/* Rating */}
                <tr>
                  <th
                    scope="row"
                    className="bg-muted/60 px-3 py-2.5 text-left align-middle text-[11px] font-semibold tracking-wide text-muted-foreground uppercase"
                  >
                    {t("reviewsTab")}
                  </th>
                  {ordered.map((p) => (
                    <td key={p.id} className="border-t px-3 py-2.5 align-middle">
                      <StarRating rating={p.rating} count={p.reviewCount} />
                    </td>
                  ))}
                </tr>

                {/* Brand */}
                <tr>
                  <th
                    scope="row"
                    className="bg-muted/60 px-3 py-2.5 text-left align-middle text-[11px] font-semibold tracking-wide text-muted-foreground uppercase"
                  >
                    {t("productBrand")}
                  </th>
                  {ordered.map((p) => (
                    <td key={p.id} className="border-t px-3 py-2.5 align-middle font-medium">
                      {p.brand}
                    </td>
                  ))}
                </tr>

                {/* Spec rows */}
                {SPEC_LABELS.map((labelEn) => {
                  // Localized row label: take from the first product that has the spec.
                  const anySpec = ordered
                    .map((p) => findSpec(p, labelEn))
                    .find(Boolean);
                  const rowLabel = anySpec
                    ? lang === "bn"
                      ? anySpec.labelBn || anySpec.labelEn
                      : anySpec.labelEn
                    : labelEn;
                  return (
                    <tr key={labelEn}>
                      <th
                        scope="row"
                        className="bg-muted/60 px-3 py-2.5 text-left align-middle text-[11px] font-semibold tracking-wide text-muted-foreground uppercase"
                      >
                        {rowLabel}
                      </th>
                      {ordered.map((p) => {
                        const s = findSpec(p, labelEn);
                        const value = s
                          ? (lang === "bn" ? s.valueBn || s.valueEn : s.valueEn) || "—"
                          : "—";
                        return (
                          <td
                            key={p.id}
                            className="border-t px-3 py-2.5 align-middle text-muted-foreground"
                          >
                            {value}
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>

              {/* Footer: per-column Add to Cart */}
              <tfoot>
                <tr>
                  <td className="p-2" />
                  {ordered.map((p) => (
                    <td key={p.id} className="p-2 align-top">
                      <Button
                        size="sm"
                        disabled={p.stockStatus === "out_of_stock"}
                        onClick={() => handleAddToCart(p)}
                        className="h-8 w-full bg-cta text-xs text-cta-foreground hover:bg-cta/90"
                      >
                        {t("addToCart")}
                      </Button>
                    </td>
                  ))}
                </tr>
              </tfoot>
            </table>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default CompareModal;
