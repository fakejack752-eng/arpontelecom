// ─── Formatting helpers ──────────────────────────────────────────────────────
export function formatBDT(n: number): string {
  return "৳" + Math.round(n).toLocaleString("en-IN");
}

export function discountPercent(price: number, oldPrice?: number | null): number | null {
  if (!oldPrice || oldPrice <= price) return null;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}

export function formatDate(iso: string, lang: "en" | "bn" = "en"): string {
  const d = new Date(iso);
  const locale = lang === "bn" ? "bn-BD" : "en-GB";
  return d.toLocaleDateString(locale, {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

export function isValidBDPhone(phone: string): boolean {
  return /^01[3-9]\d{8}$/.test(phone.trim());
}

export function firstImage(images: string[] | string): string {
  if (Array.isArray(images)) return images[0] ?? "";
  try {
    const parsed = JSON.parse(images);
    return Array.isArray(parsed) ? parsed[0] ?? "" : "";
  } catch {
    return "";
  }
}

export function parseJson<T>(value: string | T | null | undefined, fallback: T): T {
  if (!value) return fallback;
  if (typeof value !== "string") return value;
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

export function cnPrice(n: number): string {
  return "৳" + n.toLocaleString("bn-BD");
}
