"use client";
// ─── Arpon Telecom — global client store (Zustand + localStorage persist) ────
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { CartItem, DeliveryZone, PaymentMethod } from "@/lib/types";

export type PageSlug =
  | "about"
  | "contact"
  | "faq"
  | "warranty"
  | "privacy"
  | "terms";

export type View =
  | { name: "home" }
  | { name: "shop"; category?: string; brand?: string; search?: string }
  | { name: "product"; slug: string }
  | { name: "wishlist" }
  | { name: "checkout" }
  | { name: "tracking" }
  | { name: "admin" }
  | { name: "recharge" }
  | { name: "page"; slug: PageSlug }
  | { name: "blog" }
  | { name: "blogPost"; slug: string };

export interface CompareToggleResult {
  status: "added" | "removed" | "full";
  items: string[];
}

interface StoreState {
  lang: "en" | "bn";
  setLang: (l: "en" | "bn") => void;
  toggleLang: () => void;

  view: View;
  navigate: (v: View) => void;

  cart: CartItem[];
  addToCart: (item: Omit<CartItem, "qty">, qty?: number) => void;
  removeFromCart: (productId: string, variant?: string) => void;
  setQty: (productId: string, variant: string | undefined, qty: number) => void;
  clearCart: () => void;
  cartOpen: boolean;
  setCartOpen: (open: boolean) => void;

  wishlist: string[];
  toggleWishlist: (id: string) => void;

  compare: string[];
  toggleCompare: (id: string) => CompareToggleResult;
  clearCompare: () => void;
  compareOpen: boolean;
  setCompareOpen: (open: boolean) => void;

  lastOrder: { orderNumber: string; phone: string } | null;
  setLastOrder: (o: { orderNumber: string; phone: string } | null) => void;

  adminAuthed: boolean;
  setAdminAuthed: (v: boolean) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      lang: "en",
      setLang: (l) => set({ lang: l }),
      toggleLang: () => set((s) => ({ lang: s.lang === "en" ? "bn" : "en" })),

      view: { name: "home" },
      navigate: (v) => {
        set({ view: v });
        if (typeof window !== "undefined") {
          window.scrollTo({ top: 0, behavior: "instant" as ScrollBehavior });
        }
      },

      cart: [],
      addToCart: (item, qty = 1) =>
        set((s) => {
          const idx = s.cart.findIndex(
            (c) => c.productId === item.productId && c.variant === item.variant
          );
          const cart = [...s.cart];
          if (idx >= 0) {
            cart[idx] = { ...cart[idx], qty: cart[idx].qty + qty };
          } else {
            cart.push({ ...item, qty });
          }
          return { cart };
        }),
      removeFromCart: (productId, variant) =>
        set((s) => ({
          cart: s.cart.filter(
            (c) => !(c.productId === productId && c.variant === variant)
          ),
        })),
      setQty: (productId, variant, qty) =>
        set((s) => ({
          cart: s.cart
            .map((c) =>
              c.productId === productId && c.variant === variant
                ? { ...c, qty: Math.max(0, qty) }
                : c
            )
            .filter((c) => c.qty > 0),
        })),
      clearCart: () => set({ cart: [] }),
      cartOpen: false,
      setCartOpen: (open) => set({ cartOpen: open }),

      wishlist: [],
      toggleWishlist: (id) =>
        set((s) => ({
          wishlist: s.wishlist.includes(id)
            ? s.wishlist.filter((w) => w !== id)
            : [...s.wishlist, id],
        })),

      compare: [],
      toggleCompare: (id) => {
        const cur = get().compare;
        if (cur.includes(id)) {
          const items = cur.filter((c) => c !== id);
          set({ compare: items });
          return { status: "removed" as const, items };
        }
        if (cur.length >= 3) {
          return { status: "full" as const, items: cur };
        }
        const items = [...cur, id];
        set({ compare: items });
        return { status: "added" as const, items };
      },
      clearCompare: () => set({ compare: [] }),
      compareOpen: false,
      setCompareOpen: (open) => set({ compareOpen: open }),

      lastOrder: null,
      setLastOrder: (o) => set({ lastOrder: o }),

      adminAuthed: false,
      setAdminAuthed: (v) => set({ adminAuthed: v }),
    }),
    {
      name: "arpon-telecom-store",
      storage: createJSONStorage(() => localStorage),
      partialize: (s) => ({
        lang: s.lang,
        cart: s.cart,
        wishlist: s.wishlist,
        compare: s.compare,
        lastOrder: s.lastOrder,
      }),
    }
  )
);

// ─── Derived selectors ───────────────────────────────────────────────────────
export const useCartCount = () => useStore((s) => s.cart.reduce((n, i) => n + i.qty, 0));
export const useCartSubtotal = () =>
  useStore((s) => s.cart.reduce((n, i) => n + i.qty * i.price, 0));
export const useWishlistCount = () => useStore((s) => s.wishlist.length);

export const WHATSAPP_NUMBER = "8801712345678";
export const HOTLINE_NUMBER = "01712-345678";
