// ─── Arpon Telecom — shared type contracts ─────────────────────────────────
// Every view/component must type against these DTOs.

export type StockStatus = "in_stock" | "out_of_stock" | "pre_order";
export type PaymentMethod = "cod" | "bkash" | "nagad" | "rocket" | "card";
export type DeliveryZone = "inside_dhaka" | "outside_dhaka";
export type OrderStatus = "pending" | "confirmed" | "shipped" | "delivered" | "cancelled";

export interface Spec {
  labelEn: string;
  labelBn: string;
  valueEn: string;
  valueBn: string;
}

export interface VariantGroup {
  nameEn: string; // "Color"
  nameBn: string; // "রঙ"
  type: "color" | "storage";
  options: string[]; // ["Black", "Blue"] or ["4/64GB", "6/128GB"]
}

export interface Review {
  id: string;
  name: string;
  rating: number; // 1..5
  comment: string;
  createdAt: string;
}

export interface CategoryDTO {
  id: string;
  slug: string;
  nameEn: string;
  nameBn: string;
  icon: string; // lucide icon key, e.g. "Smartphone"
}

export interface ProductDTO {
  id: string;
  slug: string;
  nameEn: string;
  nameBn: string;
  brand: string;
  categoryId: string;
  categorySlug: string;
  categoryNameEn: string;
  categoryNameBn: string;
  price: number;
  oldPrice: number | null;
  stock: number;
  stockStatus: StockStatus;
  images: string[];
  specs: Spec[];
  variants: VariantGroup[];
  ram: string | null;
  storage: string | null;
  rating: number;
  reviewCount: number;
  isFlash: boolean;
  flashEndsAt: string | null;
  isNew: boolean;
  isBestSeller: boolean;
  warrantyEn: string;
  warrantyBn: string;
  descriptionEn: string;
  descriptionBn: string;
  soldCount: number;
  createdAt: string;
}

export interface ProductDetailDTO extends ProductDTO {
  reviews: Review[];
  related: ProductDTO[];
}

export interface CartItem {
  productId: string;
  slug: string;
  nameEn: string;
  nameBn: string;
  price: number;
  image: string;
  qty: number;
  variant?: string; // e.g. "Black · 8/128GB"
}

export interface OrderCustomer {
  name: string;
  phone: string;
  division: string;
  district: string;
  upazila: string;
  address: string;
}

export interface CreateOrderPayload {
  customer: OrderCustomer;
  items: { productId: string; qty: number; variant?: string }[];
  paymentMethod: PaymentMethod;
  deliveryZone: DeliveryZone;
  couponCode?: string;
  notes?: string;
}

export interface OrderItemDTO {
  id: string;
  productId: string;
  nameEn: string;
  nameBn: string;
  price: number;
  qty: number;
  variant?: string | null;
}

export interface OrderDTO {
  id: string;
  orderNumber: string;
  customerName: string;
  phone: string;
  division: string;
  district: string;
  upazila: string;
  address: string;
  status: OrderStatus;
  deliveryZone: DeliveryZone;
  deliveryFee: number;
  paymentMethod: PaymentMethod;
  couponCode: string | null;
  discount: number;
  subtotal: number;
  total: number;
  notes?: string | null;
  createdAt: string;
  items: OrderItemDTO[];
}

export interface CouponDTO {
  id: string;
  code: string;
  type: "percent" | "fixed";
  value: number;
  minSubtotal: number | null;
  active: boolean;
}

export const DELIVERY_FEES: Record<DeliveryZone, number> = {
  inside_dhaka: 60,
  outside_dhaka: 120,
};

export const PRODUCT_SORTS = [
  "new",
  "price_asc",
  "price_desc",
  "popular",
  "rating",
] as const;
export type ProductSort = (typeof PRODUCT_SORTS)[number];
