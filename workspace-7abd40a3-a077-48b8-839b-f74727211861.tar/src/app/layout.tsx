import type { Metadata, Viewport } from "next";
import { Inter, Hind_Siliguri } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const hind = Hind_Siliguri({
  variable: "--font-hind",
  subsets: ["bengali", "latin"],
  weight: ["300", "400", "500", "600", "700"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Arpon Telecom — Mobile & Gadget Shop in Bangladesh | আরপন টেলিকম",
  description:
    "Buy genuine smartphones, feature phones, tablets & accessories with official warranty. Cash on Delivery across Bangladesh. আরপন টেলিকম — অফিসিয়াল ওয়ারেন্টিসহ জেনুইন ফোন ও গ্যাজেট।",
  keywords: [
    "Arpon Telecom",
    "mobile shop bangladesh",
    "smartphone price in bangladesh",
    "arpontelecom.store",
    "ফোন কিনুন",
    "মোবাইল দোকান",
  ],
  openGraph: {
    title: "Arpon Telecom — Genuine Mobile & Gadget Shop",
    description:
      "Official warranty phones, accessories & SIM recharge. Delivery all over Bangladesh.",
    url: "https://arpontelecom.store",
    siteName: "Arpon Telecom",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Arpon Telecom — Mobile & Gadget Shop",
    description: "Genuine phones & accessories with official warranty. COD nationwide.",
  },
};

export const viewport: Viewport = {
  themeColor: "#0B3D91",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${hind.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster position="top-center" richColors closeButton />
      </body>
    </html>
  );
}
