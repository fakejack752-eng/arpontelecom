"use client";

import { motion } from "framer-motion";

import { useStore } from "@/lib/store";
import Header from "@/components/store/header";
import Footer from "@/components/store/footer";
import FloatingButtons from "@/components/store/floating-buttons";
import CartDrawer from "@/components/store/cart-drawer";
import CompareBar from "@/components/store/compare-bar";
import CompareModal from "@/components/store/compare-modal";
import HomeView from "@/components/store/views/home-view";
import ShopView from "@/components/store/views/shop-view";
import ProductDetailView from "@/components/store/views/product-detail-view";
import WishlistView from "@/components/store/views/wishlist-view";
import CheckoutView from "@/components/store/views/checkout-view";
import TrackingView from "@/components/store/views/tracking-view";
import AdminView from "@/components/store/views/admin-view";
import RechargeView from "@/components/store/views/recharge-view";
import StaticPageView from "@/components/store/views/static-page-view";
import BlogView from "@/components/store/views/blog-view";

function CurrentView() {
  const view = useStore((s) => s.view);
  // Keyed remount gives every view/navigation change a soft fade-up.
  return (
    <motion.div
      key={JSON.stringify(view)}
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.32, ease: "easeOut" }}
    >
      <ViewSwitch view={view} />
    </motion.div>
  );
}

function ViewSwitch({
  view,
}: {
  view: ReturnType<typeof useStore.getState>["view"];
}) {
  switch (view.name) {
    case "shop":
      return <ShopView />;
    case "product":
      return <ProductDetailView />;
    case "wishlist":
      return <WishlistView />;
    case "checkout":
      return <CheckoutView />;
    case "tracking":
      return <TrackingView />;
    case "admin":
      return <AdminView />;
    case "recharge":
      return <RechargeView />;
    case "page":
      return <StaticPageView />;
    case "blog":
    case "blogPost":
      return <BlogView />;
    default:
      return <HomeView />;
  }
}

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <main className="flex-1">
        <CurrentView />
      </main>
      <Footer />
      <FloatingButtons />
      <CartDrawer />
      <CompareBar />
      <CompareModal />
    </div>
  );
}
