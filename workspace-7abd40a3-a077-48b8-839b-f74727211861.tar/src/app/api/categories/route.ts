import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/categories → { categories: CategoryDTO[] } (ordered)
export async function GET() {
  const categories = await db.category.findMany({
    orderBy: { order: "asc" },
  });
  return NextResponse.json({ categories });
}
