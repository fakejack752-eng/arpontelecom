import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

// GET /api/search?q= → { suggestions: [{id, slug, nameEn, nameBn, price, image}] }
export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get("q") || "").trim().toLowerCase();
  if (!q) return NextResponse.json({ suggestions: [] });

  const rows = await db.product.findMany({
    orderBy: { soldCount: "desc" },
  });

  const suggestions = rows
    .filter(
      (p) =>
        p.nameEn.toLowerCase().includes(q) ||
        p.nameBn.includes(q) || // Bengali has no case
        p.brand.toLowerCase().includes(q),
    )
    .slice(0, 8)
    .map((p) => {
      let images: string[] = [];
      try {
        images = JSON.parse(p.images);
      } catch {
        images = [];
      }
      return {
        id: p.id,
        slug: p.slug,
        nameEn: p.nameEn,
        nameBn: p.nameBn,
        price: p.price,
        image: images[0] ?? null,
      };
    });

  return NextResponse.json({ suggestions });
}
