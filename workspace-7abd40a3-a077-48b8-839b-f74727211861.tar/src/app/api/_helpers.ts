// ─── Arpon Telecom — API shared helpers (serialization + admin guard) ───────
import { NextResponse } from "next/server";
import type {
  Category,
  Coupon,
  Order,
  OrderItem,
  Product,
  Review as ReviewRow,
} from "@prisma/client";
import type { CouponDTO, OrderDTO, ProductDTO, Review } from "@/lib/types";

export const ADMIN_PASSCODE = "arpon2024";

/** Check the `x-admin-passcode` header. */
export function isAdmin(req: Request): boolean {
  return req.headers.get("x-admin-passcode") === ADMIN_PASSCODE;
}

export function unauthorized() {
  return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
}

export function badRequest(message: string, extra?: Record<string, unknown>) {
  return NextResponse.json({ error: message, ...extra }, { status: 400 });
}

// ── row → DTO mappers (JSON strings parsed, dates ISO) ──────────────────────

function parseJSON<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function toProductDTO(
  p: Product & { category: Category },
): ProductDTO {
  return {
    id: p.id,
    slug: p.slug,
    nameEn: p.nameEn,
    nameBn: p.nameBn,
    brand: p.brand,
    categoryId: p.categoryId,
    categorySlug: p.category.slug,
    categoryNameEn: p.category.nameEn,
    categoryNameBn: p.category.nameBn,
    price: p.price,
    oldPrice: p.oldPrice ?? null,
    stock: p.stock,
    stockStatus: p.stockStatus as ProductDTO["stockStatus"],
    images: parseJSON<string[]>(p.images, []),
    specs: parseJSON<ProductDTO["specs"]>(p.specs, []),
    variants: parseJSON<ProductDTO["variants"]>(p.variants, []),
    ram: p.ram,
    storage: p.storage,
    rating: p.rating,
    reviewCount: p.reviewCount,
    isFlash: p.isFlash,
    flashEndsAt: p.flashEndsAt ? p.flashEndsAt.toISOString() : null,
    isNew: p.isNew,
    isBestSeller: p.isBestSeller,
    warrantyEn: p.warrantyEn,
    warrantyBn: p.warrantyBn,
    descriptionEn: p.descriptionEn,
    descriptionBn: p.descriptionBn,
    soldCount: p.soldCount,
    createdAt: p.createdAt.toISOString(),
  };
}

export function toOrderDTO(o: Order & { items: OrderItem[] }): OrderDTO {
  return {
    id: o.id,
    orderNumber: o.orderNumber,
    customerName: o.customerName,
    phone: o.phone,
    division: o.division,
    district: o.district,
    upazila: o.upazila,
    address: o.address,
    status: o.status as OrderDTO["status"],
    deliveryZone: o.deliveryZone as OrderDTO["deliveryZone"],
    deliveryFee: o.deliveryFee,
    paymentMethod: o.paymentMethod as OrderDTO["paymentMethod"],
    couponCode: o.couponCode ?? null,
    discount: o.discount,
    subtotal: o.subtotal,
    total: o.total,
    notes: o.notes ?? null,
    createdAt: o.createdAt.toISOString(),
    items: o.items.map((it) => ({
      id: it.id,
      productId: it.productId,
      nameEn: it.nameEn,
      nameBn: it.nameBn,
      price: it.price,
      qty: it.qty,
      variant: it.variant ?? null,
    })),
  };
}

export function toReviewDTO(r: ReviewRow): Review {
  return {
    id: r.id,
    name: r.name,
    rating: r.rating,
    comment: r.comment,
    createdAt: r.createdAt.toISOString(),
  };
}

export function toCouponDTO(c: Coupon): CouponDTO {
  return {
    id: c.id,
    code: c.code,
    type: c.type as CouponDTO["type"],
    value: c.value,
    minSubtotal: c.minSubtotal ?? null,
    active: c.active,
  };
}

/** Store a JSON-typed column from an unknown input (array | string | undefined). */
export function jsonify(
  value: unknown,
  fallback: unknown[] = [],
): string {
  if (Array.isArray(value)) return JSON.stringify(value);
  if (typeof value === "string" && value.length > 0) return value;
  return JSON.stringify(fallback);
}

/** Compute a coupon's discount against a subtotal (never exceeds subtotal). */
export function computeDiscount(
  type: string,
  value: number,
  subtotal: number,
): number {
  const raw = type === "percent" ? (subtotal * value) / 100 : value;
  return Math.max(0, Math.min(Math.round(raw), Math.round(subtotal)));
}
