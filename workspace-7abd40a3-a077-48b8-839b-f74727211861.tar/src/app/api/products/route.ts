import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toProductDTO } from "../_helpers";
import type { Prisma } from "@prisma/client";

export const dynamic = "force-dynamic";

// GET /api/products — full filter/sort/paginate contract (see worklog.md)
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const category = sp.get("category") || undefined;
  const brandParam = sp.get("brand");
  const min = sp.get("min");
  const max = sp.get("max");
  const ramParam = sp.get("ram");
  const storageParam = sp.get("storage");
  const rating = sp.get("rating");
  const stockParam = sp.get("stock");
  const flag = sp.get("flag");
  const q = sp.get("q");
  const idsParam = sp.get("ids");
  const sort = sp.get("sort") || "new";
  const page = Math.max(1, parseInt(sp.get("page") || "1", 10) || 1);
  const limit = Math.min(
    100,
    Math.max(1, parseInt(sp.get("limit") || "12", 10) || 12),
  );

  const num = (v: string | null) => {
    if (v === null || v.trim() === "") return undefined;
    const n = Number(v);
    return Number.isFinite(n) ? n : undefined;
  };
  const list = (v: string | null) =>
    v
      ? v
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean)
      : [];

  // DB-level filters (SQLite-safe)
  const where: Prisma.ProductWhereInput = {};
  if (category) where.category = { slug: category };
  const minN = num(min);
  const maxN = num(max);
  if (minN !== undefined || maxN !== undefined) {
    where.price = {
      ...(minN !== undefined ? { gte: minN } : {}),
      ...(maxN !== undefined ? { lte: maxN } : {}),
    };
  }
  const ratingN = num(rating);
  if (ratingN !== undefined) where.rating = { gte: ratingN };
  const stockList = list(stockParam);
  if (stockList.length) where.stockStatus = { in: stockList };
  if (flag === "flash") where.isFlash = true;
  else if (flag === "new") where.isNew = true;
  else if (flag === "best") where.isBestSeller = true;
  const idList = list(idsParam);
  if (idList.length) where.id = { in: idList };

  // Fetch (dataset is small; case-insensitive + multilingual filtering done in JS)
  const rows = await db.product.findMany({
    where,
    include: { category: true },
  });

  let filtered = rows;

  const brandList = list(brandParam).map((b) => b.toLowerCase());
  if (brandList.length) {
    filtered = filtered.filter((p) =>
      brandList.includes(p.brand.toLowerCase()),
    );
  }

  const ramList = list(ramParam).map((r) => r.toLowerCase());
  if (ramList.length) {
    filtered = filtered.filter(
      (p) => p.ram !== null && ramList.includes(p.ram.toLowerCase()),
    );
  }

  const storageList = list(storageParam).map((s) => s.toLowerCase());
  if (storageList.length) {
    filtered = filtered.filter(
      (p) => p.storage !== null && storageList.includes(p.storage.toLowerCase()),
    );
  }

  const query = (q || "").trim().toLowerCase();
  if (query) {
    filtered = filtered.filter(
      (p) =>
        p.nameEn.toLowerCase().includes(query) ||
        p.nameBn.includes(query) || // Bengali has no case
        p.brand.toLowerCase().includes(query),
    );
  }

  // sort
  const sorted = [...filtered];
  switch (sort) {
    case "price_asc":
      sorted.sort((a, b) => a.price - b.price);
      break;
    case "price_desc":
      sorted.sort((a, b) => b.price - a.price);
      break;
    case "popular":
      sorted.sort((a, b) => b.soldCount - a.soldCount);
      break;
    case "rating":
      sorted.sort((a, b) => b.rating - a.rating);
      break;
    case "new":
    default:
      sorted.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
      break;
  }

  const total = sorted.length;
  const pages = Math.ceil(total / limit);
  const paged = sorted.slice((page - 1) * limit, page * limit);

  return NextResponse.json({
    products: paged.map(toProductDTO),
    total,
    page,
    pages,
  });
}
