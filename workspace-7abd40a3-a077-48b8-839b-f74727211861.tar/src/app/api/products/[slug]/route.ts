import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toProductDTO, toReviewDTO } from "../../_helpers";

export const dynamic = "force-dynamic";

// GET /api/products/[slug] — accepts slug OR id; returns product + reviews + related
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  const { slug } = await params;
  const key = decodeURIComponent(slug);

  const product = await db.product.findFirst({
    where: { OR: [{ slug: key }, { id: key }] },
    include: { category: true },
  });
  if (!product) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  const [reviews, related] = await Promise.all([
    db.review.findMany({
      where: { productId: product.id },
      orderBy: { createdAt: "desc" },
    }),
    db.product.findMany({
      where: { categoryId: product.categoryId, id: { not: product.id } },
      include: { category: true },
      orderBy: { soldCount: "desc" },
      take: 4,
    }),
  ]);

  return NextResponse.json({
    product: {
      ...toProductDTO(product),
      reviews: reviews.map(toReviewDTO),
      related: related.map(toProductDTO),
    },
  });
}
