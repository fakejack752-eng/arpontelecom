import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

const contactSchema = z.object({
  name: z.string().min(2, "Name is required"),
  phone: z.string().min(6, "Valid phone number is required"),
  email: z.string().optional().nullable(),
  message: z.string().min(3, "Message is required"),
});

// POST /api/contact { name, phone, email?, message } → { ok: true }
export async function POST(req: NextRequest) {
  const parsed = contactSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      {
        ok: false,
        error: "Invalid contact payload",
        details: parsed.error.issues[0]?.message ?? "Validation failed",
      },
      { status: 400 },
    );
  }

  await db.contactMessage.create({
    data: {
      name: parsed.data.name,
      phone: parsed.data.phone,
      email: parsed.data.email?.trim() || null,
      message: parsed.data.message,
    },
  });

  return NextResponse.json({ ok: true });
}
