import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toOrderDTO } from "../../_helpers";

export const dynamic = "force-dynamic";

// GET /api/orders/track?phone=&orderNumber= → { order } | 404 { error }
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const phone = (sp.get("phone") || "").trim();
  const orderNumber = (sp.get("orderNumber") || "").trim();

  if (!phone || !orderNumber) {
    return NextResponse.json(
      { error: "Both phone and orderNumber are required" },
      { status: 400 },
    );
  }

  // orderNumber stored uppercase → match case-insensitively
  const order = await db.order.findFirst({
    where: { phone, orderNumber: orderNumber.toUpperCase() },
    include: { items: true },
  });

  if (!order) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  return NextResponse.json({ order: toOrderDTO(order) });
}
