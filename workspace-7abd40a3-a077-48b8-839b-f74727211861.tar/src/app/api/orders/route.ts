import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { toOrderDTO } from "../_helpers";

export const dynamic = "force-dynamic";

const orderSchema = z.object({
  customer: z.object({
    name: z.string().min(2, "Name is required"),
    phone: z.string().min(6, "Valid phone number is required"),
    division: z.string().min(1, "Division is required"),
    district: z.string().min(1, "District is required"),
    upazila: z.string().min(1, "Upazila is required"),
    address: z.string().min(3, "Address is required"),
  }),
  items: z
    .array(
      z.object({
        productId: z.string().min(1),
        qty: z.number().int().positive().max(99),
        variant: z.string().optional().nullable(),
      }),
    )
    .min(1, "Order must contain at least one item"),
  paymentMethod: z.enum(["cod", "bkash", "nagad", "rocket", "card"]),
  deliveryZone: z.enum(["inside_dhaka", "outside_dhaka"]),
  couponCode: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

const CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
const rand4 = () =>
  Array.from(
    { length: 4 },
    () => CHARS[Math.floor(Math.random() * CHARS.length)],
  ).join("");

function makeOrderNumber(): string {
  const now = new Date();
  const yy = String(now.getFullYear()).slice(2);
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  return `APT${yy}${mm}${dd}${rand4()}`;
}

// POST /api/orders — server-priced checkout (client prices are never trusted)
export async function POST(req: NextRequest) {
  const parsed = orderSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Invalid order payload",
        details: parsed.error.issues[0]?.message ?? "Validation failed",
      },
      { status: 400 },
    );
  }
  const data = parsed.data;

  // merge duplicate line items
  const qtyByProduct = new Map<string, number>();
  const firstVariant = new Map<string, string | null>();
  for (const it of data.items) {
    qtyByProduct.set(it.productId, (qtyByProduct.get(it.productId) ?? 0) + it.qty);
    if (!firstVariant.has(it.productId)) {
      firstVariant.set(it.productId, it.variant ?? null);
    }
  }

  // re-fetch prices/stock from DB — never trust the client
  const productIds = [...qtyByProduct.keys()];
  const products = await db.product.findMany({
    where: { id: { in: productIds } },
  });
  if (products.length !== productIds.length) {
    return NextResponse.json(
      { error: "One or more products no longer exist" },
      { status: 400 },
    );
  }

  for (const p of products) {
    const qty = qtyByProduct.get(p.id)!;
    if (p.stockStatus !== "pre_order" && p.stock < qty) {
      return NextResponse.json(
        { error: `Insufficient stock for ${p.nameEn}` },
        { status: 400 },
      );
    }
  }

  const subtotal = products.reduce(
    (sum, p) => sum + p.price * qtyByProduct.get(p.id)!,
    0,
  );

  // coupon (validated server-side against DB)
  let discount = 0;
  let couponCode: string | null = null;
  const wantedCoupon = data.couponCode?.trim();
  if (wantedCoupon) {
    const coupons = await db.coupon.findMany();
    const coupon = coupons.find(
      (c) =>
        c.active &&
        c.code.toLowerCase() === wantedCoupon.toLowerCase() &&
        (!c.minSubtotal || subtotal >= c.minSubtotal),
    );
    if (coupon) {
      discount =
        coupon.type === "percent"
          ? Math.round((subtotal * coupon.value) / 100)
          : coupon.value;
      discount = Math.max(0, Math.min(discount, Math.round(subtotal)));
      couponCode = coupon.code;
    }
  }

  const deliveryFee = data.deliveryZone === "inside_dhaka" ? 60 : 120;
  const total = Math.max(0, subtotal - discount) + deliveryFee;

  // unique order number ("APT" + YYMMDD + 4 random uppercase alphanumerics)
  let orderNumber = makeOrderNumber();
  for (let i = 0; i < 10; i++) {
    const exists = await db.order.findUnique({
      where: { orderNumber },
    });
    if (!exists) break;
    orderNumber = makeOrderNumber();
  }

  const order = await db.$transaction(async (tx) => {
    const created = await tx.order.create({
      data: {
        orderNumber,
        customerName: data.customer.name,
        phone: data.customer.phone,
        division: data.customer.division,
        district: data.customer.district,
        upazila: data.customer.upazila,
        address: data.customer.address,
        status: "pending",
        deliveryZone: data.deliveryZone,
        deliveryFee,
        paymentMethod: data.paymentMethod,
        couponCode,
        discount,
        subtotal,
        total,
        notes: data.notes ?? null,
        items: {
          create: data.items.map((it) => ({
            productId: it.productId,
            nameEn: products.find((p) => p.id === it.productId)!.nameEn,
            nameBn: products.find((p) => p.id === it.productId)!.nameBn,
            price: products.find((p) => p.id === it.productId)!.price,
            qty: it.qty,
            variant: firstVariant.get(it.productId) ?? null,
          })),
        },
      },
      include: { items: true },
    });

    for (const p of products) {
      const qty = qtyByProduct.get(p.id)!;
      // pre-order items don't decrement physical stock
      if (p.stockStatus === "pre_order") {
        await tx.product.update({
          where: { id: p.id },
          data: { soldCount: { increment: qty } },
        });
      } else {
        await tx.product.update({
          where: { id: p.id },
          data: {
            stock: { decrement: qty },
            soldCount: { increment: qty },
          },
        });
      }
    }

    return created;
  });

  return NextResponse.json({ order: toOrderDTO(order) }, { status: 201 });
}
