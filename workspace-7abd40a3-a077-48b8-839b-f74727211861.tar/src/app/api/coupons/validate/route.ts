import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { computeDiscount } from "../../_helpers";

export const dynamic = "force-dynamic";

// POST /api/coupons/validate { code, subtotal } → { ok, discount, message }
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const code = String(body?.code ?? "").trim();
  const subtotal = Number(body?.subtotal);

  if (!code || !Number.isFinite(subtotal) || subtotal < 0) {
    return NextResponse.json(
      { ok: false, discount: 0, message: "Invalid coupon request" },
      { status: 400 },
    );
  }

  const coupons = await db.coupon.findMany();
  const coupon = coupons.find(
    (c) => c.code.toLowerCase() === code.toLowerCase(),
  );

  if (!coupon || !coupon.active) {
    return NextResponse.json({
      ok: false,
      discount: 0,
      message: "Invalid or inactive coupon code",
    });
  }

  if (coupon.minSubtotal && subtotal < coupon.minSubtotal) {
    return NextResponse.json({
      ok: false,
      discount: 0,
      message: `This coupon requires a minimum order of ৳${coupon.minSubtotal}`,
    });
  }

  const discount = computeDiscount(coupon.type, coupon.value, subtotal);
  return NextResponse.json({
    ok: true,
    discount,
    message: `Coupon ${coupon.code} applied — you saved ৳${discount}!`,
  });
}
