import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin, toOrderDTO, unauthorized } from "../../../_helpers";

export const dynamic = "force-dynamic";

const STATUSES = ["pending", "confirmed", "shipped", "delivered", "cancelled"];

// PUT /api/admin/orders/[id] { status } → { order }
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!isAdmin(req)) return unauthorized();

  const { id } = await params;
  const body = await req.json().catch(() => null);
  const status = String(body?.status ?? "");

  if (!STATUSES.includes(status)) {
    return NextResponse.json(
      { error: `status must be one of: ${STATUSES.join(", ")}` },
      { status: 400 },
    );
  }

  const existing = await db.order.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json({ error: "Order not found" }, { status: 404 });
  }

  const order = await db.order.update({
    where: { id },
    data: { status },
    include: { items: true },
  });

  return NextResponse.json({ order: toOrderDTO(order) });
}
