import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin, toOrderDTO, unauthorized } from "../../_helpers";

export const dynamic = "force-dynamic";

// GET /api/admin/orders?status= (header x-admin-passcode)
export async function GET(req: NextRequest) {
  if (!isAdmin(req)) return unauthorized();

  const status = req.nextUrl.searchParams.get("status");
  const orders = await db.order.findMany({
    where: status ? { status } : undefined,
    include: { items: true },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ orders: orders.map(toOrderDTO) });
}
