import { NextRequest, NextResponse } from "next/server";
import { ADMIN_PASSCODE } from "../../_helpers";

export const dynamic = "force-dynamic";

// POST /api/admin/login { passcode } → { ok: true } | 401
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (body?.passcode === ADMIN_PASSCODE) {
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json(
    { ok: false, error: "Invalid passcode" },
    { status: 401 },
  );
}
