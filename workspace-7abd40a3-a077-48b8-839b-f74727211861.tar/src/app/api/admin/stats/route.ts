import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin, toOrderDTO, unauthorized } from "../../_helpers";

export const dynamic = "force-dynamic";

// GET /api/admin/stats (header x-admin-passcode)
export async function GET(req: NextRequest) {
  if (!isAdmin(req)) return unauthorized();

  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const notCancelled = { status: { not: "cancelled" } };

  const [todayAgg, monthAgg, totalOrders, pendingOrders, totalProducts] =
    await Promise.all([
      db.order.aggregate({
        _sum: { total: true },
        where: { createdAt: { gte: startOfToday }, ...notCancelled },
      }),
      db.order.aggregate({
        _sum: { total: true },
        where: { createdAt: { gte: startOfMonth }, ...notCancelled },
      }),
      db.order.count(),
      db.order.count({ where: { status: "pending" } }),
      db.product.count(),
    ]);

  const [lowStock, recentOrders, topProducts] = await Promise.all([
    db.product.findMany({
      where: { stock: { lte: 5 } },
      select: { id: true, nameEn: true, stock: true },
      orderBy: { stock: "asc" },
      take: 8,
    }),
    db.order.findMany({
      include: { items: true },
      orderBy: { createdAt: "desc" },
      take: 8,
    }),
    db.product.findMany({
      orderBy: { soldCount: "desc" },
      take: 5,
      select: { nameEn: true, soldCount: true },
    }),
  ]);

  return NextResponse.json({
    todayRevenue: todayAgg._sum.total ?? 0,
    monthRevenue: monthAgg._sum.total ?? 0,
    totalOrders,
    pendingOrders,
    totalProducts,
    lowStock,
    recentOrders: recentOrders.map(toOrderDTO),
    topProducts,
  });
}
