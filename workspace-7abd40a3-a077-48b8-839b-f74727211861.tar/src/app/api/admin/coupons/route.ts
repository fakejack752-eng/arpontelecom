import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { isAdmin, toCouponDTO, unauthorized } from "../../_helpers";

export const dynamic = "force-dynamic";

// GET /api/admin/coupons (header x-admin-passcode) → { coupons: CouponDTO[] }
export async function GET(req: NextRequest) {
  if (!isAdmin(req)) return unauthorized();

  const coupons = await db.coupon.findMany({
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ coupons: coupons.map(toCouponDTO) });
}

const couponSchema = z.object({
  code: z.string().min(2, "Code is required"),
  type: z.enum(["percent", "fixed"]),
  value: z.number().positive("Value must be positive"),
  minSubtotal: z.number().positive().optional().nullable(),
});

// POST /api/admin/coupons { code, type, value, minSubtotal? } → { coupon }
export async function POST(req: NextRequest) {
  if (!isAdmin(req)) return unauthorized();

  const parsed = couponSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Invalid coupon payload",
        details: parsed.error.issues[0]?.message ?? "Validation failed",
      },
      { status: 400 },
    );
  }

  const code = parsed.data.code.trim().toUpperCase();
  const existing = await db.coupon.findUnique({ where: { code } });
  if (existing) {
    return NextResponse.json(
      { error: "A coupon with this code already exists" },
      { status: 409 },
    );
  }

  const coupon = await db.coupon.create({
    data: {
      code,
      type: parsed.data.type,
      value: parsed.data.value,
      minSubtotal: parsed.data.minSubtotal ?? null,
      active: true,
    },
  });

  return NextResponse.json({ coupon: toCouponDTO(coupon) }, { status: 201 });
}
