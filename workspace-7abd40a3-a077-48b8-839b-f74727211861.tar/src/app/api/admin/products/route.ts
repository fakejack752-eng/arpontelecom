import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin, jsonify, toProductDTO, unauthorized } from "../../_helpers";

export const dynamic = "force-dynamic";

// GET /api/admin/products (header x-admin-passcode) → { products: ProductDTO[] }
export async function GET(req: NextRequest) {
  if (!isAdmin(req)) return unauthorized();

  const products = await db.product.findMany({
    include: { category: true },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json({ products: products.map(toProductDTO) });
}

// POST /api/admin/products — create (images/specs/variants arrive as arrays, stored as JSON strings)
export async function POST(req: NextRequest) {
  if (!isAdmin(req)) return unauthorized();

  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const slug = String(body.slug ?? "").trim();
  const nameEn = String(body.nameEn ?? "").trim();
  const nameBn = String(body.nameBn ?? "").trim();
  const brand = String(body.brand ?? "").trim();
  const price = Number(body.price);

  if (!slug || !nameEn || !nameBn || !brand || !Number.isFinite(price) || price <= 0) {
    return NextResponse.json(
      { error: "slug, nameEn, nameBn, brand and a positive price are required" },
      { status: 400 },
    );
  }

  // category by id or slug
  let categoryId = typeof body.categoryId === "string" ? body.categoryId : "";
  if (body.categorySlug) {
    const cat = await db.category.findUnique({
      where: { slug: String(body.categorySlug) },
    });
    if (cat) categoryId = cat.id;
  }
  if (!categoryId) {
    return NextResponse.json(
      { error: "categoryId or categorySlug is required" },
      { status: 400 },
    );
  }
  const category = await db.category.findUnique({ where: { id: categoryId } });
  if (!category) {
    return NextResponse.json({ error: "Category not found" }, { status: 400 });
  }

  const slugTaken = await db.product.findUnique({ where: { slug } });
  if (slugTaken) {
    return NextResponse.json(
      { error: "A product with this slug already exists" },
      { status: 409 },
    );
  }

  const stock = Number.isFinite(Number(body.stock))
    ? Math.max(0, Math.floor(Number(body.stock)))
    : 0;
  const stockStatus =
    body.stockStatus === "in_stock" ||
    body.stockStatus === "out_of_stock" ||
    body.stockStatus === "pre_order"
      ? body.stockStatus
      : stock === 0
        ? "out_of_stock"
        : "in_stock";

  const product = await db.product.create({
    data: {
      slug,
      nameEn,
      nameBn,
      brand,
      categoryId,
      price,
      oldPrice:
        body.oldPrice === null || body.oldPrice === undefined
          ? null
          : Number(body.oldPrice) || null,
      stock,
      stockStatus,
      images: jsonify(body.images),
      specs: jsonify(body.specs),
      variants: jsonify(body.variants),
      ram: body.ram ?? null,
      storage: body.storage ?? null,
      rating: Number.isFinite(Number(body.rating))
        ? Math.min(5, Math.max(0, Number(body.rating)))
        : 4.5,
      reviewCount: Number.isFinite(Number(body.reviewCount))
        ? Math.max(0, Math.floor(Number(body.reviewCount)))
        : 0,
      isFlash: !!body.isFlash,
      flashEndsAt: body.isFlash && body.flashEndsAt
        ? new Date(body.flashEndsAt)
        : null,
      isNew: !!body.isNew,
      isBestSeller: !!body.isBestSeller,
      warrantyEn: String(body.warrantyEn ?? ""),
      warrantyBn: String(body.warrantyBn ?? ""),
      descriptionEn: String(body.descriptionEn ?? ""),
      descriptionBn: String(body.descriptionBn ?? ""),
      soldCount: Number.isFinite(Number(body.soldCount))
        ? Math.max(0, Math.floor(Number(body.soldCount)))
        : 0,
    },
    include: { category: true },
  });

  return NextResponse.json({ product: toProductDTO(product) }, { status: 201 });
}
