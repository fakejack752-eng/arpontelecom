import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { isAdmin, toProductDTO, unauthorized } from "../../../_helpers";

export const dynamic = "force-dynamic";

const STOCK_STATUSES = ["in_stock", "out_of_stock", "pre_order"];

// PUT /api/admin/products/[id] { price?, stock?, stockStatus? } → { product }
// stockStatus auto-derives from stock (0 → out_of_stock) unless the body
// explicitly provides one (e.g. "pre_order").
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!isAdmin(req)) return unauthorized();

  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") {
    return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
  }

  const existing = await db.product.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  const data: { price?: number; stock?: number; stockStatus?: string } = {};

  if (body.price !== undefined) {
    const price = Number(body.price);
    if (!Number.isFinite(price) || price < 0) {
      return NextResponse.json({ error: "price must be a positive number" }, { status: 400 });
    }
    data.price = price;
  }

  const explicitStatus =
    body.stockStatus !== undefined &&
    STOCK_STATUSES.includes(String(body.stockStatus))
      ? String(body.stockStatus)
      : undefined;

  if (body.stockStatus !== undefined && !explicitStatus) {
    return NextResponse.json(
      { error: `stockStatus must be one of: ${STOCK_STATUSES.join(", ")}` },
      { status: 400 },
    );
  }

  if (body.stock !== undefined) {
    const stock = Number(body.stock);
    if (!Number.isFinite(stock) || stock < 0) {
      return NextResponse.json({ error: "stock must be a non-negative number" }, { status: 400 });
    }
    data.stock = Math.floor(stock);
    data.stockStatus = explicitStatus ?? (data.stock === 0 ? "out_of_stock" : "in_stock");
  } else if (explicitStatus) {
    data.stockStatus = explicitStatus;
  }

  const product = await db.product.update({
    where: { id },
    data,
    include: { category: true },
  });

  return NextResponse.json({ product: toProductDTO(product) });
}

// DELETE /api/admin/products/[id] → { ok: true }
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!isAdmin(req)) return unauthorized();

  const { id } = await params;
  const existing = await db.product.findUnique({ where: { id } });
  if (!existing) {
    return NextResponse.json({ error: "Product not found" }, { status: 404 });
  }

  await db.review.deleteMany({ where: { productId: id } });
  await db.product.delete({ where: { id } });

  return NextResponse.json({ ok: true });
}
